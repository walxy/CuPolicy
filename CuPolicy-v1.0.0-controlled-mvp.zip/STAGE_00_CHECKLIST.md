# Stage 00 checklist

## Architecture
- [x] Product boundary written
- [x] Refactoring policy written
- [x] Dependency policy written
- [x] License policy written
- [x] Versioning policy written
- [x] Initial error register written

## Reproducibility
- [x] CMake configure/build validated locally
- [x] Python metadata parses locally
- [ ] uv.lock generated in a network-enabled trusted environment
- [ ] Ruff/ty/pytest run from the locked environment
- [ ] MkDocs strict build run from the locked environment

## Naming
- [x] Initial exact GitHub/public-web collision search performed
- [ ] Trademark/domain/package-name clearance before public launch

## Runtime transition
- [x] Stage 00 prohibited CUDA runtime implementation only; v0.2.x host-side observer is now implemented
- [x] CUDA runtime/GPU validation remains explicitly deferred until CUDA code exists
