// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/shadow.hpp"

#include <chrono>
#include <cstdint>
#include <iostream>

int main() {
    using clock = std::chrono::steady_clock;
    using namespace cupolicy;

    PolicyCandidate candidate{};
    candidate.observation.capture_definition_id = 42;
    candidate.observation.eager_duration_ns = 1000;
    candidate.observation.graph_replay_duration_ns = 100;
    candidate.observation.capture_duration_ns = 50;
    candidate.observation.instantiate_duration_ns = 50;
    candidate.observation.warmup_duration_ns = 50;
    candidate.observation.graph_memory_bytes = 1024;
    candidate.observation.fields =
        ObservationField::kCaptureDefinition |
        ObservationField::kEagerDuration |
        ObservationField::kGraphReplayDuration |
        ObservationField::kCaptureDuration |
        ObservationField::kInstantiateDuration |
        ObservationField::kWarmupDuration |
        ObservationField::kGraphMemory |
        ObservationField::kContractValidation;
    candidate.observation.timing_samples = 10;
    candidate.observation.confidence = EvidenceConfidence::kHigh;
    candidate.expected_replays = 10;
    candidate.memory = MemorySnapshot{
        1 << 20,
        1 << 10,
        1 << 10,
        MemoryField::kDeviceBudget | MemoryField::kNonGraphResident |
            MemoryField::kGraphResident,
    };

    PolicyConstraints constraints{};
    constraints.min_evidence_confidence = EvidenceConfidence::kHigh;

    constexpr std::uint64_t iterations = 100'000;
    ShadowController controller(ShadowConfig{ShadowMode::kShadow, iterations});

    const auto start = clock::now();
    std::uint64_t checksum = 0;
    for (std::uint64_t i = 0; i < iterations; ++i) {
        const ShadowEvaluation result = controller.evaluate(candidate, constraints);
        checksum += static_cast<std::uint64_t>(result.evaluated);
    }
    const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(clock::now() - start);

    std::cout << "shadow_evaluation_ns=" <<
        (static_cast<double>(elapsed.count()) / static_cast<double>(iterations)) << '\n';
    std::cout << "evaluated_checksum=" << checksum << '\n';
    std::cout << "trace_entries=" << controller.report().trace_entries << '\n';
    std::cout << "trace_dropped=" << controller.report().trace_dropped << '\n';
    return 0;
}
