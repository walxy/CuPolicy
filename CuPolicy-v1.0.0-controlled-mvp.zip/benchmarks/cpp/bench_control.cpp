// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/control.hpp"

#include <chrono>
#include <cstdint>
#include <iostream>

namespace {

bool eager(void*) noexcept { return true; }
bool graph_available(void*) noexcept { return true; }
cupolicy::BackendStatus graph_launch(void*) noexcept {
    return {cupolicy::BackendStatusCode::kOk, cupolicy::SafetyEventKind::kNone, 0};
}

cupolicy::PolicyCandidate candidate() {
    cupolicy::PolicyCandidate c{};
    c.observation.capture_definition_id = 1;
    c.observation.eager_duration_ns = 200;
    c.observation.graph_replay_duration_ns = 100;
    c.observation.capture_duration_ns = 10;
    c.observation.instantiate_duration_ns = 10;
    c.observation.warmup_duration_ns = 10;
    c.observation.graph_memory_bytes = 64;
    c.observation.fields =
        cupolicy::ObservationField::kCaptureDefinition |
        cupolicy::ObservationField::kEagerDuration |
        cupolicy::ObservationField::kGraphReplayDuration |
        cupolicy::ObservationField::kCaptureDuration |
        cupolicy::ObservationField::kInstantiateDuration |
        cupolicy::ObservationField::kWarmupDuration |
        cupolicy::ObservationField::kGraphMemory |
        cupolicy::ObservationField::kContractValidation;
    c.observation.timing_samples = 10;
    c.observation.confidence = cupolicy::EvidenceConfidence::kHigh;
    c.observation.contract_issues = cupolicy::ContractIssue::kNone;
    c.expected_replays = 10;
    c.memory = {4096, 0, 0,
                 cupolicy::MemoryField::kDeviceBudget |
                     cupolicy::MemoryField::kNonGraphResident |
                     cupolicy::MemoryField::kGraphResident};
    return c;
}

}  // namespace

int main() {
    using namespace cupolicy;
    const auto c = candidate();
    const PolicyConstraints constraints{};
    const ControlBackend backend{graph_available, graph_launch, nullptr};
    ControlController controller(ControlConfig{ControlMode::kControlled, true, true});

    constexpr std::uint64_t iterations = 100000;
    std::uint64_t accepted = 0;
    const auto start = std::chrono::steady_clock::now();
    for (std::uint64_t i = 0; i < iterations; ++i) {
        const auto result = controller.execute(c, constraints, backend, eager);
        accepted += result.graph_executed ? 1U : 0U;
    }
    const auto elapsed = std::chrono::steady_clock::now() - start;
    const double ns = std::chrono::duration<double, std::nano>(elapsed).count() /
                      static_cast<double>(iterations);
    std::cout << "iterations=" << iterations << "\n"
              << "control_evaluation_ns=" << ns << "\n"
              << "graph_executions=" << accepted << "\n";
    return 0;
}
