// SPDX-License-Identifier: Apache-2.0
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cerrno>
#include <iomanip>
#include <iostream>

#include "cupolicy/observation.hpp"

namespace {

inline void do_not_optimize(std::uint64_t value) noexcept {
#if defined(__GNUC__) || defined(__clang__)
    asm volatile("" : "+g"(value) : : "memory");
#else
    static volatile std::uint64_t sink = 0;
    sink ^= value;
#endif
}

template <typename Fn>
double measure_ns_per_iteration(Fn&& fn, std::uint64_t iterations) {
    const auto start = std::chrono::steady_clock::now();
    for (std::uint64_t i = 0; i < iterations; ++i) {
        fn(i);
    }
    const auto end = std::chrono::steady_clock::now();
    const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();
    return static_cast<double>(ns) / static_cast<double>(iterations);
}

}  // namespace

int main(int argc, char** argv) {
    std::uint64_t iterations = 1000000ULL;
    if (argc > 1) {
        char* end = nullptr;
        errno = 0;
        const auto parsed = std::strtoull(argv[1], &end, 10);
        if (errno != 0 || end == argv[1] || *end != '\0' || parsed == 0) {
            std::cerr << "iterations must be a positive integer\n";
            return EXIT_FAILURE;
        }
        iterations = static_cast<std::uint64_t>(parsed);
    }

    cupolicy::Observer disabled{{cupolicy::ObservationMode::kDisabled, 1}};
    cupolicy::Observer sampled{{cupolicy::ObservationMode::kSampled, 16}};
    cupolicy::Observer full{{cupolicy::ObservationMode::kFull, 1}};

    const auto baseline = measure_ns_per_iteration(
        [](std::uint64_t i) noexcept { do_not_optimize(i); }, iterations);
    const auto disabled_ns = measure_ns_per_iteration(
        [&disabled](std::uint64_t i) noexcept {
            auto scope = disabled.begin(i, 0);
            static_cast<void>(scope);
        },
        iterations);
    const auto sampled_ns = measure_ns_per_iteration(
        [&sampled](std::uint64_t i) noexcept {
            auto scope = sampled.begin(i, 0);
            static_cast<void>(scope);
        },
        iterations);
    const auto full_ns = measure_ns_per_iteration(
        [&full](std::uint64_t i) noexcept {
            auto scope = full.begin(i, 0);
            static_cast<void>(scope);
        },
        iterations);

    std::cout << std::fixed << std::setprecision(2)
              << "iterations=" << iterations << '\n'
              << "baseline_ns=" << baseline << '\n'
              << "disabled_ns=" << disabled_ns << '\n'
              << "sampled16_ns=" << sampled_ns << '\n'
              << "full_ns=" << full_ns << '\n'
              << "disabled_over_baseline_ns=" << (disabled_ns - baseline) << '\n'
              << "sampled16_over_baseline_ns=" << (sampled_ns - baseline) << '\n'
              << "full_over_baseline_ns=" << (full_ns - baseline) << '\n';

    const auto sampled_snapshot = sampled.snapshot();
    const auto full_snapshot = full.snapshot();
    std::cout << "sampled_events=" << sampled_snapshot.events_seen << '\n'
              << "sampled_samples=" << sampled_snapshot.samples_recorded << '\n'
              << "full_events=" << full_snapshot.events_seen << '\n'
              << "full_samples=" << full_snapshot.samples_recorded << '\n';

    return EXIT_SUCCESS;
}
