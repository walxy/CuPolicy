// SPDX-License-Identifier: Apache-2.0
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cerrno>
#include <iomanip>
#include <iostream>

#include "cupolicy/residency.hpp"

namespace {

void do_not_optimize(std::uint64_t value) noexcept {
#if defined(__GNUC__) || defined(__clang__)
    asm volatile("" : "+g"(value) : : "memory");
#else
    static volatile std::uint64_t sink = 0;
    sink ^= value;
#endif
}

template <typename Fn>
double measure_ns_per_iteration(Fn&& fn, std::uint64_t iterations) {
    const auto start = std::chrono::steady_clock::now();
    for (std::uint64_t i = 0; i < iterations; ++i) {
        fn(i);
    }
    const auto end = std::chrono::steady_clock::now();
    const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();
    return static_cast<double>(ns) / static_cast<double>(iterations);
}

}  // namespace

int main(int argc, char** argv) {
    std::uint64_t iterations = 1'000'000ULL;
    if (argc > 1) {
        char* end = nullptr;
        errno = 0;
        const auto parsed = std::strtoull(argv[1], &end, 10);
        if (errno != 0 || end == argv[1] || *end != '\0' || parsed == 0) {
            std::cerr << "iterations must be a positive integer\n";
            return EXIT_FAILURE;
        }
        iterations = static_cast<std::uint64_t>(parsed);
    }

    using namespace cupolicy;
    ResidencyController controller(ResidencyConstraints{64, 64 * 1024 * 1024});
    for (std::uint64_t i = 1; i <= 64; ++i) {
        if (!controller.admit(i, i, 1024 * 1024)) {
            std::cerr << "failed to seed residency controller\n";
            return EXIT_FAILURE;
        }
    }

    std::uint64_t accumulator = 0;
    const double evaluation_ns = measure_ns_per_iteration(
        [&controller, &accumulator](std::uint64_t i) noexcept {
            const ResidencyDecision result = controller.evaluate(1000 + i, 2000 + i, 1024 * 1024);
            accumulator += result.projected_graph_bytes + result.projected_graphs;
        },
        iterations);

    do_not_optimize(accumulator);
    std::cout << std::fixed << std::setprecision(2)
              << "iterations=" << iterations << '\n'
              << "residency_evaluation_ns=" << evaluation_ns << '\n'
              << "accumulator=" << accumulator << '\n';
    return EXIT_SUCCESS;
}
