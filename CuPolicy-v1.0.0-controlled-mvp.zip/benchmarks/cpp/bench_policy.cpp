// SPDX-License-Identifier: Apache-2.0
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cerrno>
#include <iomanip>
#include <iostream>

#include "cupolicy/policy.hpp"

namespace {

inline void do_not_optimize(std::uint64_t value) noexcept {
#if defined(__GNUC__) || defined(__clang__)
    asm volatile("" : "+g"(value) : : "memory");
#else
    static volatile std::uint64_t sink = 0;
    sink ^= value;
#endif
}

template <typename Fn>
double measure_ns_per_iteration(Fn&& fn, std::uint64_t iterations) {
    const auto start = std::chrono::steady_clock::now();
    for (std::uint64_t i = 0; i < iterations; ++i) {
        fn(i);
    }
    const auto end = std::chrono::steady_clock::now();
    const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();
    return static_cast<double>(ns) / static_cast<double>(iterations);
}

}  // namespace

int main(int argc, char** argv) {
    std::uint64_t iterations = 1'000'000ULL;
    if (argc > 1) {
        char* end = nullptr;
        errno = 0;
        const auto parsed = std::strtoull(argv[1], &end, 10);
        if (errno != 0 || end == argv[1] || *end != '\0' || parsed == 0) {
            std::cerr << "iterations must be a positive integer\n";
            return EXIT_FAILURE;
        }
        iterations = static_cast<std::uint64_t>(parsed);
    }

    using namespace cupolicy;
    const PolicyCandidate candidate{
        ObservedExecution{
            123,
            100,
            40,
            100,
            20,
            10,
            1024,
            ContractIssue::kNone,
            ObservationField::kCaptureDefinition | ObservationField::kEagerDuration |
                ObservationField::kGraphReplayDuration | ObservationField::kCaptureDuration |
                ObservationField::kInstantiateDuration | ObservationField::kWarmupDuration |
                ObservationField::kGraphMemory | ObservationField::kContractValidation,
                10,
                EvidenceConfidence::kHigh,
        },
        10,
        PolicyCandidateState::kAvailable,
        ExecutionMode::kEager,
        MemorySnapshot{16 * 1024, 2 * 1024, 4 * 1024,
                       MemoryField::kDeviceBudget | MemoryField::kNonGraphResident |
                           MemoryField::kGraphResident},
    };
    const PolicyConstraints constraints{};
    std::uint64_t accumulator = 0;

    const double evaluation_ns = measure_ns_per_iteration(
        [&candidate, &constraints, &accumulator](std::uint64_t i) noexcept {
            const PolicyEvaluation result = PolicyEvaluator::evaluate(candidate, constraints);
            accumulator += result.estimated_net_benefit_ns + i;
        },
        iterations);

    do_not_optimize(accumulator);
    std::cout << std::fixed << std::setprecision(2)
              << "iterations=" << iterations << '\n'
              << "policy_evaluation_ns=" << evaluation_ns << '\n'
              << "accumulator=" << accumulator << '\n';
    return EXIT_SUCCESS;
}
