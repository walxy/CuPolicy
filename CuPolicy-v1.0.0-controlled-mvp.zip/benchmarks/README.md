# Benchmarks

Host-side observer, policy evaluation, and residency evaluation benchmarks are available.
These benchmarks are methodology probes only; they do not establish GPU runtime overhead, CUDA graph speedups, or production performance.
