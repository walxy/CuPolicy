// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/policy.hpp"

#include <algorithm>
#include <vector>

namespace cupolicy {
namespace {

[[nodiscard]] constexpr std::uint64_t saturating_add(std::uint64_t lhs,
                                                     std::uint64_t rhs) noexcept {
    constexpr auto max_value = std::numeric_limits<std::uint64_t>::max();
    return lhs > max_value - rhs ? max_value : lhs + rhs;
}

[[nodiscard]] constexpr std::uint64_t saturating_mul(std::uint64_t lhs,
                                                     std::uint64_t rhs) noexcept {
    constexpr auto max_value = std::numeric_limits<std::uint64_t>::max();
    if (lhs == 0 || rhs == 0) {
        return 0;
    }
    return lhs > max_value / rhs ? max_value : lhs * rhs;
}


[[nodiscard]] constexpr std::uint64_t min_positive_replays_for_setup(
    std::uint64_t setup_cost_ns,
    std::uint64_t per_replay_savings_ns) noexcept {
    if (per_replay_savings_ns == 0) {
        return 0;
    }
    if (setup_cost_ns == 0) {
        return 1;
    }
    const std::uint64_t quotient = setup_cost_ns / per_replay_savings_ns;
    constexpr auto max_value = std::numeric_limits<std::uint64_t>::max();
    return quotient == max_value ? max_value : quotient + 1;
}

void record_reason(SimulationSummary& summary, DecisionReason reason) noexcept {
    switch (reason) {
        case DecisionReason::kInsufficientEvidence:
            ++summary.insufficient_evidence;
            break;
        case DecisionReason::kInvalidCandidate:
            ++summary.invalid_candidate;
            break;
        case DecisionReason::kUnsafeContract:
            ++summary.unsafe_contract;
            break;
        case DecisionReason::kGraphUnavailable:
            ++summary.graph_unavailable;
            break;
        case DecisionReason::kInsufficientReuse:
            ++summary.insufficient_reuse;
            break;
        case DecisionReason::kMemoryBudget:
            ++summary.memory_budget_rejections;
            break;
        case DecisionReason::kNonPositiveBenefit:
            ++summary.non_positive_benefit;
            break;
        case DecisionReason::kNotAmortized:
            ++summary.not_amortized;
            break;
        case DecisionReason::kBelowBenefitThreshold:
            ++summary.below_benefit_threshold;
            break;
        case DecisionReason::kNotEnoughConfidence:
            ++summary.not_enough_confidence;
            break;
        case DecisionReason::kVariantBudget:
            ++summary.variant_budget_rejections;
            break;
        case DecisionReason::kRuntimeFailure:
            ++summary.runtime_failures;
            break;
        case DecisionReason::kEvicted:
            ++summary.evicted_decisions;
            break;
        case DecisionReason::kUnspecified:
        case DecisionReason::kDefault:
        case DecisionReason::kHysteresisRetained:
        case DecisionReason::kCandidateAccepted:
            break;
    }
}

[[nodiscard]] bool same_definition(const PolicyCandidate& lhs,
                                   const PolicyCandidate& rhs) noexcept {
    return lhs.observation.capture_definition_id != 0 &&
           lhs.observation.capture_definition_id == rhs.observation.capture_definition_id;
}

[[nodiscard]] bool contains_definition(std::span<const std::uint64_t> definitions,
                                       std::uint64_t definition_id) noexcept {
    return std::find(definitions.begin(), definitions.end(), definition_id) != definitions.end();
}

}  // namespace

MemoryAdmission MemoryPolicyEvaluator::evaluate(const MemorySnapshot& snapshot,
                                                    std::uint64_t candidate_graph_bytes,
                                                    const MemoryConstraints& constraints) noexcept {
    MemoryAdmission result{};
    if (!constraints.valid() || (constraints.require_memory_evidence && !snapshot.complete())) {
        result.reason = MemoryAdmissionReason::kInsufficientEvidence;
        return result;
    }

    if (!snapshot.complete() && !constraints.require_memory_evidence) {
        result.admitted = true;
        result.reason = MemoryAdmissionReason::kAccepted;
        result.projected_graph_resident_bytes = snapshot.graph_resident_bytes;
        result.projected_total_resident_bytes = snapshot.non_graph_resident_bytes + snapshot.graph_resident_bytes;
        result.free_bytes_after_admission = std::numeric_limits<std::uint64_t>::max();
        return result;
    }

    if (snapshot.non_graph_resident_bytes > snapshot.device_budget_bytes ||
        snapshot.graph_resident_bytes > snapshot.device_budget_bytes - snapshot.non_graph_resident_bytes) {
        result.reason = MemoryAdmissionReason::kCurrentUsageExceedsBudget;
        result.projected_graph_resident_bytes = snapshot.graph_resident_bytes;
        result.projected_total_resident_bytes = std::numeric_limits<std::uint64_t>::max();
        return result;
    }

    if (snapshot.graph_resident_bytes > constraints.max_graph_resident_bytes) {
        result.reason = MemoryAdmissionReason::kCandidateExceedsGraphBudget;
        result.projected_graph_resident_bytes = snapshot.graph_resident_bytes;
        result.projected_total_resident_bytes = snapshot.non_graph_resident_bytes + snapshot.graph_resident_bytes;
        return result;
    }

    const std::uint64_t remaining_graph_budget =
        constraints.max_graph_resident_bytes - snapshot.graph_resident_bytes;
    if (candidate_graph_bytes > remaining_graph_budget) {
        result.reason = MemoryAdmissionReason::kCandidateExceedsGraphBudget;
        result.projected_graph_resident_bytes = snapshot.graph_resident_bytes;
        result.projected_total_resident_bytes = snapshot.non_graph_resident_bytes +
                                                 snapshot.graph_resident_bytes;
        return result;
    }

    const std::uint64_t used_without_candidate =
        snapshot.non_graph_resident_bytes + snapshot.graph_resident_bytes;
    const std::uint64_t remaining_total_budget =
        snapshot.device_budget_bytes - used_without_candidate;
    if (candidate_graph_bytes > remaining_total_budget) {
        result.reason = MemoryAdmissionReason::kTotalBudgetExceeded;
        result.projected_graph_resident_bytes = snapshot.graph_resident_bytes;
        result.projected_total_resident_bytes = used_without_candidate;
        result.free_bytes_after_admission = remaining_total_budget;
        return result;
    }

    const std::uint64_t projected_total = used_without_candidate + candidate_graph_bytes;
    const std::uint64_t free_after = snapshot.device_budget_bytes - projected_total;
    result.projected_graph_resident_bytes = snapshot.graph_resident_bytes + candidate_graph_bytes;
    result.projected_total_resident_bytes = projected_total;
    result.free_bytes_after_admission = free_after;
    if (free_after < constraints.min_free_bytes_after_admission) {
        result.reason = MemoryAdmissionReason::kReservedHeadroomViolated;
        return result;
    }

    result.admitted = true;
    result.reason = MemoryAdmissionReason::kAccepted;
    return result;
}

PolicyEvaluation PolicyEvaluator::evaluate(const PolicyCandidate& candidate,
                                           const PolicyConstraints& constraints) noexcept {
    PolicyEvaluation result{};
    const ObservedExecution& observation = candidate.observation;

    if (!constraints.valid()) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0, DecisionReason::kInvalidCandidate};
        return result;
    }

    if (!observation.complete_for_policy(constraints.require_contract_validation) ||
        observation.timing_samples < constraints.min_timing_samples) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                            DecisionReason::kInsufficientEvidence};
        return result;
    }

    if (!confidence_at_least(observation.confidence, constraints.min_evidence_confidence)) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                            DecisionReason::kNotEnoughConfidence};
        return result;
    }

    if (candidate.state == PolicyCandidateState::kUnavailable) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                            DecisionReason::kGraphUnavailable};
        return result;
    }
    if (candidate.state != PolicyCandidateState::kAvailable) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                            DecisionReason::kInvalidCandidate};
        return result;
    }
    switch (candidate.current_mode) {
        case ExecutionMode::kEager:
        case ExecutionMode::kGraph:
        case ExecutionMode::kPiecewise:
        case ExecutionMode::kUpdate:
        case ExecutionMode::kRecapture:
        case ExecutionMode::kFallback:
            break;
        default:
            result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                                DecisionReason::kInvalidCandidate};
            return result;
    }

    if (constraints.require_contract_validation && observation.contract_issues != ContractIssue::kNone) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                            DecisionReason::kUnsafeContract};
        return result;
    }

    if (candidate.expected_replays < constraints.min_expected_replays) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                            DecisionReason::kInsufficientReuse};
        return result;
    }

    if (observation.graph_memory_bytes > constraints.max_graph_memory_bytes) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0, DecisionReason::kMemoryBudget};
        return result;
    }

    const MemoryAdmission memory_admission =
        MemoryPolicyEvaluator::evaluate(candidate.memory, observation.graph_memory_bytes,
                                        constraints.memory);
    result.memory_evaluated = true;
    result.memory_reason = memory_admission.reason;
    if (!memory_admission.admitted) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0, DecisionReason::kMemoryBudget};
        return result;
    }

    if (observation.eager_duration_ns <= observation.graph_replay_duration_ns) {
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0,
                                            DecisionReason::kNonPositiveBenefit};
        return result;
    }

    result.per_replay_savings_ns =
        observation.eager_duration_ns - observation.graph_replay_duration_ns;
    result.setup_cost_ns = saturating_add(
        observation.capture_duration_ns,
        saturating_add(observation.instantiate_duration_ns, observation.warmup_duration_ns));
    result.break_even_replays =
        min_positive_replays_for_setup(result.setup_cost_ns, result.per_replay_savings_ns);
    result.break_even_reachable = result.per_replay_savings_ns != 0 &&
                                  result.break_even_replays != std::numeric_limits<std::uint64_t>::max();
    const std::uint64_t total_savings =
        saturating_mul(candidate.expected_replays, result.per_replay_savings_ns);
    result.estimated_net_benefit_ns =
        total_savings >= result.setup_cost_ns ? total_savings - result.setup_cost_ns : 0;

    const bool was_graph = candidate.current_mode == ExecutionMode::kGraph;
    if (was_graph && result.estimated_net_benefit_ns > constraints.graph_exit_min_net_benefit_ns &&
        result.estimated_net_benefit_ns <= constraints.min_net_benefit_ns) {
        result.hysteresis_retained = true;
        result.decision = ExecutionDecision{ExecutionMode::kGraph, 0,
                                            DecisionReason::kHysteresisRetained};
        return result;
    }

    const std::uint64_t threshold = was_graph ? constraints.graph_exit_min_net_benefit_ns
                                              : constraints.min_net_benefit_ns;
    if (result.estimated_net_benefit_ns <= threshold) {
        DecisionReason reason = DecisionReason::kBelowBenefitThreshold;
        if (result.estimated_net_benefit_ns == 0) {
            reason = !result.break_even_reachable || result.break_even_replays > candidate.expected_replays
                         ? DecisionReason::kNotAmortized
                         : DecisionReason::kNonPositiveBenefit;
        }
        result.decision = ExecutionDecision{ExecutionMode::kEager, 0, reason};
        return result;
    }

    result.decision = ExecutionDecision{ExecutionMode::kGraph, 0,
                                        DecisionReason::kCandidateAccepted};
    return result;
}

SimulationSummary PolicySimulator::simulate(std::span<const PolicyCandidate> candidates,
                                            const PolicyConstraints& constraints,
                                            PolicyDecisionSink sink,
                                            void* sink_context) {
    SimulationSummary summary{};
    std::vector<std::uint64_t> accepted_definitions;
    accepted_definitions.reserve(candidates.size());

    for (std::size_t i = 0; i < candidates.size(); ++i) {
        const PolicyCandidate& candidate = candidates[i];
        PolicyEvaluation evaluation = PolicyEvaluator::evaluate(candidate, constraints);

        const bool duplicate = candidate.observation.capture_definition_id != 0 &&
                               i > 0 &&
                               std::any_of(candidates.begin(),
                                           candidates.begin() + static_cast<std::ptrdiff_t>(i),
                                           [&](const PolicyCandidate& prior) noexcept {
                                               return same_definition(candidate, prior);
                                           });
        if (candidate.observation.capture_definition_id != 0 && !duplicate) {
            ++summary.unique_capture_definitions;
        } else if (duplicate) {
            ++summary.duplicate_candidates;
        }

        const bool already_accepted =
            candidate.observation.capture_definition_id != 0 &&
            contains_definition(accepted_definitions, candidate.observation.capture_definition_id);

        if (evaluation.decision.mode == ExecutionMode::kGraph && !already_accepted) {
            if (accepted_definitions.size() >= constraints.max_graph_variants) {
                evaluation.decision =
                    ExecutionDecision{ExecutionMode::kEager, 0, DecisionReason::kVariantBudget};
            } else if (candidate.observation.capture_definition_id != 0) {
                accepted_definitions.push_back(candidate.observation.capture_definition_id);
                ++summary.accepted_graph_definitions;
            }
        }

        ++summary.observations;
        if (evaluation.hysteresis_retained && evaluation.decision.mode == ExecutionMode::kGraph) {
            ++summary.hysteresis_retained;
        }
        if (evaluation.decision.mode == ExecutionMode::kGraph) {
            ++summary.graph_decisions;
            summary.estimated_net_benefit_ns =
                saturating_add(summary.estimated_net_benefit_ns, evaluation.estimated_net_benefit_ns);
        } else {
            ++summary.eager_decisions;
            record_reason(summary, evaluation.decision.reason);
        }
        if (sink != nullptr) {
            sink(candidate, evaluation, sink_context);
        }
    }
    return summary;
}

}  // namespace cupolicy
