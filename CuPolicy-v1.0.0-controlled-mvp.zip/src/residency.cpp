// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/residency.hpp"

#include <algorithm>
#include <limits>

namespace cupolicy {
namespace {

[[nodiscard]] constexpr bool add_overflow(std::uint64_t lhs,
                                           std::uint64_t rhs,
                                           std::uint64_t& result) noexcept {
    constexpr auto max_value = std::numeric_limits<std::uint64_t>::max();
    if (lhs > max_value - rhs) {
        result = max_value;
        return true;
    }
    result = lhs + rhs;
    return false;
}

[[nodiscard]] constexpr std::uint64_t saturating_add(std::uint64_t lhs,
                                                     std::uint64_t rhs) noexcept {
    std::uint64_t result = 0;
    (void)add_overflow(lhs, rhs, result);
    return result;
}

}  // namespace

bool ResidencyController::contains(std::uint64_t capture_definition_id) const noexcept {
    return std::any_of(entries_.begin(), entries_.end(), [&](const ResidentGraph& entry) noexcept {
        return entry.capture_definition_id == capture_definition_id;
    });
}

std::optional<ResidentGraph> ResidencyController::find(
    std::uint64_t capture_definition_id) const noexcept {
    const auto it = std::find_if(entries_.begin(), entries_.end(),
                                 [&](const ResidentGraph& entry) noexcept {
                                     return entry.capture_definition_id == capture_definition_id;
                                 });
    if (it == entries_.end()) {
        return std::nullopt;
    }
    return *it;
}

bool ResidencyController::less_for_eviction(const ResidentGraph& lhs,
                                             const ResidentGraph& rhs) noexcept {
    if (lhs.last_used_tick != rhs.last_used_tick) {
        return lhs.last_used_tick < rhs.last_used_tick;
    }
    if (lhs.graph_id != rhs.graph_id) {
        return lhs.graph_id < rhs.graph_id;
    }
    return lhs.capture_definition_id < rhs.capture_definition_id;
}

std::optional<EvictionTarget> ResidencyController::next_eviction() const noexcept {
    const auto it = std::min_element(
        entries_.begin(), entries_.end(), [](const ResidentGraph& lhs, const ResidentGraph& rhs) {
            if (lhs.pin_count == 0 && rhs.pin_count != 0) {
                return true;
            }
            if (lhs.pin_count != 0 && rhs.pin_count == 0) {
                return false;
            }
            if (lhs.pin_count != 0 && rhs.pin_count != 0) {
                return false;
            }
            return less_for_eviction(lhs, rhs);
        });

    if (it == entries_.end() || it->pin_count != 0) {
        return std::nullopt;
    }
    return EvictionTarget{it->capture_definition_id, it->graph_id, it->memory_bytes};
}

bool ResidencyController::would_fit(std::uint64_t graph_count,
                                    std::uint64_t graph_bytes) const noexcept {
    return graph_count <= constraints_.max_graphs && graph_bytes <= constraints_.max_graph_bytes;
}

ResidencyDecision ResidencyController::evaluate(std::uint64_t capture_definition_id,
                                                std::uint64_t graph_id,
                                                std::uint64_t memory_bytes) const noexcept {
    ResidencyDecision result{};
    if (!constraints_.valid()) {
        result.reason = ResidencyDecisionReason::kInvalidConstraints;
        return result;
    }
    if (capture_definition_id == 0 || graph_id == 0) {
        result.reason = ResidencyDecisionReason::kInvalidDefinition;
        return result;
    }

    const auto existing = find(capture_definition_id);
    if (existing.has_value()) {
        if (existing->graph_id == graph_id && existing->memory_bytes == memory_bytes) {
            result.admissible = true;
            result.reason = ResidencyDecisionReason::kAlreadyResident;
            result.projected_graphs = entries_.size();
            result.projected_graph_bytes = resident_bytes_;
            return result;
        }

        result.reason = ResidencyDecisionReason::kReplacementRequired;
        result.replacement = existing;
        if (existing->pin_count != 0) {
            return result;
        }
        const std::uint64_t replaced_bytes =
            resident_bytes_ - existing->memory_bytes;
        std::uint64_t projected_bytes = 0;
        const bool overflow = add_overflow(replaced_bytes, memory_bytes, projected_bytes);
        if (!overflow && would_fit(static_cast<std::uint64_t>(entries_.size()), projected_bytes)) {
            result.projected_graphs = entries_.size();
            result.projected_graph_bytes = projected_bytes;
            return result;
        }
        const auto victim = next_eviction();
        if (victim.has_value() &&
            victim->capture_definition_id != capture_definition_id) {
            result.eviction = *victim;
        }
        return result;
    }

    if (memory_bytes > constraints_.max_graph_bytes) {
        result.reason = ResidencyDecisionReason::kCandidateTooLarge;
        return result;
    }

    const std::uint64_t candidate_count = saturating_add(entries_.size(), 1);
    std::uint64_t candidate_bytes = 0;
    const bool candidate_bytes_overflow =
        add_overflow(resident_bytes_, memory_bytes, candidate_bytes);
    if (!candidate_bytes_overflow && would_fit(candidate_count, candidate_bytes)) {
        result.admissible = true;
        result.reason = ResidencyDecisionReason::kAccepted;
        result.projected_graphs = candidate_count;
        result.projected_graph_bytes = candidate_bytes;
        return result;
    }

    const auto victim = next_eviction();
    if (!victim.has_value()) {
        const bool any_unpinned = std::any_of(
            entries_.begin(), entries_.end(), [](const ResidentGraph& entry) noexcept {
                return entry.pin_count == 0;
            });
        result.reason = !any_unpinned && !entries_.empty()
                            ? ResidencyDecisionReason::kPinnedOnly
                            : ResidencyDecisionReason::kGraphCountBudget;
        result.projected_graphs = candidate_count;
        result.projected_graph_bytes = candidate_bytes;
        return result;
    }

    const std::uint64_t after_bytes = resident_bytes_ - victim->memory_bytes;
    const std::uint64_t after_count = static_cast<std::uint64_t>(entries_.size() - 1U);
    std::uint64_t after_candidate_bytes = 0;
    (void)add_overflow(after_bytes, memory_bytes, after_candidate_bytes);
    const std::uint64_t after_candidate_count = saturating_add(after_count, 1);
    result.reason = ResidencyDecisionReason::kEvictionRequired;
    result.projected_graphs = after_candidate_count;
    result.projected_graph_bytes = after_candidate_bytes;
    result.eviction = *victim;
    if (would_fit(after_candidate_count, after_candidate_bytes)) {
        return result;
    }
    return result;
}

bool ResidencyController::admit(std::uint64_t capture_definition_id,
                                std::uint64_t graph_id,
                                std::uint64_t memory_bytes) {
    if (!evaluate(capture_definition_id, graph_id, memory_bytes).admissible) {
        return false;
    }
    if (contains(capture_definition_id)) {
        return false;
    }
    const ResidencyDecision decision = evaluate(capture_definition_id, graph_id, memory_bytes);
    if (!decision.admissible || decision.eviction.has_value()) {
        return false;
    }
    entries_.push_back(ResidentGraph{capture_definition_id, graph_id, memory_bytes, next_tick_, 0});
    ++next_tick_;
    resident_bytes_ = saturating_add(resident_bytes_, memory_bytes);
    return true;
}

bool ResidencyController::replace(std::uint64_t capture_definition_id,
                                   std::uint64_t graph_id,
                                   std::uint64_t memory_bytes) {
    const auto it = std::find_if(entries_.begin(), entries_.end(),
                                 [&](const ResidentGraph& entry) noexcept {
                                     return entry.capture_definition_id == capture_definition_id;
                                 });
    if (it == entries_.end() || it->pin_count != 0 || graph_id == 0) {
        return false;
    }
    const std::uint64_t base_bytes = resident_bytes_ - it->memory_bytes;
    std::uint64_t projected_bytes = 0;
    if (add_overflow(base_bytes, memory_bytes, projected_bytes) ||
        !would_fit(static_cast<std::uint64_t>(entries_.size()), projected_bytes)) {
        return false;
    }
    it->graph_id = graph_id;
    it->memory_bytes = memory_bytes;
    it->last_used_tick = next_tick_;
    if (next_tick_ != std::numeric_limits<std::uint64_t>::max()) {
        ++next_tick_;
    }
    resident_bytes_ = projected_bytes;
    return true;
}

bool ResidencyController::remove(std::uint64_t capture_definition_id) noexcept {
    const auto it = std::find_if(entries_.begin(), entries_.end(),
                                 [&](const ResidentGraph& entry) noexcept {
                                     return entry.capture_definition_id == capture_definition_id;
                                 });
    if (it == entries_.end() || it->pin_count != 0) {
        return false;
    }
    resident_bytes_ -= it->memory_bytes;
    entries_.erase(it);
    return true;
}

bool ResidencyController::touch(std::uint64_t capture_definition_id) noexcept {
    for (ResidentGraph& entry : entries_) {
        if (entry.capture_definition_id == capture_definition_id) {
            entry.last_used_tick = next_tick_;
            if (next_tick_ != std::numeric_limits<std::uint64_t>::max()) {
                ++next_tick_;
            }
                    return true;
        }
    }
    return false;
}

bool ResidencyController::pin(std::uint64_t capture_definition_id) noexcept {
    for (ResidentGraph& entry : entries_) {
        if (entry.capture_definition_id == capture_definition_id) {
            if (entry.pin_count == std::numeric_limits<std::uint32_t>::max()) {
                return false;
            }
            ++entry.pin_count;
                    return true;
        }
    }
    return false;
}

bool ResidencyController::unpin(std::uint64_t capture_definition_id) noexcept {
    for (ResidentGraph& entry : entries_) {
        if (entry.capture_definition_id == capture_definition_id) {
            if (entry.pin_count == 0) {
                return false;
            }
            --entry.pin_count;
                    return true;
        }
    }
    return false;
}

}  // namespace cupolicy
