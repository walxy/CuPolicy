// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/control.hpp"

namespace cupolicy {
namespace {

[[nodiscard]] constexpr bool is_valid_control_mode(ControlMode mode) noexcept {
    return static_cast<std::uint8_t>(mode) <= static_cast<std::uint8_t>(ControlMode::kControlled);
}

[[nodiscard]] constexpr bool eager_or_block(ControlResult& result,
                                            EagerExecutionCallback callback,
                                            void* context,
                                            ControlAction action) noexcept {
    if (callback == nullptr) {
        result.error = ControlErrorCode::kInvalidEagerCallback;
        result.action = ControlAction::kBlockExecution;
        return false;
    }
    const bool ok = callback(context);
    result.eager_executed = ok;
    result.action = action;
    if (!ok) {
        result.error = ControlErrorCode::kBackendFailed;
        result.action = ControlAction::kBlockExecution;
    }
    return ok;
}

}  // namespace

ControlResult ControlController::execute(const PolicyCandidate& candidate,
                                         const PolicyConstraints& constraints,
                                         const ControlBackend& backend,
                                         EagerExecutionCallback eager_callback,
                                         void* eager_context) noexcept {
    ControlResult result{};
    if (!config_.valid() || !is_valid_control_mode(config_.mode)) {
        result.error = ControlErrorCode::kInvalidConfiguration;
        result.action = ControlAction::kBlockExecution;
        return result;
    }
    if (eager_callback == nullptr) {
        result.error = ControlErrorCode::kInvalidEagerCallback;
        result.action = ControlAction::kBlockExecution;
        return result;
    }

    result.policy = PolicyEvaluator::evaluate(candidate, constraints);

    if (config_.mode == ControlMode::kShadow) {
        result.action = ControlAction::kShadowOnly;
        // v1.0 invariant: shadow mode never calls either execution callback.
        return result;
    }
    if (safety_.state() == SafetyState::kTerminal) {
        result.error = ControlErrorCode::kSafetyBlocked;
        result.action = ControlAction::kBlockExecution;
        return result;
    }
    if (result.policy.decision.mode != ExecutionMode::kGraph) {
        result.error = result.policy.decision.reason == DecisionReason::kCandidateAccepted
                           ? ControlErrorCode::kOk
                           : ControlErrorCode::kPolicyRejected;
        (void)eager_or_block(result, eager_callback, eager_context, ControlAction::kExecuteEager);
        if (result.eager_executed) {
            result.error = ControlErrorCode::kOk;
        }
        return result;
    }
    if (!backend.valid()) {
        result.error = ControlErrorCode::kInvalidBackend;
        result.action = ControlAction::kBlockExecution;
        return result;
    }

    if (config_.require_healthy_safety && safety_.state() != SafetyState::kHealthy) {
        result.error = ControlErrorCode::kSafetyBlocked;
        result.action = ControlAction::kBlockExecution;
        return result;
    }

    if (!backend.graph_available(backend.context)) {
        result.error = ControlErrorCode::kPolicyRejected;
        (void)eager_or_block(result, eager_callback, eager_context, ControlAction::kFallbackEager);
        if (result.eager_executed) {
            result.error = ControlErrorCode::kOk;
        }
        return result;
    }

    result.backend_status = backend.launch_graph(backend.context);
    if (result.backend_status.ok()) {
        result.error = ControlErrorCode::kOk;
        result.action = ControlAction::kExecuteGraph;
        result.graph_executed = true;
        result.intervention_performed = candidate.current_mode != ExecutionMode::kGraph;
        return result;
    }

    result.safety = safety_.observe(
        SafetyEvent{result.backend_status.safety_event, result.backend_status.external_error_code,
                    result.policy.decision.graph_id});
    switch (result.safety.action) {
        case SafetyAction::kFallbackEager:
            result.error = ControlErrorCode::kOk;
            (void)eager_or_block(result, eager_callback, eager_context, ControlAction::kFallbackEager);
            if (result.eager_executed) {
                result.intervention_performed = true;
                return result;
            }
            return result;
        case SafetyAction::kQuarantineGraph:
        case SafetyAction::kRequireProcessRestart:
        case SafetyAction::kProceed:
            result.error = ControlErrorCode::kSafetyBlocked;
            result.action = ControlAction::kBlockExecution;
            return result;
    }

    result.error = ControlErrorCode::kSafetyBlocked;
    result.action = ControlAction::kBlockExecution;
    return result;
}

}  // namespace cupolicy
