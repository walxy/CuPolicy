// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/cuda_graph.hpp"

#if defined(CUPOLICY_HAS_CUDA)

#include <atomic>
#include <mutex>

namespace cupolicy {
namespace {

std::atomic<std::uint64_t> next_graph_id{1};

[[nodiscard]] SafetyEventKind classify_cuda_error(cudaError_t error) noexcept {
    switch (error) {
        case cudaErrorMemoryAllocation:
            return SafetyEventKind::kOutOfMemory;
        case cudaErrorInvalidResourceHandle:
        case cudaErrorStreamCaptureWrongThread:
        case cudaErrorStreamCaptureUnmatched:
        case cudaErrorStreamCaptureUnjoined:
        case cudaErrorStreamCaptureIsolation:
            return SafetyEventKind::kInvalidResource;
        case cudaErrorIllegalAddress:
            return SafetyEventKind::kIllegalAddress;
        case cudaErrorAssert:
        case cudaErrorHardwareStackError:
        case cudaErrorIllegalInstruction:
        case cudaErrorMisalignedAddress:
        case cudaErrorInvalidAddressSpace:
        case cudaErrorInvalidPc:
            return SafetyEventKind::kFatalDeviceFault;
        case cudaErrorLaunchFailure:
        case cudaErrorLaunchTimeout:
        case cudaErrorTensorMemoryLeak:
            return SafetyEventKind::kKernelFailure;
        case cudaErrorContextIsDestroyed:
        case cudaErrorECCUncorrectable:
        case cudaErrorContained:
        case cudaErrorExternalDevice:
            return SafetyEventKind::kDeviceLost;
        default:
            return SafetyEventKind::kTransientRuntimeError;
    }
}

[[nodiscard]] GraphRuntimeStatus status_from_cuda(cudaError_t error,
                                                   GraphRuntimeStatusCode code) noexcept {
    GraphRuntimeStatus result{};
    result.code = code;
    result.cuda_error_code = static_cast<int>(error);
    result.safety_event = classify_cuda_error(error);
    return result;
}


[[nodiscard]] bool is_terminal_safety_event(SafetyEventKind kind) noexcept {
    switch (kind) {
        case SafetyEventKind::kDeviceLost:
        case SafetyEventKind::kIllegalAddress:
        case SafetyEventKind::kKernelFailure:
        case SafetyEventKind::kFatalDeviceFault:
            return true;
        default:
            return false;
    }
}

[[nodiscard]] bool is_valid_eviction_mode(EvictionMode mode) noexcept {
    switch (mode) {
        case EvictionMode::kNonBlocking:
        case EvictionMode::kWaitForCompletion:
            return true;
    }
    return false;
}

[[nodiscard]] bool is_valid_capture_mode(cudaStreamCaptureMode mode) noexcept {
    switch (mode) {
        case cudaStreamCaptureModeGlobal:
        case cudaStreamCaptureModeThreadLocal:
        case cudaStreamCaptureModeRelaxed:
            return true;
    }
    return false;
}

[[nodiscard]] GraphRuntimeStatus preflight_stream(cudaStream_t stream,
                                                   cudaStreamCaptureMode mode,
                                                   bool require_not_capturing) noexcept {
    if (stream == cudaStreamLegacy || !is_valid_capture_mode(mode)) {
        return {GraphRuntimeStatusCode::kInvalidArgument, static_cast<int>(cudaErrorInvalidValue),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }

    if (!require_not_capturing) {
        return {};
    }

    cudaStreamCaptureStatus capture_status = cudaStreamCaptureStatusNone;
    const cudaError_t error = cudaStreamIsCapturing(stream, &capture_status);
    if (error != cudaSuccess) {
        return status_from_cuda(error, GraphRuntimeStatusCode::kCudaError);
    }
    if (capture_status != cudaStreamCaptureStatusNone) {
        return {GraphRuntimeStatusCode::kInvalidArgument, static_cast<int>(cudaSuccess),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }
    return {};
}

[[nodiscard]] GraphRuntimeStatus capture_graph(cudaStream_t stream,
                                               CaptureCallback callback,
                                               void* context,
                                               CaptureOptions options,
                                               cudaGraph_t* graph_out) noexcept {
    if (callback == nullptr || graph_out == nullptr) {
        return {GraphRuntimeStatusCode::kInvalidArgument, static_cast<int>(cudaErrorInvalidValue),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }

    const GraphRuntimeStatus preflight = preflight_stream(stream, options.mode, true);
    if (!preflight.ok()) {
        return preflight;
    }

    const cudaError_t begin_error = cudaStreamBeginCapture(stream, options.mode);
    if (begin_error != cudaSuccess) {
        return status_from_cuda(begin_error, GraphRuntimeStatusCode::kCaptureFailed);
    }

    const cudaError_t callback_error = callback(stream, context);
    cudaGraph_t graph = nullptr;
    const cudaError_t end_error = cudaStreamEndCapture(stream, &graph);

    if (callback_error != cudaSuccess) {
        if (graph != nullptr) {
            (void)cudaGraphDestroy(graph);
        }
        GraphRuntimeStatus result = status_from_cuda(callback_error, GraphRuntimeStatusCode::kCaptureFailed);
        if (!is_terminal_safety_event(result.safety_event)) {
            result.safety_event = SafetyEventKind::kCaptureFailure;
        }
        return result;
    }
    if (end_error != cudaSuccess) {
        if (graph != nullptr) {
            (void)cudaGraphDestroy(graph);
        }
        GraphRuntimeStatus result = status_from_cuda(end_error, GraphRuntimeStatusCode::kCaptureFailed);
        if (!is_terminal_safety_event(result.safety_event)) {
            result.safety_event = SafetyEventKind::kCaptureFailure;
        }
        return result;
    }
    if (graph == nullptr) {
        return {GraphRuntimeStatusCode::kCaptureFailed,
                static_cast<int>(cudaErrorStreamCaptureInvalidated),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }

    std::size_t node_count = 0;
    const cudaError_t node_count_error = cudaGraphGetNodes(graph, nullptr, &node_count);
    if (node_count_error != cudaSuccess) {
        (void)cudaGraphDestroy(graph);
        return status_from_cuda(node_count_error, GraphRuntimeStatusCode::kCudaError);
    }
    if (node_count == 0) {
        (void)cudaGraphDestroy(graph);
        return {GraphRuntimeStatusCode::kCaptureFailed,
                static_cast<int>(cudaErrorInvalidValue),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }

    *graph_out = graph;
    return {};
}

[[nodiscard]] GraphRuntimeStatus instantiate_graph(cudaGraph_t graph,
                                                   cudaGraphExec_t* exec_out) noexcept {
    if (graph == nullptr || exec_out == nullptr) {
        return {GraphRuntimeStatusCode::kInvalidArgument, static_cast<int>(cudaErrorInvalidValue),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }
    cudaGraphExec_t exec = nullptr;
    const cudaError_t error = cudaGraphInstantiate(&exec, graph, nullptr, nullptr, 0);
    if (error != cudaSuccess) {
        return status_from_cuda(error, GraphRuntimeStatusCode::kCudaError);
    }
    *exec_out = exec;
    return {};
}

void destroy_pair(cudaGraph_t& graph, cudaGraphExec_t& exec) noexcept {
    if (exec != nullptr) {
        (void)cudaGraphExecDestroy(exec);
        exec = nullptr;
    }
    if (graph != nullptr) {
        (void)cudaGraphDestroy(graph);
        graph = nullptr;
    }
}

}  // namespace

CudaGraphRuntime::~CudaGraphRuntime() noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    destroy_pair(graph_, exec_);
    capture_stream_ = nullptr;
    graph_id_ = 0;
}

GraphRuntimeStatus CudaGraphRuntime::capture(cudaStream_t stream,
                                             CaptureCallback callback,
                                             void* context,
                                             CaptureOptions options) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (exec_ != nullptr || graph_ != nullptr) {
        return {GraphRuntimeStatusCode::kAlreadyInitialized, static_cast<int>(cudaSuccess),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }

    cudaGraph_t new_graph = nullptr;
    const GraphRuntimeStatus capture_status =
        capture_graph(stream, callback, context, options, &new_graph);
    if (!capture_status.ok()) {
        return capture_status;
    }

    cudaGraphExec_t new_exec = nullptr;
    const GraphRuntimeStatus instantiate_status = instantiate_graph(new_graph, &new_exec);
    if (!instantiate_status.ok()) {
        (void)cudaGraphDestroy(new_graph);
        return instantiate_status;
    }

    graph_ = new_graph;
    exec_ = new_exec;
    capture_stream_ = stream;
    graph_id_ = next_graph_id.fetch_add(1, std::memory_order_relaxed);
    return {};
}

GraphRuntimeStatus CudaGraphRuntime::launch(cudaStream_t stream) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (exec_ == nullptr || graph_ == nullptr) {
        return {GraphRuntimeStatusCode::kNotInitialized, static_cast<int>(cudaSuccess),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }
    if (stream != capture_stream_ || stream == cudaStreamLegacy) {
        return {GraphRuntimeStatusCode::kStreamMismatch, static_cast<int>(cudaSuccess),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }
    const cudaError_t error = cudaGraphLaunch(exec_, stream);
    if (error != cudaSuccess) {
        return status_from_cuda(error, GraphRuntimeStatusCode::kCudaError);
    }
    return {};
}

GraphRuntimeStatus CudaGraphRuntime::update(cudaStream_t stream,
                                            CaptureCallback callback,
                                            void* context,
                                            CaptureOptions options) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (exec_ == nullptr || graph_ == nullptr) {
        return {GraphRuntimeStatusCode::kNotInitialized, static_cast<int>(cudaSuccess),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }
    if (stream != capture_stream_ || stream == cudaStreamLegacy) {
        return {GraphRuntimeStatusCode::kStreamMismatch, static_cast<int>(cudaSuccess),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }

    cudaGraph_t new_graph = nullptr;
    const GraphRuntimeStatus capture_status =
        capture_graph(stream, callback, context, options, &new_graph);
    if (!capture_status.ok()) {
        return capture_status;
    }

    cudaGraphExecUpdateResultInfo info{};
    const cudaError_t error = cudaGraphExecUpdate(exec_, new_graph, &info);
    const int update_result = static_cast<int>(info.result);
    (void)cudaGraphDestroy(new_graph);

    if (error != cudaSuccess) {
        GraphRuntimeStatus result = status_from_cuda(error,
                                                      GraphRuntimeStatusCode::kGraphUpdateRejected);
        result.update_result_code = update_result;
        if (!is_terminal_safety_event(result.safety_event)) {
            result.safety_event = SafetyEventKind::kGraphUpdateRejected;
        }
        return result;
    }

    return {GraphRuntimeStatusCode::kOk,
            static_cast<int>(cudaSuccess),
            update_result};
}

GraphRuntimeStatus CudaGraphRuntime::recapture(cudaStream_t stream,
                                                CaptureCallback callback,
                                                void* context,
                                                CaptureOptions options) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    if (exec_ != nullptr && (stream != capture_stream_ || stream == cudaStreamLegacy)) {
        return {GraphRuntimeStatusCode::kStreamMismatch,
                static_cast<int>(cudaSuccess),
                static_cast<int>(cudaGraphExecUpdateSuccess)};
    }

    cudaGraph_t new_graph = nullptr;
    const GraphRuntimeStatus capture_status =
        capture_graph(stream, callback, context, options, &new_graph);
    if (!capture_status.ok()) {
        return capture_status;
    }

    cudaGraphExec_t new_exec = nullptr;
    const GraphRuntimeStatus instantiate_status = instantiate_graph(new_graph, &new_exec);
    if (!instantiate_status.ok()) {
        (void)cudaGraphDestroy(new_graph);
        return instantiate_status;
    }

    cudaGraph_t old_graph = graph_;
    cudaGraphExec_t old_exec = exec_;
    graph_ = new_graph;
    exec_ = new_exec;
    capture_stream_ = stream;
    graph_id_ = next_graph_id.fetch_add(1, std::memory_order_relaxed);

    destroy_pair(old_graph, old_exec);
    return {};
}

bool CudaGraphRuntime::initialized() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return exec_ != nullptr && graph_ != nullptr;
}

std::uint64_t CudaGraphRuntime::graph_id() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return graph_id_;
}

cudaStream_t CudaGraphRuntime::capture_stream() const noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    return capture_stream_;
}

EvictionResult CudaGraphRuntime::evict(EvictionOptions options) noexcept {
    std::lock_guard<std::mutex> lock(mutex_);
    EvictionResult result{};
    if (!is_valid_eviction_mode(options.mode)) {
        result.status = {GraphRuntimeStatusCode::kInvalidArgument,
                         static_cast<int>(cudaErrorInvalidValue),
                         static_cast<int>(cudaGraphExecUpdateSuccess)};
        return result;
    }
    if (exec_ == nullptr || graph_ == nullptr) {
        result.status = {GraphRuntimeStatusCode::kNotInitialized, static_cast<int>(cudaSuccess),
                         static_cast<int>(cudaGraphExecUpdateSuccess)};
        return result;
    }

    if (options.mode == EvictionMode::kWaitForCompletion) {
        const cudaError_t sync_error = cudaStreamSynchronize(capture_stream_);
        if (sync_error != cudaSuccess) {
            result.status = status_from_cuda(sync_error, GraphRuntimeStatusCode::kCudaError);
            return result;
        }
        result.synchronization_performed = true;
    }

    destroy_pair(graph_, exec_);
    capture_stream_ = nullptr;
    graph_id_ = 0;
    result.status = {GraphRuntimeStatusCode::kOk, static_cast<int>(cudaSuccess),
                     static_cast<int>(cudaGraphExecUpdateSuccess)};
    result.logical_eviction = true;
    result.physical_release_may_be_deferred =
        options.mode == EvictionMode::kNonBlocking;
    return result;
}

}  // namespace cupolicy

#endif
