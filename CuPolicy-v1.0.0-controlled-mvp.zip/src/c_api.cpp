// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/c_api.h"

#include "cupolicy/version.hpp"

const char* cupolicy_version(void) {
    return cupolicy::kVersion.data();
}
