// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/safety.hpp"

#include <limits>

namespace cupolicy {
namespace {

[[nodiscard]] constexpr std::uint64_t saturating_increment(std::uint64_t value) noexcept {
    return value == std::numeric_limits<std::uint64_t>::max() ? value : value + 1;
}

[[nodiscard]] constexpr SafetyDecision decision(SafetyErrorCode error,
                                                SafetyState state,
                                                SafetyAction action,
                                                SafetyEventKind event,
                                                std::uint64_t faults,
                                                bool quarantined) noexcept {
    return {error, state, action, event, faults, quarantined};
}

}  // namespace

SafetyDecision SafetyController::observe(SafetyEvent event) noexcept {
    if (!constraints_.valid()) {
        return decision(SafetyErrorCode::kInvalidConfiguration, state_, SafetyAction::kRequireProcessRestart,
                        event.kind, consecutive_recoverable_faults_, graph_quarantined_);
    }
    if (!is_valid_safety_event(event.kind) || event.kind == SafetyEventKind::kNone) {
        return decision(SafetyErrorCode::kInvalidEvent, state_, SafetyAction::kProceed,
                        event.kind, consecutive_recoverable_faults_, graph_quarantined_);
    }
    if (state_ == SafetyState::kTerminal) {
        return decision(SafetyErrorCode::kTerminalState, state_, SafetyAction::kRequireProcessRestart,
                        event.kind, consecutive_recoverable_faults_, graph_quarantined_);
    }

    switch (event.kind) {
        case SafetyEventKind::kContractViolation:
            consecutive_recoverable_faults_ = 0;
            if (constraints_.quarantine_on_contract_violation) {
                state_ = SafetyState::kQuarantined;
                graph_quarantined_ = true;
                return decision(SafetyErrorCode::kOk, state_, SafetyAction::kQuarantineGraph,
                                event.kind, consecutive_recoverable_faults_, graph_quarantined_);
            }
            state_ = SafetyState::kDegraded;
            return decision(SafetyErrorCode::kOk, state_, SafetyAction::kFallbackEager,
                            event.kind, consecutive_recoverable_faults_, graph_quarantined_);

        case SafetyEventKind::kDeviceLost:
        case SafetyEventKind::kIllegalAddress:
        case SafetyEventKind::kKernelFailure:
        case SafetyEventKind::kFatalDeviceFault:
            state_ = SafetyState::kTerminal;
            graph_quarantined_ = true;
            consecutive_recoverable_faults_ = 0;
            return decision(SafetyErrorCode::kOk, state_, SafetyAction::kRequireProcessRestart,
                            event.kind, consecutive_recoverable_faults_, graph_quarantined_);

        case SafetyEventKind::kUnknownRuntimeError:
            state_ = SafetyState::kQuarantined;
            graph_quarantined_ = true;
            consecutive_recoverable_faults_ = 0;
            return decision(SafetyErrorCode::kOk, state_, SafetyAction::kQuarantineGraph,
                            event.kind, consecutive_recoverable_faults_, graph_quarantined_);

        case SafetyEventKind::kGraphUpdateRejected:
        case SafetyEventKind::kCaptureFailure:
        case SafetyEventKind::kTransientRuntimeError:
        case SafetyEventKind::kOutOfMemory:
        case SafetyEventKind::kInvalidResource: {
            consecutive_recoverable_faults_ = saturating_increment(consecutive_recoverable_faults_);
            if (consecutive_recoverable_faults_ >= constraints_.max_consecutive_recoverable_faults) {
                state_ = SafetyState::kQuarantined;
                graph_quarantined_ = true;
                return decision(SafetyErrorCode::kOk, state_, SafetyAction::kQuarantineGraph,
                                event.kind, consecutive_recoverable_faults_, graph_quarantined_);
            }
            state_ = SafetyState::kDegraded;
            return decision(SafetyErrorCode::kOk, state_, SafetyAction::kFallbackEager,
                            event.kind, consecutive_recoverable_faults_, graph_quarantined_);
        }
        case SafetyEventKind::kNone:
            break;
    }

    return decision(SafetyErrorCode::kInvalidEvent, state_, SafetyAction::kProceed,
                    event.kind, consecutive_recoverable_faults_, graph_quarantined_);
}

SafetyDecision SafetyController::recover() noexcept {
    if (state_ == SafetyState::kTerminal) {
        return decision(SafetyErrorCode::kTerminalState, state_, SafetyAction::kRequireProcessRestart,
                        SafetyEventKind::kNone, consecutive_recoverable_faults_, graph_quarantined_);
    }
    if (state_ == SafetyState::kQuarantined || graph_quarantined_) {
        return decision(SafetyErrorCode::kOk, state_, SafetyAction::kQuarantineGraph,
                        SafetyEventKind::kNone, consecutive_recoverable_faults_, graph_quarantined_);
    }
    state_ = SafetyState::kHealthy;
    consecutive_recoverable_faults_ = 0;
    return decision(SafetyErrorCode::kOk, state_, SafetyAction::kProceed,
                    SafetyEventKind::kNone, consecutive_recoverable_faults_, graph_quarantined_);
}

SafetyDecision SafetyController::clear_quarantine() noexcept {
    if (state_ == SafetyState::kTerminal) {
        return decision(SafetyErrorCode::kTerminalState, state_, SafetyAction::kRequireProcessRestart,
                        SafetyEventKind::kNone, consecutive_recoverable_faults_, graph_quarantined_);
    }
    graph_quarantined_ = false;
    state_ = SafetyState::kHealthy;
    consecutive_recoverable_faults_ = 0;
    return decision(SafetyErrorCode::kOk, state_, SafetyAction::kProceed,
                    SafetyEventKind::kNone, consecutive_recoverable_faults_, graph_quarantined_);
}

}  // namespace cupolicy
