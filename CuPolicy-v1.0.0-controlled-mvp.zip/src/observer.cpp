// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/observation.hpp"

#include <utility>

namespace cupolicy {

Observer::Scope::Scope(Observer* observer,
                       std::uint64_t operation_id,
                       std::uint64_t stream_id,
                       std::uint64_t sequence,
                       TimePoint start) noexcept
    : observer_(observer),
      operation_id_(operation_id),
      stream_id_(stream_id),
      sequence_(sequence),
      start_(start),
      active_(true) {}

Observer::Scope::Scope(Scope&& other) noexcept
    : observer_(other.observer_),
      operation_id_(other.operation_id_),
      stream_id_(other.stream_id_),
      sequence_(other.sequence_),
      start_(other.start_),
      active_(other.active_) {
    other.observer_ = nullptr;
    other.active_ = false;
}

Observer::Scope& Observer::Scope::operator=(Scope&& other) noexcept {
    if (this != &other) {
        finish();
        observer_ = other.observer_;
        operation_id_ = other.operation_id_;
        stream_id_ = other.stream_id_;
        sequence_ = other.sequence_;
        start_ = other.start_;
        active_ = other.active_;
        other.observer_ = nullptr;
        other.active_ = false;
    }
    return *this;
}

Observer::Scope::~Scope() {
    finish();
}

void Observer::Scope::finish() noexcept {
    if (!active_) {
        return;
    }

    const auto end = Clock::now();
    const auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start_);
    const auto duration_count = duration.count();
    const auto duration_ns = duration_count >= 0
                                 ? static_cast<std::uint64_t>(duration_count)
                                 : std::uint64_t{0};

    observer_->record(ObservationSample{
        operation_id_,
        stream_id_,
        sequence_,
        duration_ns,
    });
    observer_ = nullptr;
    active_ = false;
}

Observer::Observer(ObserverConfig config,
                   ObservationSink sink,
                   void* sink_context) noexcept
    : config_(config), sink_(sink), sink_context_(sink_context) {
    if (config_.mode == ObservationMode::kSampled && config_.sample_every == 0) {
        config_.sample_every = 1;
    }
}

Observer::Scope Observer::begin(std::uint64_t operation_id,
                                std::uint64_t stream_id) noexcept {
    if (config_.mode == ObservationMode::kDisabled) {
        return {};
    }

    const auto sequence = atomic_increment_saturating(events_seen_);
    const auto should_sample = config_.mode == ObservationMode::kFull ||
                                ((sequence - 1) % config_.sample_every == 0);
    if (!should_sample) {
        return {};
    }

    return Scope(this,
                 operation_id,
                 stream_id,
                 sequence,
                 Scope::Clock::now());
}

ObserverSnapshot Observer::snapshot() const noexcept {
    return {
        events_seen_.load(std::memory_order_relaxed),
        samples_recorded_.load(std::memory_order_relaxed),
        total_cpu_duration_ns_.load(std::memory_order_relaxed),
        max_cpu_duration_ns_.load(std::memory_order_relaxed),
        last_cpu_duration_ns_.load(std::memory_order_relaxed),
    };
}

void Observer::record(const ObservationSample& sample) noexcept {
    atomic_increment_saturating(samples_recorded_);

    auto current = total_cpu_duration_ns_.load(std::memory_order_relaxed);
    auto desired = saturating_add(current, sample.cpu_duration_ns);
    while (!total_cpu_duration_ns_.compare_exchange_weak(
        current,
        desired,
        std::memory_order_relaxed,
        std::memory_order_relaxed)) {
        desired = saturating_add(current, sample.cpu_duration_ns);
    }

    atomic_max(max_cpu_duration_ns_, sample.cpu_duration_ns);
    last_cpu_duration_ns_.store(sample.cpu_duration_ns, std::memory_order_relaxed);

    if (sink_ != nullptr) {
        sink_(sample, sink_context_);
    }
}

std::uint64_t Observer::saturating_add(std::uint64_t lhs, std::uint64_t rhs) noexcept {
    constexpr auto max_value = std::numeric_limits<std::uint64_t>::max();
    if (lhs > max_value - rhs) {
        return max_value;
    }
    return lhs + rhs;
}


std::uint64_t Observer::atomic_increment_saturating(
    std::atomic<std::uint64_t>& target) noexcept {
    auto current = target.load(std::memory_order_relaxed);
    constexpr auto max_value = std::numeric_limits<std::uint64_t>::max();
    for (;;) {
        if (current == max_value) {
            return max_value;
        }

        const auto desired = current + 1;
        if (target.compare_exchange_weak(current,
                                          desired,
                                          std::memory_order_relaxed,
                                          std::memory_order_relaxed)) {
            return desired;
        }
    }
}

void Observer::atomic_max(std::atomic<std::uint64_t>& target, std::uint64_t value) noexcept {
    auto current = target.load(std::memory_order_relaxed);
    while (current < value &&
           !target.compare_exchange_weak(current,
                                         value,
                                         std::memory_order_relaxed,
                                         std::memory_order_relaxed)) {
    }
}

}  // namespace cupolicy
