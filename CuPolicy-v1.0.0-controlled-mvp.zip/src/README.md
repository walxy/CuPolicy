# Runtime source

The v0.1 foundation contains only the C ABI version bridge. CUDA runtime implementation is intentionally deferred.
