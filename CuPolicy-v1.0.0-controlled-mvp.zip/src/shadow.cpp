// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/shadow.hpp"

#include <limits>
#include <sstream>

namespace cupolicy {
namespace {

[[nodiscard]] constexpr std::uint64_t saturating_add_local(std::uint64_t lhs,
                                                            std::uint64_t rhs) noexcept {
    constexpr auto max_value = std::numeric_limits<std::uint64_t>::max();
    return lhs > max_value - rhs ? max_value : lhs + rhs;
}

}  // namespace

ShadowTraceRecorder::ShadowTraceRecorder(std::uint64_t max_entries) {
    entries_.reserve(static_cast<std::size_t>(max_entries));
}

bool ShadowTraceRecorder::record(const ShadowObservation& observation) {
    if (entries_.size() >= entries_.capacity()) {
        if (dropped_ != std::numeric_limits<std::uint64_t>::max()) {
            ++dropped_;
        }
        return false;
    }
    entries_.push_back(observation);
    return true;
}

std::span<const ShadowObservation> ShadowTraceRecorder::entries() const noexcept {
    return std::span<const ShadowObservation>(entries_.data(), entries_.size());
}

ShadowController::ShadowController(ShadowConfig config)
    : config_(config), recorder_(config.max_trace_entries) {
    if (!config_.valid()) {
        config_ = ShadowConfig{ShadowMode::kOff, 1};
        recorder_ = ShadowTraceRecorder(config_.max_trace_entries);
    }
}

bool ShadowController::is_baseline_mode_valid(ExecutionMode mode) noexcept {
    return mode == ExecutionMode::kEager || mode == ExecutionMode::kGraph;
}

std::uint64_t ShadowController::saturating_add(std::uint64_t lhs,
                                               std::uint64_t rhs) noexcept {
    return saturating_add_local(lhs, rhs);
}

ShadowEvaluation ShadowController::evaluate(const PolicyCandidate& candidate,
                                             const PolicyConstraints& constraints) noexcept {
    ShadowEvaluation result{};
    if (config_.mode == ShadowMode::kOff) {
        result.comparison = ShadowComparisonReason::kNotEvaluated;
        return result;
    }

    if (!is_baseline_mode_valid(candidate.current_mode)) {
        result.comparison = ShadowComparisonReason::kPolicyCouldNotEvaluate;
        update_report(candidate, result);
        return result;
    }

    if (config_.mode == ShadowMode::kObserve) {
        result.proposed_decision =
            ExecutionDecision{candidate.current_mode, 0, DecisionReason::kDefault};
        result.comparison = ShadowComparisonReason::kNotEvaluated;
        result.evaluated = false;
        update_report(candidate, result);
        return result;
    }

    const PolicyEvaluation evaluation = PolicyEvaluator::evaluate(candidate, constraints);
    result.proposed_decision = evaluation.decision;
    result.evaluated = true;
    result.estimated_policy_benefit_ns =
        evaluation.decision.mode == ExecutionMode::kGraph ? evaluation.estimated_net_benefit_ns : 0;

    if (evaluation.decision.mode == candidate.current_mode) {
        result.comparison = ShadowComparisonReason::kAgreement;
    } else if (evaluation.decision.mode == ExecutionMode::kGraph &&
               candidate.current_mode == ExecutionMode::kEager) {
        result.comparison = ShadowComparisonReason::kPolicyWouldPreferGraph;
        result.estimated_regret_ns = evaluation.estimated_net_benefit_ns;
    } else if (evaluation.decision.mode == ExecutionMode::kEager &&
               candidate.current_mode == ExecutionMode::kGraph) {
        result.comparison = ShadowComparisonReason::kPolicyWouldPreferEager;
        // v0.9 does not monetize constrained/safety-rejected graph execution as “regret”.
        // The model benefit may be positive even when graph execution is unsafe or over budget.
        result.estimated_regret_ns = 0;
    } else {
        result.comparison = ShadowComparisonReason::kPolicyCouldNotEvaluate;
    }

    // Critical v0.9 invariant: shadow mode never changes the caller's execution mode.
    result.intervention_performed = false;
    update_report(candidate, result);
    return result;
}

void ShadowController::update_report(const PolicyCandidate& candidate,
                                     const ShadowEvaluation& evaluation) noexcept {
    if (report_.observations != std::numeric_limits<std::uint64_t>::max()) {
        ++report_.observations;
    }
    if (evaluation.evaluated) {
        if (report_.evaluated != std::numeric_limits<std::uint64_t>::max()) {
            ++report_.evaluated;
        }
    }

    if (candidate.current_mode == ExecutionMode::kGraph) {
        if (report_.baseline_graph_decisions != std::numeric_limits<std::uint64_t>::max()) {
            ++report_.baseline_graph_decisions;
        }
    } else if (candidate.current_mode == ExecutionMode::kEager) {
        if (report_.baseline_eager_decisions != std::numeric_limits<std::uint64_t>::max()) {
            ++report_.baseline_eager_decisions;
        }
    }

    if (evaluation.proposed_decision.mode == ExecutionMode::kGraph) {
        if (report_.policy_graph_decisions != std::numeric_limits<std::uint64_t>::max()) {
            ++report_.policy_graph_decisions;
        }
    } else if (evaluation.evaluated &&
               report_.policy_eager_decisions != std::numeric_limits<std::uint64_t>::max()) {
        ++report_.policy_eager_decisions;
    }

    switch (evaluation.comparison) {
        case ShadowComparisonReason::kAgreement:
            if (report_.agreements != std::numeric_limits<std::uint64_t>::max()) {
                ++report_.agreements;
            }
            break;
        case ShadowComparisonReason::kPolicyWouldPreferGraph:
            if (report_.policy_would_prefer_graph != std::numeric_limits<std::uint64_t>::max()) {
                ++report_.policy_would_prefer_graph;
            }
            break;
        case ShadowComparisonReason::kPolicyWouldPreferEager:
            if (report_.policy_would_prefer_eager != std::numeric_limits<std::uint64_t>::max()) {
                ++report_.policy_would_prefer_eager;
            }
            break;
        case ShadowComparisonReason::kPolicyCouldNotEvaluate:
            if (report_.policy_could_not_evaluate != std::numeric_limits<std::uint64_t>::max()) {
                ++report_.policy_could_not_evaluate;
            }
            break;
        case ShadowComparisonReason::kNotEvaluated:
            break;
    }

    report_.estimated_policy_benefit_ns =
        saturating_add(report_.estimated_policy_benefit_ns, evaluation.estimated_policy_benefit_ns);
    report_.estimated_regret_ns =
        saturating_add(report_.estimated_regret_ns, evaluation.estimated_regret_ns);

    ShadowObservation observation{
        next_sequence_,
        candidate.observation.capture_definition_id,
        candidate.current_mode,
        evaluation.proposed_decision,
        evaluation.comparison,
        evaluation.estimated_policy_benefit_ns,
        evaluation.estimated_regret_ns,
    };
    if (recorder_.record(observation)) {
        if (report_.trace_entries != std::numeric_limits<std::uint64_t>::max()) {
            ++report_.trace_entries;
        }
    } else {
        report_.trace_dropped = recorder_.dropped();
    }

    if (next_sequence_ != std::numeric_limits<std::uint64_t>::max()) {
        ++next_sequence_;
    }
}

ShadowReport ShadowController::replay(std::span<const PolicyCandidate> candidates,
                                       const PolicyConstraints& constraints) noexcept {
    for (const PolicyCandidate& candidate : candidates) {
        (void)evaluate(candidate, constraints);
    }
    return report_;
}

std::string ShadowController::report_json() const {
    std::ostringstream output;
    output << "{\n"
           << "  \"mode\": \"" << to_string(config_.mode) << "\",\n"
           << "  \"intervention_performed\": false,\n"
           << "  \"observations\": " << report_.observations << ",\n"
           << "  \"evaluated\": " << report_.evaluated << ",\n"
           << "  \"policy_graph_decisions\": " << report_.policy_graph_decisions << ",\n"
           << "  \"policy_eager_decisions\": " << report_.policy_eager_decisions << ",\n"
           << "  \"baseline_graph_decisions\": " << report_.baseline_graph_decisions << ",\n"
           << "  \"baseline_eager_decisions\": " << report_.baseline_eager_decisions << ",\n"
           << "  \"agreements\": " << report_.agreements << ",\n"
           << "  \"policy_would_prefer_graph\": " << report_.policy_would_prefer_graph << ",\n"
           << "  \"policy_would_prefer_eager\": " << report_.policy_would_prefer_eager << ",\n"
           << "  \"policy_could_not_evaluate\": " << report_.policy_could_not_evaluate << ",\n"
           << "  \"estimated_policy_benefit_ns\": " << report_.estimated_policy_benefit_ns << ",\n"
           << "  \"estimated_regret_ns\": " << report_.estimated_regret_ns << ",\n"
           << "  \"trace_entries\": " << report_.trace_entries << ",\n"
           << "  \"trace_dropped\": " << report_.trace_dropped << "\n"
           << "}\n";
    return output.str();
}

}  // namespace cupolicy
