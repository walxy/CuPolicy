// SPDX-License-Identifier: Apache-2.0
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

const char* cupolicy_version(void);

#ifdef __cplusplus
}
#endif
