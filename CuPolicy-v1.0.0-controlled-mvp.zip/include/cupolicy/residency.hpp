// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <limits>
#include <optional>
#include <span>
#include <string_view>
#include <vector>

namespace cupolicy {

enum class ResidencyDecisionReason : std::uint8_t {
    kAccepted = 0,
    kAlreadyResident,
    kReplacementRequired,
    kCandidateTooLarge,
    kGraphCountBudget,
    kPinnedOnly,
    kEvictionRequired,
    kInvalidDefinition,
    kInvalidConstraints,
};

constexpr std::string_view to_string(ResidencyDecisionReason reason) noexcept {
    switch (reason) {
        case ResidencyDecisionReason::kAccepted:
            return "ACCEPTED";
        case ResidencyDecisionReason::kAlreadyResident:
            return "ALREADY_RESIDENT";
        case ResidencyDecisionReason::kReplacementRequired:
            return "REPLACEMENT_REQUIRED";
        case ResidencyDecisionReason::kCandidateTooLarge:
            return "CANDIDATE_TOO_LARGE";
        case ResidencyDecisionReason::kGraphCountBudget:
            return "GRAPH_COUNT_BUDGET";
        case ResidencyDecisionReason::kPinnedOnly:
            return "PINNED_ONLY";
        case ResidencyDecisionReason::kEvictionRequired:
            return "EVICTION_REQUIRED";
        case ResidencyDecisionReason::kInvalidDefinition:
            return "INVALID_DEFINITION";
        case ResidencyDecisionReason::kInvalidConstraints:
            return "INVALID_CONSTRAINTS";
    }
    return "UNKNOWN";
}

struct ResidencyConstraints final {
    std::uint64_t max_graphs{std::numeric_limits<std::uint64_t>::max()};
    std::uint64_t max_graph_bytes{std::numeric_limits<std::uint64_t>::max()};

    [[nodiscard]] constexpr bool valid() const noexcept { return max_graphs != 0; }
};

struct ResidentGraph final {
    std::uint64_t capture_definition_id{0};
    std::uint64_t graph_id{0};
    std::uint64_t memory_bytes{0};
    std::uint64_t last_used_tick{0};
    std::uint32_t pin_count{0};
};

struct EvictionTarget final {
    std::uint64_t capture_definition_id{0};
    std::uint64_t graph_id{0};
    std::uint64_t memory_bytes{0};
};

struct ResidencyDecision final {
    bool admissible{false};
    ResidencyDecisionReason reason{ResidencyDecisionReason::kInvalidDefinition};
    std::uint64_t projected_graphs{0};
    std::uint64_t projected_graph_bytes{0};
    std::optional<EvictionTarget> eviction{};
    std::optional<ResidentGraph> replacement{};
};

// Host-side deterministic residency bookkeeping. It does not destroy CUDA resources; a caller
// must successfully perform the selected physical eviction before removing that entry and then
// re-run admission. This one-eviction-at-a-time protocol avoids partial multi-eviction state.
class ResidencyController final {
public:
    explicit ResidencyController(ResidencyConstraints constraints = {}) noexcept
        : constraints_(constraints) {}

    [[nodiscard]] constexpr const ResidencyConstraints& constraints() const noexcept {
        return constraints_;
    }

    [[nodiscard]] std::size_t size() const noexcept { return entries_.size(); }
    [[nodiscard]] std::uint64_t resident_bytes() const noexcept { return resident_bytes_; }
    [[nodiscard]] bool contains(std::uint64_t capture_definition_id) const noexcept;
    [[nodiscard]] std::optional<ResidentGraph> find(
        std::uint64_t capture_definition_id) const noexcept;

    // Returns a deterministic LRU eviction target, excluding pinned entries. Ties are broken by
    // graph id and then capture definition id so the result is reproducible.
    [[nodiscard]] std::optional<EvictionTarget> next_eviction() const noexcept;

    // Admission only inspects metadata. If it returns an eviction target, the caller must perform
    // that physical eviction and call remove() successfully before retrying admission.
    [[nodiscard]] ResidencyDecision evaluate(std::uint64_t capture_definition_id,
                                             std::uint64_t graph_id,
                                             std::uint64_t memory_bytes) const noexcept;

    // Mutations are explicit so physical CUDA lifecycle success can be acknowledged first.
    [[nodiscard]] bool admit(std::uint64_t capture_definition_id,
                             std::uint64_t graph_id,
                             std::uint64_t memory_bytes);

    // A replacement acknowledges that a successfully recaptured/updated runtime generation has
    // superseded the existing entry. It cannot change a pinned entry and must fit the residency
    // limits after accounting for the old generation being retired.
    [[nodiscard]] bool replace(std::uint64_t capture_definition_id,
                               std::uint64_t graph_id,
                               std::uint64_t memory_bytes);

    [[nodiscard]] bool remove(std::uint64_t capture_definition_id) noexcept;
    [[nodiscard]] bool touch(std::uint64_t capture_definition_id) noexcept;
    [[nodiscard]] bool pin(std::uint64_t capture_definition_id) noexcept;
    [[nodiscard]] bool unpin(std::uint64_t capture_definition_id) noexcept;

private:
    [[nodiscard]] static bool less_for_eviction(const ResidentGraph& lhs,
                                                const ResidentGraph& rhs) noexcept;
    [[nodiscard]] bool would_fit(std::uint64_t graph_count,
                                 std::uint64_t graph_bytes) const noexcept;

    ResidencyConstraints constraints_{};
    std::vector<ResidentGraph> entries_{};
    std::uint64_t resident_bytes_{0};
    std::uint64_t next_tick_{1};
};

}  // namespace cupolicy
