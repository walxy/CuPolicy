// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <string_view>

namespace cupolicy {

enum class StatusCode {
    kOk = 0,
    kInvalidArgument,
    kNotInitialized,
    kNotSupported,
    kExternalFailure,
    kInternalError,
};

constexpr std::string_view to_string(StatusCode code) noexcept {
    switch (code) {
        case StatusCode::kOk:
            return "OK";
        case StatusCode::kInvalidArgument:
            return "INVALID_ARGUMENT";
        case StatusCode::kNotInitialized:
            return "NOT_INITIALIZED";
        case StatusCode::kNotSupported:
            return "NOT_SUPPORTED";
        case StatusCode::kExternalFailure:
            return "EXTERNAL_FAILURE";
        case StatusCode::kInternalError:
            return "INTERNAL_ERROR";
    }
    return "UNKNOWN";
}

class Status {
public:
    constexpr Status() noexcept = default;
    explicit constexpr Status(StatusCode code) noexcept : code_(code) {}

    [[nodiscard]] constexpr bool ok() const noexcept { return code_ == StatusCode::kOk; }
    [[nodiscard]] constexpr StatusCode code() const noexcept { return code_; }
    [[nodiscard]] constexpr std::string_view message() const noexcept { return to_string(code_); }

private:
    StatusCode code_{StatusCode::kOk};
};

}  // namespace cupolicy
