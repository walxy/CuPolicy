// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <algorithm>
#include <cstdint>
#include <initializer_list>
#include <span>
#include <utility>
#include <vector>

namespace cupolicy {

struct WorkloadSignature final {
    std::vector<std::uint64_t> shape{};

    WorkloadSignature() = default;
    explicit WorkloadSignature(std::vector<std::uint64_t> shape_values)
        : shape(std::move(shape_values)) {}
    WorkloadSignature(std::initializer_list<std::uint64_t> shape_values) : shape(shape_values) {}

    [[nodiscard]] bool operator==(const WorkloadSignature&) const = default;

    [[nodiscard]] bool empty() const noexcept { return shape.empty(); }
    [[nodiscard]] std::span<const std::uint64_t> dimensions() const noexcept { return shape; }
};

[[nodiscard]] constexpr bool same_shape(
    const WorkloadSignature& lhs,
    const WorkloadSignature& rhs) noexcept {
    return std::ranges::equal(lhs.shape, rhs.shape);
}

}  // namespace cupolicy
