// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <string_view>

namespace cupolicy {

enum class ExecutionMode {
    kEager = 0,
    kGraph,
    kPiecewise,
    kUpdate,
    kRecapture,
    kFallback,
};

constexpr std::string_view to_string(ExecutionMode mode) noexcept {
    switch (mode) {
        case ExecutionMode::kEager:
            return "EAGER";
        case ExecutionMode::kGraph:
            return "GRAPH";
        case ExecutionMode::kPiecewise:
            return "PIECEWISE";
        case ExecutionMode::kUpdate:
            return "UPDATE";
        case ExecutionMode::kRecapture:
            return "RECAPTURE";
        case ExecutionMode::kFallback:
            return "FALLBACK";
    }
    return "UNKNOWN";
}

enum class DecisionReason {
    kUnspecified = 0,
    kDefault,
    kInsufficientEvidence,
    kInvalidCandidate,
    kUnsafeContract,
    kGraphUnavailable,
    kInsufficientReuse,
    kMemoryBudget,
    kNonPositiveBenefit,
    kNotAmortized,
    kBelowBenefitThreshold,
    kNotEnoughConfidence,
    kHysteresisRetained,
    kVariantBudget,
    kRuntimeFailure,
    kEvicted,
    kCandidateAccepted,
};

constexpr std::string_view to_string(DecisionReason reason) noexcept {
    switch (reason) {
        case DecisionReason::kUnspecified:
            return "UNSPECIFIED";
        case DecisionReason::kDefault:
            return "DEFAULT";
        case DecisionReason::kInsufficientEvidence:
            return "INSUFFICIENT_EVIDENCE";
        case DecisionReason::kInvalidCandidate:
            return "INVALID_CANDIDATE";
        case DecisionReason::kUnsafeContract:
            return "UNSAFE_CONTRACT";
        case DecisionReason::kGraphUnavailable:
            return "GRAPH_UNAVAILABLE";
        case DecisionReason::kInsufficientReuse:
            return "INSUFFICIENT_REUSE";
        case DecisionReason::kMemoryBudget:
            return "MEMORY_BUDGET";
        case DecisionReason::kNonPositiveBenefit:
            return "NON_POSITIVE_BENEFIT";
        case DecisionReason::kNotAmortized:
            return "NOT_AMORTIZED";
        case DecisionReason::kBelowBenefitThreshold:
            return "BELOW_BENEFIT_THRESHOLD";
        case DecisionReason::kNotEnoughConfidence:
            return "NOT_ENOUGH_CONFIDENCE";
        case DecisionReason::kHysteresisRetained:
            return "HYSTERESIS_RETAINED";
        case DecisionReason::kVariantBudget:
            return "VARIANT_BUDGET";
        case DecisionReason::kRuntimeFailure:
            return "RUNTIME_FAILURE";
        case DecisionReason::kEvicted:
            return "EVICTED";
        case DecisionReason::kCandidateAccepted:
            return "CANDIDATE_ACCEPTED";
    }
    return "UNKNOWN";
}

struct ExecutionDecision {
    ExecutionMode mode{ExecutionMode::kEager};
    std::uint64_t graph_id{0};
    DecisionReason reason{DecisionReason::kUnspecified};
};

}  // namespace cupolicy
