// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <limits>
#include <string_view>

namespace cupolicy {

enum class SafetyState : std::uint8_t {
    kHealthy = 0,
    kDegraded,
    kQuarantined,
    kTerminal,
};

constexpr std::string_view to_string(SafetyState state) noexcept {
    switch (state) {
        case SafetyState::kHealthy: return "HEALTHY";
        case SafetyState::kDegraded: return "DEGRADED";
        case SafetyState::kQuarantined: return "QUARANTINED";
        case SafetyState::kTerminal: return "TERMINAL";
    }
    return "UNKNOWN";
}

enum class SafetyEventKind : std::uint8_t {
    kNone = 0,
    kContractViolation,
    kGraphUpdateRejected,
    kCaptureFailure,
    kTransientRuntimeError,
    kOutOfMemory,
    kInvalidResource,
    kDeviceLost,
    kIllegalAddress,
    kKernelFailure,
    kFatalDeviceFault,
    kUnknownRuntimeError,
};

constexpr std::string_view to_string(SafetyEventKind kind) noexcept {
    switch (kind) {
        case SafetyEventKind::kNone: return "NONE";
        case SafetyEventKind::kContractViolation: return "CONTRACT_VIOLATION";
        case SafetyEventKind::kGraphUpdateRejected: return "GRAPH_UPDATE_REJECTED";
        case SafetyEventKind::kCaptureFailure: return "CAPTURE_FAILURE";
        case SafetyEventKind::kTransientRuntimeError: return "TRANSIENT_RUNTIME_ERROR";
        case SafetyEventKind::kOutOfMemory: return "OUT_OF_MEMORY";
        case SafetyEventKind::kInvalidResource: return "INVALID_RESOURCE";
        case SafetyEventKind::kDeviceLost: return "DEVICE_LOST";
        case SafetyEventKind::kIllegalAddress: return "ILLEGAL_ADDRESS";
        case SafetyEventKind::kKernelFailure: return "KERNEL_FAILURE";
        case SafetyEventKind::kFatalDeviceFault: return "FATAL_DEVICE_FAULT";
        case SafetyEventKind::kUnknownRuntimeError: return "UNKNOWN_RUNTIME_ERROR";
    }
    return "UNKNOWN";
}

enum class SafetyAction : std::uint8_t {
    kProceed = 0,
    kFallbackEager,
    kQuarantineGraph,
    kRequireProcessRestart,
};

constexpr std::string_view to_string(SafetyAction action) noexcept {
    switch (action) {
        case SafetyAction::kProceed: return "PROCEED";
        case SafetyAction::kFallbackEager: return "FALLBACK_EAGER";
        case SafetyAction::kQuarantineGraph: return "QUARANTINE_GRAPH";
        case SafetyAction::kRequireProcessRestart: return "REQUIRE_PROCESS_RESTART";
    }
    return "UNKNOWN";
}

enum class SafetyErrorCode : std::uint8_t {
    kOk = 0,
    kInvalidConfiguration,
    kInvalidEvent,
    kTerminalState,
};

struct SafetyConstraints final {
    // Number of consecutive recoverable runtime faults before the controller quarantines the graph.
    std::uint64_t max_consecutive_recoverable_faults{3};
    bool quarantine_on_contract_violation{true};

    [[nodiscard]] constexpr bool valid() const noexcept {
        return max_consecutive_recoverable_faults != 0;
    }
};

struct SafetyEvent final {
    SafetyEventKind kind{SafetyEventKind::kNone};
    std::int32_t external_error_code{0};
    std::uint64_t graph_id{0};
};

struct SafetyDecision final {
    SafetyErrorCode error{SafetyErrorCode::kOk};
    SafetyState state{SafetyState::kHealthy};
    SafetyAction action{SafetyAction::kProceed};
    SafetyEventKind event{SafetyEventKind::kNone};
    std::uint64_t consecutive_recoverable_faults{0};
    bool graph_quarantined{false};

    [[nodiscard]] constexpr bool ok() const noexcept { return error == SafetyErrorCode::kOk; }
};

[[nodiscard]] constexpr bool is_valid_safety_event(SafetyEventKind kind) noexcept {
    return static_cast<std::uint8_t>(kind) <=
           static_cast<std::uint8_t>(SafetyEventKind::kUnknownRuntimeError);
}

class SafetyController final {
public:
    explicit SafetyController(SafetyConstraints constraints = {}) noexcept
        : constraints_(constraints) {}

    [[nodiscard]] constexpr const SafetyConstraints& constraints() const noexcept {
        return constraints_;
    }
    [[nodiscard]] constexpr SafetyState state() const noexcept { return state_; }
    [[nodiscard]] constexpr std::uint64_t consecutive_recoverable_faults() const noexcept {
        return consecutive_recoverable_faults_;
    }
    [[nodiscard]] constexpr bool graph_quarantined() const noexcept {
        return graph_quarantined_;
    }

    [[nodiscard]] SafetyDecision observe(SafetyEvent event) noexcept;
    // Explicit operator-controlled recovery. This never clears a terminal state.
    [[nodiscard]] SafetyDecision recover() noexcept;
    // Clears the controller only after an external lifecycle reset has occurred. This does not
    // perform cudaDeviceReset() or otherwise mutate global CUDA state.
    [[nodiscard]] SafetyDecision clear_quarantine() noexcept;

private:
    SafetyConstraints constraints_{};
    SafetyState state_{SafetyState::kHealthy};
    std::uint64_t consecutive_recoverable_faults_{0};
    bool graph_quarantined_{false};
};

}  // namespace cupolicy
