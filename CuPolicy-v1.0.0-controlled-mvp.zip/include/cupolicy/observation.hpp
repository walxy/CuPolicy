// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <limits>
#include <string_view>

namespace cupolicy {

enum class ObservationMode {
    kDisabled = 0,
    kSampled,
    kFull,
};

constexpr std::string_view to_string(ObservationMode mode) noexcept {
    switch (mode) {
        case ObservationMode::kDisabled:
            return "DISABLED";
        case ObservationMode::kSampled:
            return "SAMPLED";
        case ObservationMode::kFull:
            return "FULL";
    }
    return "UNKNOWN";
}

struct ObserverConfig {
    ObservationMode mode{ObservationMode::kDisabled};
    std::uint32_t sample_every{1};
};

struct ObservationSample {
    std::uint64_t operation_id{0};
    std::uint64_t stream_id{0};
    std::uint64_t sequence{0};
    std::uint64_t cpu_duration_ns{0};
};

using ObservationSink = void (*)(const ObservationSample&, void* context) noexcept;

struct ObserverSnapshot {
    std::uint64_t events_seen{0};
    std::uint64_t samples_recorded{0};
    std::uint64_t total_cpu_duration_ns{0};
    std::uint64_t max_cpu_duration_ns{0};
    std::uint64_t last_cpu_duration_ns{0};
};

class Observer final {
public:
    class Scope final {
    public:
        Scope() noexcept = default;
        Scope(const Scope&) = delete;
        Scope& operator=(const Scope&) = delete;
        Scope(Scope&& other) noexcept;
        Scope& operator=(Scope&& other) noexcept;
        ~Scope();

    private:
        friend class Observer;

        using Clock = std::chrono::steady_clock;
        using TimePoint = Clock::time_point;

        Scope(Observer* observer,
              std::uint64_t operation_id,
              std::uint64_t stream_id,
              std::uint64_t sequence,
              TimePoint start) noexcept;
        void finish() noexcept;

        Observer* observer_{nullptr};
        std::uint64_t operation_id_{0};
        std::uint64_t stream_id_{0};
        std::uint64_t sequence_{0};
        TimePoint start_{};
        bool active_{false};
    };

    explicit Observer(ObserverConfig config = {},
                      ObservationSink sink = nullptr,
                      void* sink_context = nullptr) noexcept;

    Observer(const Observer&) = delete;
    Observer& operator=(const Observer&) = delete;
    Observer(Observer&&) = delete;
    Observer& operator=(Observer&&) = delete;
    ~Observer() = default;

    [[nodiscard]] Scope begin(std::uint64_t operation_id,
                              std::uint64_t stream_id = 0) noexcept;

    // Returns independently atomic aggregate values. Under concurrent recording,
    // fields are not a transactional snapshot of one instant and must not be
    // interpreted as a mutually consistent tuple.
    [[nodiscard]] ObserverSnapshot snapshot() const noexcept;
    [[nodiscard]] const ObserverConfig& config() const noexcept { return config_; }

private:
    friend class Scope;

    void record(const ObservationSample& sample) noexcept;

    static std::uint64_t saturating_add(std::uint64_t lhs, std::uint64_t rhs) noexcept;
    static std::uint64_t atomic_increment_saturating(
        std::atomic<std::uint64_t>& target) noexcept;
    static void atomic_max(std::atomic<std::uint64_t>& target, std::uint64_t value) noexcept;

    ObserverConfig config_{};
    ObservationSink sink_{nullptr};
    void* sink_context_{nullptr};
    std::atomic<std::uint64_t> events_seen_{0};
    std::atomic<std::uint64_t> samples_recorded_{0};
    std::atomic<std::uint64_t> total_cpu_duration_ns_{0};
    std::atomic<std::uint64_t> max_cpu_duration_ns_{0};
    std::atomic<std::uint64_t> last_cpu_duration_ns_{0};
};

}  // namespace cupolicy
