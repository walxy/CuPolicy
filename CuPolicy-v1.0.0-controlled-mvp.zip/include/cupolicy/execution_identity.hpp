// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstddef>
#include <cstdint>

#include "cupolicy/contracts.hpp"
#include "cupolicy/workload.hpp"

namespace cupolicy {

struct ExecutionIdentity final {
    WorkloadSignature workload{};
    std::uint64_t topology_id{0};
    std::uint64_t backend_id{0};
    MetadataContract metadata{};
    WorkspaceContract workspace{};
    StreamContract stream{};

    // Capture-definition equality intentionally excludes runtime resource, capacity,
    // lifetime, and stream state. Those belong to the replay contract.
    [[nodiscard]] bool capture_definition_equal(const ExecutionIdentity& other) const noexcept {
        return workload == other.workload && topology_id == other.topology_id &&
               backend_id == other.backend_id;
    }

    // Full replay-contract equality includes all resource, capacity, lifetime, and stream state.
    [[nodiscard]] bool replay_contract_equal(const ExecutionIdentity& other) const noexcept {
        return capture_definition_equal(other) && metadata == other.metadata &&
               workspace == other.workspace && stream == other.stream;
    }

    [[nodiscard]] ContractValidation validate() const noexcept {
        ContractIssue issues{ContractIssue::kNone};
        const ContractValidation metadata_result = metadata.validate();
        const ContractValidation workspace_result = workspace.validate();
        const ContractValidation stream_result = stream.validate();
        issues = issues | metadata_result.issues | workspace_result.issues | stream_result.issues;
        return ContractValidation{issues};
    }

    friend bool operator==(const ExecutionIdentity&, const ExecutionIdentity&) = default;
};

namespace detail {

[[nodiscard]] constexpr std::uint64_t mix_u64(std::uint64_t value) noexcept {
    value += 0x9e3779b97f4a7c15ULL;
    value = (value ^ (value >> 30U)) * 0xbf58476d1ce4e5b9ULL;
    value = (value ^ (value >> 27U)) * 0x94d049bb133111ebULL;
    return value ^ (value >> 31U);
}

[[nodiscard]] constexpr std::uint64_t combine_u64(
    std::uint64_t state,
    std::uint64_t value) noexcept {
    return mix_u64(state ^ mix_u64(value));
}

[[nodiscard]] inline std::uint64_t capture_definition_hash(const ExecutionIdentity& identity) noexcept {
    std::uint64_t hash = mix_u64(identity.topology_id);
    hash = combine_u64(hash, identity.backend_id);
    hash = combine_u64(hash, static_cast<std::uint64_t>(identity.workload.shape.size()));
    for (std::size_t index = 0; index < identity.workload.shape.size(); ++index) {
        hash = combine_u64(hash, static_cast<std::uint64_t>(index));
        hash = combine_u64(hash, identity.workload.shape[index]);
    }
    return hash;
}

}  // namespace detail

// Hashes are deterministic logical encodings for in-process caches and diagnostics.
// They are not a persistent serialization format and may change between CuPolicy releases.
[[nodiscard]] inline std::uint64_t capture_definition_hash(const ExecutionIdentity& identity) noexcept {
    return detail::capture_definition_hash(identity);
}

[[nodiscard]] inline std::uint64_t identity_hash(const ExecutionIdentity& identity) noexcept {
    std::uint64_t hash = detail::capture_definition_hash(identity);

    hash = detail::combine_u64(hash, identity.metadata.resource.id);
    hash = detail::combine_u64(
        hash, static_cast<std::uint64_t>(identity.metadata.resource.mutability));
    hash = detail::combine_u64(hash, identity.metadata.capacity_bytes);
    hash = detail::combine_u64(hash, identity.metadata.required_capacity_bytes);
    hash = detail::combine_u64(hash, static_cast<std::uint64_t>(identity.metadata.lifetime));

    hash = detail::combine_u64(hash, identity.workspace.resource.id);
    hash = detail::combine_u64(
        hash, static_cast<std::uint64_t>(identity.workspace.resource.mutability));
    hash = detail::combine_u64(hash, identity.workspace.capacity_bytes);
    hash = detail::combine_u64(hash, identity.workspace.required_capacity_bytes);
    hash = detail::combine_u64(hash, static_cast<std::uint64_t>(identity.workspace.lifetime));

    hash = detail::combine_u64(hash, identity.stream.producer_stream_id);
    hash = detail::combine_u64(hash, identity.stream.consumer_stream_id);
    hash = detail::combine_u64(hash, static_cast<std::uint64_t>(identity.stream.ordering));
    hash = detail::combine_u64(hash, identity.stream.dependency_id);
    return hash;
}

}  // namespace cupolicy
