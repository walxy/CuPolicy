// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <string_view>

namespace cupolicy {

inline constexpr int kVersionMajor = 1;
inline constexpr int kVersionMinor = 0;
inline constexpr int kVersionPatch = 0;
inline constexpr std::string_view kVersion = "1.0.0";

}  // namespace cupolicy
