// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <string_view>

#include "cupolicy/policy.hpp"
#include "cupolicy/safety.hpp"

namespace cupolicy {

enum class ControlMode : std::uint8_t {
    kShadow = 0,
    kControlled,
};

constexpr std::string_view to_string(ControlMode mode) noexcept {
    switch (mode) {
        case ControlMode::kShadow:
            return "SHADOW";
        case ControlMode::kControlled:
            return "CONTROLLED";
    }
    return "UNKNOWN";
}

struct ControlConfig final {
    ControlMode mode{ControlMode::kShadow};
    bool allow_graph_launch{false};
    bool require_healthy_safety{true};

    [[nodiscard]] constexpr bool valid() const noexcept {
        const auto raw = static_cast<std::uint8_t>(mode);
        if (raw > static_cast<std::uint8_t>(ControlMode::kControlled)) {
            return false;
        }
        // Automatic graph intervention must be explicit. Shadow mode can never launch a graph.
        return mode != ControlMode::kControlled || allow_graph_launch;
    }
};

enum class BackendStatusCode : std::uint8_t {
    kOk = 0,
    kUnavailable,
    kFailed,
    kTerminal,
};

struct BackendStatus final {
    BackendStatusCode code{BackendStatusCode::kUnavailable};
    SafetyEventKind safety_event{SafetyEventKind::kNone};
    std::int32_t external_error_code{0};

    [[nodiscard]] constexpr bool ok() const noexcept { return code == BackendStatusCode::kOk; }
};

using EagerExecutionCallback = bool (*)(void* context) noexcept;
using GraphAvailabilityCallback = bool (*)(void* context) noexcept;
using GraphLaunchCallback = BackendStatus (*)(void* context) noexcept;

struct ControlBackend final {
    GraphAvailabilityCallback graph_available{nullptr};
    GraphLaunchCallback launch_graph{nullptr};
    void* context{nullptr};

    [[nodiscard]] constexpr bool valid() const noexcept {
        return graph_available != nullptr && launch_graph != nullptr;
    }
};

enum class ControlAction : std::uint8_t {
    kNone = 0,
    kShadowOnly,
    kExecuteEager,
    kExecuteGraph,
    kFallbackEager,
    kBlockExecution,
};

constexpr std::string_view to_string(ControlAction action) noexcept {
    switch (action) {
        case ControlAction::kNone:
            return "NONE";
        case ControlAction::kShadowOnly:
            return "SHADOW_ONLY";
        case ControlAction::kExecuteEager:
            return "EXECUTE_EAGER";
        case ControlAction::kExecuteGraph:
            return "EXECUTE_GRAPH";
        case ControlAction::kFallbackEager:
            return "FALLBACK_EAGER";
        case ControlAction::kBlockExecution:
            return "BLOCK_EXECUTION";
    }
    return "UNKNOWN";
}

enum class ControlErrorCode : std::uint8_t {
    kOk = 0,
    kInvalidConfiguration,
    kInvalidBackend,
    kInvalidEagerCallback,
    kPolicyRejected,
    kBackendFailed,
    kSafetyBlocked,
};

struct ControlResult final {
    ControlErrorCode error{ControlErrorCode::kOk};
    ControlAction action{ControlAction::kNone};
    PolicyEvaluation policy{};
    BackendStatus backend_status{};
    SafetyDecision safety{};
    bool eager_executed{false};
    bool graph_executed{false};
    bool intervention_performed{false};

    [[nodiscard]] constexpr bool ok() const noexcept { return error == ControlErrorCode::kOk; }
};

class ControlController final {
public:
    explicit ControlController(ControlConfig config = {}) noexcept : config_(config), safety_() {}

    [[nodiscard]] constexpr const ControlConfig& config() const noexcept { return config_; }
    [[nodiscard]] constexpr const SafetyController& safety() const noexcept { return safety_; }
    [[nodiscard]] constexpr SafetyController& safety() noexcept { return safety_; }

    [[nodiscard]] ControlResult execute(const PolicyCandidate& candidate,
                                        const PolicyConstraints& constraints,
                                        const ControlBackend& backend,
                                        EagerExecutionCallback eager_callback,
                                        void* eager_context = nullptr) noexcept;

private:
    ControlConfig config_{};
    SafetyController safety_{};
};

}  // namespace cupolicy
