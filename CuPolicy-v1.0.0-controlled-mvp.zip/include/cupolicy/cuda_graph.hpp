// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <string_view>
#include <mutex>

#include "cupolicy/safety.hpp"


#if defined(CUPOLICY_HAS_CUDA)
#include <cuda_runtime_api.h>
#endif

namespace cupolicy {

#if !defined(CUPOLICY_HAS_CUDA)

// The CUDA backend is an optional build feature. This declaration intentionally keeps the
// type incomplete in host-only builds so generic applications can include the public header
// without obtaining CUDA Toolkit headers. Instantiation is available only when the CuPolicy
// target is built with CUPOLICY_ENABLE_CUDA=ON.
class CudaGraphRuntime;

#else

enum class GraphRuntimeStatusCode : std::uint8_t {
    kOk = 0,
    kInvalidArgument,
    kNotInitialized,
    kAlreadyInitialized,
    kStreamMismatch,
    kCudaError,
    kGraphUpdateRejected,
    kCaptureFailed,
};

constexpr std::string_view to_string(GraphRuntimeStatusCode code) noexcept {
    switch (code) {
        case GraphRuntimeStatusCode::kOk:
            return "OK";
        case GraphRuntimeStatusCode::kInvalidArgument:
            return "INVALID_ARGUMENT";
        case GraphRuntimeStatusCode::kNotInitialized:
            return "NOT_INITIALIZED";
        case GraphRuntimeStatusCode::kAlreadyInitialized:
            return "ALREADY_INITIALIZED";
        case GraphRuntimeStatusCode::kStreamMismatch:
            return "STREAM_MISMATCH";
        case GraphRuntimeStatusCode::kCudaError:
            return "CUDA_ERROR";
        case GraphRuntimeStatusCode::kGraphUpdateRejected:
            return "GRAPH_UPDATE_REJECTED";
        case GraphRuntimeStatusCode::kCaptureFailed:
            return "CAPTURE_FAILED";
    }
    return "UNKNOWN";
}

struct GraphRuntimeStatus final {
    GraphRuntimeStatusCode code{GraphRuntimeStatusCode::kOk};
    int cuda_error_code{static_cast<int>(cudaSuccess)};
    int update_result_code{static_cast<int>(cudaGraphExecUpdateSuccess)};
    SafetyEventKind safety_event{SafetyEventKind::kNone};

    [[nodiscard]] constexpr bool ok() const noexcept {
        return code == GraphRuntimeStatusCode::kOk;
    }
};

enum class GraphUpdateResult : int {
    kSuccess = cudaGraphExecUpdateSuccess,
    kError = cudaGraphExecUpdateError,
    kTopologyChanged = cudaGraphExecUpdateErrorTopologyChanged,
    kNodeTypeChanged = cudaGraphExecUpdateErrorNodeTypeChanged,
    kFunctionChanged = cudaGraphExecUpdateErrorFunctionChanged,
    kParametersChanged = cudaGraphExecUpdateErrorParametersChanged,
    kNotSupported = cudaGraphExecUpdateErrorNotSupported,
    kUnsupportedFunctionChange = cudaGraphExecUpdateErrorUnsupportedFunctionChange,
    kAttributesChanged = cudaGraphExecUpdateErrorAttributesChanged,
};

constexpr std::string_view to_string(GraphUpdateResult result) noexcept {
    switch (result) {
        case GraphUpdateResult::kSuccess:
            return "SUCCESS";
        case GraphUpdateResult::kError:
            return "ERROR";
        case GraphUpdateResult::kTopologyChanged:
            return "TOPOLOGY_CHANGED";
        case GraphUpdateResult::kNodeTypeChanged:
            return "NODE_TYPE_CHANGED";
        case GraphUpdateResult::kFunctionChanged:
            return "FUNCTION_CHANGED";
        case GraphUpdateResult::kParametersChanged:
            return "PARAMETERS_CHANGED";
        case GraphUpdateResult::kNotSupported:
            return "NOT_SUPPORTED";
        case GraphUpdateResult::kUnsupportedFunctionChange:
            return "UNSUPPORTED_FUNCTION_CHANGE";
        case GraphUpdateResult::kAttributesChanged:
            return "ATTRIBUTES_CHANGED";
    }
    return "UNKNOWN";
}


enum class EvictionMode : std::uint8_t {
    kNonBlocking = 0,
    kWaitForCompletion,
};

struct EvictionOptions final {
    EvictionMode mode{EvictionMode::kNonBlocking};
};

struct EvictionResult final {
    GraphRuntimeStatus status{};
    bool logical_eviction{false};
    bool physical_release_may_be_deferred{false};
    bool synchronization_performed{false};

    [[nodiscard]] constexpr bool ok() const noexcept { return status.ok(); }
};

struct CaptureOptions final {
    cudaStreamCaptureMode mode{cudaStreamCaptureModeGlobal};
};

using CaptureCallback = cudaError_t (*)(cudaStream_t stream, void* context) noexcept;

class CudaGraphRuntime final {
public:
    CudaGraphRuntime() = default;
    CudaGraphRuntime(const CudaGraphRuntime&) = delete;
    CudaGraphRuntime& operator=(const CudaGraphRuntime&) = delete;
    CudaGraphRuntime(CudaGraphRuntime&&) = delete;
    CudaGraphRuntime& operator=(CudaGraphRuntime&&) = delete;
    ~CudaGraphRuntime() noexcept;

    // Capture constructs a fresh CUDA graph and executable graph. It is valid only when the
    // runtime is empty. The callback must enqueue the complete logical workload on `stream`.
    [[nodiscard]] GraphRuntimeStatus capture(cudaStream_t stream,
                                             CaptureCallback callback,
                                             void* context = nullptr,
                                             CaptureOptions options = {}) noexcept;

    // Launches the current executable graph. By default the launch stream must be identical to
    // the capture stream; this conservative v0.6 rule preserves the stream contract established
    // during capture. A future version may permit explicitly validated alternate launch streams.
    [[nodiscard]] GraphRuntimeStatus launch(cudaStream_t stream) noexcept;

    // Captures a new graph and asks CUDA to update the existing executable graph in place. On
    // update rejection the existing executable graph remains installed and the new graph is
    // destroyed. A successful update keeps the same executable-graph instance id.
    [[nodiscard]] GraphRuntimeStatus update(cudaStream_t stream,
                                            CaptureCallback callback,
                                            void* context = nullptr,
                                            CaptureOptions options = {}) noexcept;

    // Captures a completely new graph, instantiates a new executable graph, then atomically
    // replaces the installed executable graph on success. This deliberately avoids
    // cudaStreamBeginRecaptureToGraph because CUDA documents that a failed recapture leaves the
    // target graph in an undefined state and it should then be destroyed.
    [[nodiscard]] GraphRuntimeStatus recapture(cudaStream_t stream,
                                                CaptureCallback callback,
                                                void* context = nullptr,
                                                CaptureOptions options = {}) noexcept;

    // Evicts the installed graph generation. In non-blocking mode CUDA may defer the physical
    // release until an in-flight launch completes; callers must re-observe memory before treating
    // the bytes as available. Wait-for-completion performs a stream synchronization first and
    // therefore provides a stronger release boundary at the cost of blocking the host.
    [[nodiscard]] EvictionResult evict(EvictionOptions options = {}) noexcept;

    [[nodiscard]] bool initialized() const noexcept;
    [[nodiscard]] std::uint64_t graph_id() const noexcept;
    [[nodiscard]] cudaStream_t capture_stream() const noexcept;

private:
    cudaGraph_t graph_{nullptr};
    cudaGraphExec_t exec_{nullptr};
    cudaStream_t capture_stream_{nullptr};
    std::uint64_t graph_id_{0};

    mutable std::mutex mutex_;
};

#endif

}  // namespace cupolicy
