# Public headers

CuPolicy exposes framework-neutral host-side policy and residency headers plus an optional CUDA Graph runtime header. The CUDA runtime is enabled explicitly with `CUPOLICY_ENABLE_CUDA=ON`. GPU compatibility is not declared without device-backed validation.
