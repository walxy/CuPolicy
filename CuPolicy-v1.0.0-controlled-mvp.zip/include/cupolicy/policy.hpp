// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <limits>
#include <span>
#include <string_view>

#include "cupolicy/contracts.hpp"
#include "cupolicy/execution.hpp"

namespace cupolicy {

enum class ObservationField : std::uint32_t {
    kNone = 0U,
    kCaptureDefinition = 1U << 0U,
    kEagerDuration = 1U << 1U,
    kGraphReplayDuration = 1U << 2U,
    kCaptureDuration = 1U << 3U,
    kInstantiateDuration = 1U << 4U,
    kWarmupDuration = 1U << 5U,
    kGraphMemory = 1U << 6U,
    kContractValidation = 1U << 7U,
};

[[nodiscard]] constexpr ObservationField operator|(ObservationField lhs,
                                                    ObservationField rhs) noexcept {
    return static_cast<ObservationField>(static_cast<std::uint32_t>(lhs) |
                                         static_cast<std::uint32_t>(rhs));
}

[[nodiscard]] constexpr ObservationField operator&(ObservationField lhs,
                                                    ObservationField rhs) noexcept {
    return static_cast<ObservationField>(static_cast<std::uint32_t>(lhs) &
                                         static_cast<std::uint32_t>(rhs));
}

[[nodiscard]] constexpr ObservationField operator~(ObservationField value) noexcept {
    return static_cast<ObservationField>(~static_cast<std::uint32_t>(value));
}

[[nodiscard]] constexpr bool has_field(ObservationField fields, ObservationField field) noexcept {
    return (fields & field) != ObservationField::kNone;
}

constexpr std::string_view to_string(ObservationField field) noexcept {
    switch (field) {
        case ObservationField::kNone:
            return "NONE";
        case ObservationField::kCaptureDefinition:
            return "CAPTURE_DEFINITION";
        case ObservationField::kEagerDuration:
            return "EAGER_DURATION";
        case ObservationField::kGraphReplayDuration:
            return "GRAPH_REPLAY_DURATION";
        case ObservationField::kCaptureDuration:
            return "CAPTURE_DURATION";
        case ObservationField::kInstantiateDuration:
            return "INSTANTIATE_DURATION";
        case ObservationField::kWarmupDuration:
            return "WARMUP_DURATION";
        case ObservationField::kGraphMemory:
            return "GRAPH_MEMORY";
        case ObservationField::kContractValidation:
            return "CONTRACT_VALIDATION";
    }
    return "UNKNOWN";
}

enum class EvidenceConfidence : std::uint8_t {
    kUnknown = 0,
    kLow,
    kMedium,
    kHigh,
};

constexpr std::string_view to_string(EvidenceConfidence confidence) noexcept {
    switch (confidence) {
        case EvidenceConfidence::kUnknown:
            return "UNKNOWN";
        case EvidenceConfidence::kLow:
            return "LOW";
        case EvidenceConfidence::kMedium:
            return "MEDIUM";
        case EvidenceConfidence::kHigh:
            return "HIGH";
    }
    return "UNKNOWN";
}

[[nodiscard]] constexpr bool is_valid_confidence(EvidenceConfidence confidence) noexcept {
    return static_cast<std::uint8_t>(confidence) <=
           static_cast<std::uint8_t>(EvidenceConfidence::kHigh);
}

[[nodiscard]] constexpr bool confidence_at_least(EvidenceConfidence actual,
                                                  EvidenceConfidence required) noexcept {
    return is_valid_confidence(actual) && is_valid_confidence(required) &&
           static_cast<std::uint8_t>(actual) >= static_cast<std::uint8_t>(required);
}

// A partial observation is intentionally distinct from ExecutionIdentity.
// Zero-valued fields are data only when their corresponding validity bit is set.
struct ObservedExecution final {
    std::uint64_t capture_definition_id{0};
    std::uint64_t eager_duration_ns{0};
    std::uint64_t graph_replay_duration_ns{0};
    std::uint64_t capture_duration_ns{0};
    std::uint64_t instantiate_duration_ns{0};
    std::uint64_t warmup_duration_ns{0};
    std::uint64_t graph_memory_bytes{0};
    ContractIssue contract_issues{ContractIssue::kNone};
    ObservationField fields{ObservationField::kNone};
    std::uint64_t timing_samples{0};
    EvidenceConfidence confidence{EvidenceConfidence::kUnknown};

    [[nodiscard]] constexpr bool has(ObservationField field) const noexcept {
        return has_field(fields, field);
    }

    [[nodiscard]] constexpr bool complete_for_policy(bool require_contract_validation = true) const
        noexcept {
        constexpr ObservationField required =
            ObservationField::kCaptureDefinition | ObservationField::kEagerDuration |
            ObservationField::kGraphReplayDuration | ObservationField::kCaptureDuration |
            ObservationField::kInstantiateDuration | ObservationField::kWarmupDuration |
            ObservationField::kGraphMemory;
        if ((fields & required) != required) {
            return false;
        }
        if (capture_definition_id == 0 || timing_samples == 0 || !is_valid_confidence(confidence)) {
            return false;
        }
        return !require_contract_validation || has(ObservationField::kContractValidation);
    }
};

enum class PolicyCandidateState : std::uint8_t {
    kAvailable = 0,
    kUnavailable,
};

constexpr std::string_view to_string(PolicyCandidateState state) noexcept {
    switch (state) {
        case PolicyCandidateState::kAvailable:
            return "AVAILABLE";
        case PolicyCandidateState::kUnavailable:
            return "UNAVAILABLE";
    }
    return "UNKNOWN";
}


enum class MemoryField : std::uint32_t {
    kNone = 0U,
    kDeviceBudget = 1U << 0U,
    kNonGraphResident = 1U << 1U,
    kGraphResident = 1U << 2U,
};

[[nodiscard]] constexpr MemoryField operator|(MemoryField lhs, MemoryField rhs) noexcept {
    return static_cast<MemoryField>(static_cast<std::uint32_t>(lhs) |
                                    static_cast<std::uint32_t>(rhs));
}

[[nodiscard]] constexpr MemoryField operator&(MemoryField lhs, MemoryField rhs) noexcept {
    return static_cast<MemoryField>(static_cast<std::uint32_t>(lhs) &
                                    static_cast<std::uint32_t>(rhs));
}

[[nodiscard]] constexpr bool has_field(MemoryField fields, MemoryField field) noexcept {
    return (fields & field) != MemoryField::kNone;
}

struct MemorySnapshot final {
    // These values form one accounting domain. The simulator does not infer or reconcile them
    // with CUDA's allocator; a backend is responsible for collecting consistent measurements.
    std::uint64_t device_budget_bytes{0};
    std::uint64_t non_graph_resident_bytes{0};
    std::uint64_t graph_resident_bytes{0};
    MemoryField fields{MemoryField::kNone};

    [[nodiscard]] constexpr bool complete() const noexcept {
        constexpr MemoryField required = MemoryField::kDeviceBudget |
                                         MemoryField::kNonGraphResident |
                                         MemoryField::kGraphResident;
        return (fields & required) == required;
    }
};

enum class MemoryAdmissionReason : std::uint8_t {
    kAccepted = 0,
    kInsufficientEvidence,
    kCurrentUsageExceedsBudget,
    kCandidateExceedsGraphBudget,
    kTotalBudgetExceeded,
    kReservedHeadroomViolated,
};

constexpr std::string_view to_string(MemoryAdmissionReason reason) noexcept {
    switch (reason) {
        case MemoryAdmissionReason::kAccepted:
            return "ACCEPTED";
        case MemoryAdmissionReason::kInsufficientEvidence:
            return "INSUFFICIENT_EVIDENCE";
        case MemoryAdmissionReason::kCurrentUsageExceedsBudget:
            return "CURRENT_USAGE_EXCEEDS_BUDGET";
        case MemoryAdmissionReason::kCandidateExceedsGraphBudget:
            return "CANDIDATE_EXCEEDS_GRAPH_BUDGET";
        case MemoryAdmissionReason::kTotalBudgetExceeded:
            return "TOTAL_BUDGET_EXCEEDED";
        case MemoryAdmissionReason::kReservedHeadroomViolated:
            return "RESERVED_HEADROOM_VIOLATED";
    }
    return "UNKNOWN";
}

struct MemoryConstraints final {
    bool require_memory_evidence{true};
    std::uint64_t max_graph_resident_bytes{std::numeric_limits<std::uint64_t>::max()};
    std::uint64_t min_free_bytes_after_admission{0};

    [[nodiscard]] constexpr bool valid() const noexcept {
        return true;
    }
};

struct MemoryAdmission final {
    bool admitted{false};
    MemoryAdmissionReason reason{MemoryAdmissionReason::kInsufficientEvidence};
    std::uint64_t projected_graph_resident_bytes{0};
    std::uint64_t projected_total_resident_bytes{0};
    std::uint64_t free_bytes_after_admission{0};
};

class MemoryPolicyEvaluator final {
public:
    [[nodiscard]] static MemoryAdmission evaluate(const MemorySnapshot& snapshot,
                                                   std::uint64_t candidate_graph_bytes,
                                                   const MemoryConstraints& constraints) noexcept;
};

struct PolicyCandidate final {
    ObservedExecution observation{};
    std::uint64_t expected_replays{0};
    PolicyCandidateState state{PolicyCandidateState::kAvailable};
    ExecutionMode current_mode{ExecutionMode::kEager};
    // Memory is contextual state measured at the decision boundary, not part of the execution
    // definition. A runtime adapter must populate a coherent snapshot from one accounting domain.
    MemorySnapshot memory{};
};

struct PolicyConstraints final {
    // A value of zero allows a candidate with positive estimated net benefit even for
    // a single replay. Higher values require explicit reuse before graph admission.
    std::uint64_t min_expected_replays{1};
    std::uint64_t max_graph_memory_bytes{std::numeric_limits<std::uint64_t>::max()};
    std::uint64_t min_net_benefit_ns{0};
    bool require_contract_validation{true};
    EvidenceConfidence min_evidence_confidence{EvidenceConfidence::kUnknown};
    std::uint64_t min_timing_samples{1};
    // Must not exceed min_net_benefit_ns. A lower exit threshold is the hysteresis band.
    std::uint64_t graph_exit_min_net_benefit_ns{0};
    std::uint64_t max_graph_variants{std::numeric_limits<std::uint64_t>::max()};
    MemoryConstraints memory{};

    [[nodiscard]] constexpr bool valid() const noexcept {
        return static_cast<std::uint8_t>(min_evidence_confidence) <=
                   static_cast<std::uint8_t>(EvidenceConfidence::kHigh) &&
               graph_exit_min_net_benefit_ns <= min_net_benefit_ns;
    }
};

struct PolicyEvaluation final {
    ExecutionDecision decision{};
    MemoryAdmissionReason memory_reason{MemoryAdmissionReason::kAccepted};
    bool memory_evaluated{false};
    std::uint64_t setup_cost_ns{0};
    std::uint64_t per_replay_savings_ns{0};
    // Smallest positive replay count that can produce positive net benefit, ignoring
    // min_expected_replays and min_net_benefit_ns constraints. If no representable uint64_t
    // replay count can produce positive benefit, this saturates at UINT64_MAX and
    // break_even_reachable is false.
    std::uint64_t break_even_replays{0};
    bool break_even_reachable{false};
    std::uint64_t estimated_net_benefit_ns{0};
    bool hysteresis_retained{false};
};

class PolicyEvaluator final {
public:
    [[nodiscard]] static PolicyEvaluation evaluate(const PolicyCandidate& candidate,
                                                   const PolicyConstraints& constraints) noexcept;
};

struct SimulationSummary final {
    std::uint64_t observations{0};
    std::uint64_t eager_decisions{0};
    std::uint64_t graph_decisions{0};
    std::uint64_t insufficient_evidence{0};
    std::uint64_t invalid_candidate{0};
    std::uint64_t unsafe_contract{0};
    std::uint64_t graph_unavailable{0};
    std::uint64_t insufficient_reuse{0};
    std::uint64_t memory_budget_rejections{0};
    std::uint64_t non_positive_benefit{0};
    std::uint64_t not_amortized{0};
    std::uint64_t below_benefit_threshold{0};
    std::uint64_t not_enough_confidence{0};
    std::uint64_t hysteresis_retained{0};
    std::uint64_t variant_budget_rejections{0};
    std::uint64_t runtime_failures{0};
    std::uint64_t evicted_decisions{0};
    std::uint64_t unique_capture_definitions{0};
    std::uint64_t duplicate_candidates{0};
    std::uint64_t accepted_graph_definitions{0};
    std::uint64_t estimated_net_benefit_ns{0};
};

using PolicyDecisionSink = void (*)(const PolicyCandidate&, const PolicyEvaluation&, void*) noexcept;

class PolicySimulator final {
public:
    // Offline trace simulation may allocate bookkeeping storage; it is intentionally not noexcept.
    [[nodiscard]] static SimulationSummary simulate(
        std::span<const PolicyCandidate> candidates,
        const PolicyConstraints& constraints,
        PolicyDecisionSink sink = nullptr,
        void* sink_context = nullptr);
};

}  // namespace cupolicy
