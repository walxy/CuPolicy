// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <string_view>

namespace cupolicy {

enum class ContractIssue : std::uint32_t {
    kNone = 0U,
    kResourceUnspecified = 1U << 0U,
    kLifetimeUnspecified = 1U << 1U,
    kCapacityInsufficient = 1U << 2U,
    kOrderingUnspecified = 1U << 3U,
    kProducerStreamUnspecified = 1U << 4U,
    kConsumerStreamUnspecified = 1U << 5U,
    kStreamMismatch = 1U << 6U,
    kDependencyUnspecified = 1U << 7U,
};

[[nodiscard]] constexpr ContractIssue operator|(ContractIssue lhs, ContractIssue rhs) noexcept {
    return static_cast<ContractIssue>(static_cast<std::uint32_t>(lhs) |
                                      static_cast<std::uint32_t>(rhs));
}

[[nodiscard]] constexpr ContractIssue operator&(ContractIssue lhs, ContractIssue rhs) noexcept {
    return static_cast<ContractIssue>(static_cast<std::uint32_t>(lhs) &
                                      static_cast<std::uint32_t>(rhs));
}

[[nodiscard]] constexpr bool has_issue(ContractIssue issues, ContractIssue issue) noexcept {
    return (issues & issue) != ContractIssue::kNone;
}

struct ContractValidation final {
    ContractIssue issues{ContractIssue::kNone};

    [[nodiscard]] constexpr bool valid() const noexcept {
        return issues == ContractIssue::kNone;
    }
};


enum class Mutability {
    kImmutable = 0,
    kMutable,
};

constexpr std::string_view to_string(Mutability value) noexcept {
    switch (value) {
        case Mutability::kImmutable:
            return "IMMUTABLE";
        case Mutability::kMutable:
            return "MUTABLE";
    }
    return "UNKNOWN";
}

enum class Lifetime {
    kUnspecified = 0,
    kReplay,
    kExecution,
    kExternal,
};

constexpr std::string_view to_string(Lifetime value) noexcept {
    switch (value) {
        case Lifetime::kUnspecified:
            return "UNSPECIFIED";
        case Lifetime::kReplay:
            return "REPLAY";
        case Lifetime::kExecution:
            return "EXECUTION";
        case Lifetime::kExternal:
            return "EXTERNAL";
    }
    return "UNKNOWN";
}

enum class Ordering {
    kUnspecified = 0,
    kSameStream,
    kExplicitDependency,
    kIndependent,
};

constexpr std::string_view to_string(Ordering value) noexcept {
    switch (value) {
        case Ordering::kUnspecified:
            return "UNSPECIFIED";
        case Ordering::kSameStream:
            return "SAME_STREAM";
        case Ordering::kExplicitDependency:
            return "EXPLICIT_DEPENDENCY";
        case Ordering::kIndependent:
            return "INDEPENDENT";
    }
    return "UNKNOWN";
}

struct ResourceIdentity final {
    // Zero is reserved for an unspecified resource identity.
    std::uint64_t id{0};
    Mutability mutability{Mutability::kImmutable};

    [[nodiscard]] constexpr bool specified() const noexcept { return id != 0; }

    friend constexpr bool operator==(const ResourceIdentity&, const ResourceIdentity&) = default;
};

struct MetadataContract final {
    ResourceIdentity resource{};
    std::uint64_t capacity_bytes{0};
    std::uint64_t required_capacity_bytes{0};
    Lifetime lifetime{Lifetime::kUnspecified};

    [[nodiscard]] constexpr bool capacity_sufficient() const noexcept {
        return capacity_bytes >= required_capacity_bytes;
    }

    [[nodiscard]] constexpr ContractValidation validate() const noexcept {
        ContractIssue issues{ContractIssue::kNone};
        if (!resource.specified()) {
            issues = issues | ContractIssue::kResourceUnspecified;
        }
        if (lifetime == Lifetime::kUnspecified) {
            issues = issues | ContractIssue::kLifetimeUnspecified;
        }
        if (!capacity_sufficient()) {
            issues = issues | ContractIssue::kCapacityInsufficient;
        }
        return ContractValidation{issues};
    }

    [[nodiscard]] constexpr bool valid() const noexcept { return validate().valid(); }

    friend constexpr bool operator==(const MetadataContract&, const MetadataContract&) = default;
};

struct WorkspaceContract final {
    ResourceIdentity resource{};
    std::uint64_t capacity_bytes{0};
    std::uint64_t required_capacity_bytes{0};
    Lifetime lifetime{Lifetime::kUnspecified};

    [[nodiscard]] constexpr bool capacity_sufficient() const noexcept {
        return capacity_bytes >= required_capacity_bytes;
    }

    [[nodiscard]] constexpr ContractValidation validate() const noexcept {
        ContractIssue issues{ContractIssue::kNone};
        if (!resource.specified()) {
            issues = issues | ContractIssue::kResourceUnspecified;
        }
        if (lifetime == Lifetime::kUnspecified) {
            issues = issues | ContractIssue::kLifetimeUnspecified;
        }
        if (!capacity_sufficient()) {
            issues = issues | ContractIssue::kCapacityInsufficient;
        }
        return ContractValidation{issues};
    }

    [[nodiscard]] constexpr bool valid() const noexcept { return validate().valid(); }

    friend constexpr bool operator==(const WorkspaceContract&, const WorkspaceContract&) = default;
};

struct StreamContract final {
    std::uint64_t producer_stream_id{0};
    std::uint64_t consumer_stream_id{0};
    Ordering ordering{Ordering::kUnspecified};
    std::uint64_t dependency_id{0};

    [[nodiscard]] constexpr ContractValidation validate() const noexcept {
        ContractIssue issues{ContractIssue::kNone};
        if (ordering == Ordering::kUnspecified) {
            issues = issues | ContractIssue::kOrderingUnspecified;
        }
        if (producer_stream_id == 0) {
            issues = issues | ContractIssue::kProducerStreamUnspecified;
        }
        if (consumer_stream_id == 0) {
            issues = issues | ContractIssue::kConsumerStreamUnspecified;
        }

        switch (ordering) {
            case Ordering::kUnspecified:
                break;
            case Ordering::kSameStream:
                if (producer_stream_id != 0 && consumer_stream_id != 0 &&
                    producer_stream_id != consumer_stream_id) {
                    issues = issues | ContractIssue::kStreamMismatch;
                }
                break;
            case Ordering::kExplicitDependency:
                if (dependency_id == 0) {
                    issues = issues | ContractIssue::kDependencyUnspecified;
                }
                break;
            case Ordering::kIndependent:
                if (producer_stream_id != 0 && consumer_stream_id != 0 &&
                    producer_stream_id == consumer_stream_id) {
                    issues = issues | ContractIssue::kStreamMismatch;
                }
                break;
        }
        return ContractValidation{issues};
    }

    [[nodiscard]] constexpr bool valid() const noexcept { return validate().valid(); }

    friend constexpr bool operator==(const StreamContract&, const StreamContract&) = default;
};

}  // namespace cupolicy
