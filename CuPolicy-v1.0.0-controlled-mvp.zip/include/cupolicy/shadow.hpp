// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>
#include <vector>
#include <limits>

#include "cupolicy/policy.hpp"

namespace cupolicy {

enum class ShadowMode : std::uint8_t {
    kOff = 0,
    kObserve,
    kShadow,
};

constexpr std::string_view to_string(ShadowMode mode) noexcept {
    switch (mode) {
        case ShadowMode::kOff:
            return "OFF";
        case ShadowMode::kObserve:
            return "OBSERVE";
        case ShadowMode::kShadow:
            return "SHADOW";
    }
    return "UNKNOWN";
}

struct ShadowConfig final {
    ShadowMode mode{ShadowMode::kShadow};
    std::uint64_t max_trace_entries{4096};

    [[nodiscard]] constexpr bool valid() const noexcept {
        return max_trace_entries != 0 &&
               max_trace_entries <= static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max()) &&
               static_cast<std::uint8_t>(mode) <= static_cast<std::uint8_t>(ShadowMode::kShadow);
    }
};

enum class ShadowComparisonReason : std::uint8_t {
    kNotEvaluated = 0,
    kAgreement,
    kPolicyWouldPreferGraph,
    kPolicyWouldPreferEager,
    kPolicyCouldNotEvaluate,
};

constexpr std::string_view to_string(ShadowComparisonReason reason) noexcept {
    switch (reason) {
        case ShadowComparisonReason::kNotEvaluated:
            return "NOT_EVALUATED";
        case ShadowComparisonReason::kAgreement:
            return "AGREEMENT";
        case ShadowComparisonReason::kPolicyWouldPreferGraph:
            return "POLICY_WOULD_PREFER_GRAPH";
        case ShadowComparisonReason::kPolicyWouldPreferEager:
            return "POLICY_WOULD_PREFER_EAGER";
        case ShadowComparisonReason::kPolicyCouldNotEvaluate:
            return "POLICY_COULD_NOT_EVALUATE";
    }
    return "UNKNOWN";
}

struct ShadowObservation final {
    std::uint64_t sequence{0};
    std::uint64_t capture_definition_id{0};
    ExecutionMode baseline_mode{ExecutionMode::kEager};
    ExecutionDecision proposed_decision{};
    ShadowComparisonReason comparison{ShadowComparisonReason::kNotEvaluated};
    std::uint64_t estimated_policy_benefit_ns{0};
    std::uint64_t estimated_regret_ns{0};
};

struct ShadowReport final {
    std::uint64_t observations{0};
    std::uint64_t evaluated{0};
    std::uint64_t policy_graph_decisions{0};
    std::uint64_t policy_eager_decisions{0};
    std::uint64_t baseline_graph_decisions{0};
    std::uint64_t baseline_eager_decisions{0};
    std::uint64_t agreements{0};
    std::uint64_t policy_would_prefer_graph{0};
    std::uint64_t policy_would_prefer_eager{0};
    std::uint64_t policy_could_not_evaluate{0};
    std::uint64_t estimated_policy_benefit_ns{0};
    std::uint64_t estimated_regret_ns{0};
    std::uint64_t trace_entries{0};
    std::uint64_t trace_dropped{0};

    [[nodiscard]] constexpr bool intervention_performed() const noexcept { return false; }
};

class ShadowTraceRecorder final {
public:
    explicit ShadowTraceRecorder(std::uint64_t max_entries);

    [[nodiscard]] bool record(const ShadowObservation& observation);
    [[nodiscard]] std::span<const ShadowObservation> entries() const noexcept;
    [[nodiscard]] std::uint64_t dropped() const noexcept { return dropped_; }

private:
    std::vector<ShadowObservation> entries_{};
    std::uint64_t dropped_{0};
};

struct ShadowEvaluation final {
    ExecutionDecision proposed_decision{};
    ShadowComparisonReason comparison{ShadowComparisonReason::kPolicyCouldNotEvaluate};
    std::uint64_t estimated_policy_benefit_ns{0};
    std::uint64_t estimated_regret_ns{0};
    bool evaluated{false};
    bool intervention_performed{false};
};

class ShadowController final {
public:
    explicit ShadowController(ShadowConfig config = {});

    [[nodiscard]] const ShadowConfig& config() const noexcept { return config_; }
    [[nodiscard]] const ShadowReport& report() const noexcept { return report_; }
    [[nodiscard]] std::span<const ShadowObservation> trace() const noexcept {
        return recorder_.entries();
    }

    [[nodiscard]] ShadowEvaluation evaluate(const PolicyCandidate& candidate,
                                            const PolicyConstraints& constraints) noexcept;

    // The controller is not thread-safe; callers must serialize concurrent evaluation/replay
    // or use one controller per independent execution context.
    // Shadow mode never changes the caller's execution mode. This method only replays
    // the policy decision over a pre-recorded trace and updates aggregate reporting.
    [[nodiscard]] ShadowReport replay(std::span<const PolicyCandidate> candidates,
                                      const PolicyConstraints& constraints) noexcept;

    // Human-readable JSON-like object serialization for offline reports. This allocates and is
    // intentionally outside the hot policy path.
    [[nodiscard]] std::string report_json() const;

private:
    static std::uint64_t saturating_add(std::uint64_t lhs, std::uint64_t rhs) noexcept;
    static bool is_baseline_mode_valid(ExecutionMode mode) noexcept;

    void update_report(const PolicyCandidate& candidate, const ShadowEvaluation& evaluation) noexcept;

    ShadowConfig config_{};
    ShadowTraceRecorder recorder_;
    ShadowReport report_{};
    std::uint64_t next_sequence_{1};
};

}  // namespace cupolicy
