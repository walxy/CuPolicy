# Contributing

## Required for changes

- explain the problem being solved;
- prefer existing libraries and documented APIs;
- add or update tests;
- add benchmark evidence for performance-sensitive changes;
- record third-party provenance when relevant;
- update documentation for user-visible behavior.

## Refactoring

Minimalist refactoring is the default. Larger architectural refactors require an ADR or equivalent design note.
