# Requirements

## Development baseline

- Linux is the first development environment.
- C++20 compiler support.
- CMake 3.28 or newer.
- Ninja recommended.
- CUDA is required only for GPU integration stages.
- Python 3.12 or newer is used for developer tooling and optional Python integration.

## Production compatibility

Production CUDA/framework compatibility is not declared by the current v1.0.0 controlled controller, optional CUDA Graph runtime, safety controller, and shadow-release tooling. The backend targets the CUDA Runtime Graph APIs documented by CUDA Toolkit 13.3.1; actual device/driver compatibility must be established by GPU-backed validation and recorded by release.

CUDA Developer Preview releases are not part of the production baseline unless explicitly tested and labeled experimental.
