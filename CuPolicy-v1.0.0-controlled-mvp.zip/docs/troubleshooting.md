# Troubleshooting

v0.1.0 intentionally has no CUDA runtime troubleshooting guide yet.

When runtime code is introduced, every failure report should include:

- exact CuPolicy version;
- GPU model;
- driver;
- CUDA runtime/toolkit;
- framework and version;
- compiler;
- operating system;
- workload signature;
- reproduction command;
- logs and relevant telemetry;
- whether the failure occurred during capture, replay, update, recapture, or fallback.
