# Comparison baseline

This page records comparison methodology and must not claim capabilities or performance that have not been verified against the exact release and environment under test.

The current project release is **v0.1.0 foundation / pre-alpha**. CUDA execution policy comparisons begin after the observer and policy-simulation stages.
