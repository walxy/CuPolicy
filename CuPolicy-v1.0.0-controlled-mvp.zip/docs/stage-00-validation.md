# Stage 00 validation record

## Scope

This record covers the qualification baseline and the transition into the v0.2 observer implementation. It does not claim CUDA runtime correctness because the CUDA backend remains intentionally unimplemented.

## Qualification baseline

| Check | Result | Evidence |
|---|---|---|
| Repository structure | PASS | v0.1 foundation and v0.2 observer structure present |
| CMake configure/build | PASS | GCC 14.2.0, Clang 17.0.0, C++20 |
| Unit tests | PASS | foundation + observer tests |
| ASan/UBSan | PASS | observer/foundation tests |
| TSan | PASS | observer/foundation concurrency tests |
| Installed package consumer | PASS | external C++ and C consumers resolve and link the installed package |
| Python dependency lock | EXTERNAL/PENDING | Package-index access is unavailable in the current environment; `uv.lock` was not fabricated |
| Python tooling execution | EXTERNAL/PENDING | Requires the locked environment |
| MkDocs strict build | EXTERNAL/PENDING | Requires the locked environment |
| CUDA runtime validation | EXTERNAL/PENDING | No NVIDIA GPU/CUDA runtime is exposed in this environment; v0.2 contains no CUDA backend yet |
| Third-party source provenance | PASS for current tree | No third-party source vendored |

## Current host environment

- CMake: 3.31.6
- Ninja: 1.12.1
- GCC: 14.2.0
- Clang: 17.0.0
- Python: 3.13.5
- uv executable: 0.10.0 (project requires >=0.12.0,<0.13)
- NVIDIA GPU: not exposed

## v0.2 observer validation

The observer was validated with:

- GCC Release and Debug builds with `-Werror`;
- Clang Release/Debug builds with `-Werror`;
- concurrent observer tests;
- AddressSanitizer + UndefinedBehaviorSanitizer;
- ThreadSanitizer;
- installed CMake package consumption from an external C++ and C consumer;
- five repeated host-only overhead measurements.

One final GCC Release benchmark run with 1,000,000 iterations reported approximately 4.01 ns/iteration for disabled observation, 29.25 ns/iteration for sampling every 16th event, and 104.48 ns/iteration for full observation, relative to a minimal baseline of 0.36 ns/iteration. These numbers are host-only qualification data and are not GPU performance claims.

## Interpretation

The project may continue development under the documented external-environment exemption model. A future release may not claim GPU support or Python/docs quality-gate completion until the corresponding external validations have actually run.
