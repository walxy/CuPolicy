# Product boundary

## In scope

- workload observation;
- execution-mode policy;
- graph/eager admission;
- memory-aware policy;
- graph lifecycle decisions;
- safety contracts;
- fallback;
- telemetry and explanation.

## Out of scope initially

- allocator replacement;
- compiler replacement;
- kernel library;
- generic GPU scheduler;
- new CUDA bindings;
- automatic multi-vendor abstraction;
- distributed graph coordinator;
- ML/RL optimizer.
