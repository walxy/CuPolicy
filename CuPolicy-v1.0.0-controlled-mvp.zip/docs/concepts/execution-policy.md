# Execution policy

The first policy decision space is:

```text
EAGER
GRAPH
UPDATE
RECAPTURE
FALLBACK
```

A future release may introduce PIECEWISE as a policy outcome while delegating the actual piecewise implementation to the underlying framework/backend.

The policy objective is not simply minimum kernel time. It is expected end-to-end utility under performance, memory, startup, and correctness constraints.


## v0.4 simulator semantics

The v0.4 simulator admits `GRAPH` only when policy evidence is complete, replay contracts are safe, a graph candidate is available, expected reuse meets the configured minimum, graph memory fits the configured budget, and the estimated net benefit exceeds the configured threshold. All numeric inputs are unsigned integer nanoseconds/bytes; arithmetic saturates instead of wrapping.
