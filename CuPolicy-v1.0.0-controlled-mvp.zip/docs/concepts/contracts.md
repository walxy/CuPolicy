# Execution contracts

A graph candidate is valid only when its required execution contract is satisfied.

The contract model separates:

- capture-defining state;
- capacity-defining state;
- replay-mutable state.

The initial contract families are:

- metadata;
- workspace;
- stream ordering;
- resource lifetime;
- memory budget;
- backend capabilities.


## Diagnostics

Contract validation returns a compact `ContractValidation` result containing a bitset-like `ContractIssue` value. The result identifies missing resources, unspecified lifetimes, insufficient capacity, missing streams, invalid stream relationships, and missing dependency identities. This is diagnostic state only; it does not prove that a CUDA runtime dependency or event actually exists.

The contract layer intentionally does not define a persistent serialization format in v0.3.x. `identity_hash()` and `capture_definition_hash()` are in-process/cache-oriented encodings and may change between releases.


## Complete identities vs partial observations

`ExecutionIdentity::validate()` intentionally validates a complete execution contract. It requires metadata, workspace, and stream contracts to be well formed. A trace or observation may legitimately lack some of this information; such a partial observation must not be coerced into a valid `ExecutionIdentity`. The policy/adapter layers will represent partial observations explicitly in a later release.
