# Initial error register

| ID | Risk | Severity | Stage |
|---|---|---|---|
| E001 | concurrent graph-object mutation | Critical | CUDA runtime (serialized per runtime instance; GPU validation pending) |
| E002 | replay after resource lifetime ends | Critical | CUDA runtime |
| E003 | missing cross-stream dependency | Critical | CUDA runtime |
| E004 | invalid graph-update assumption | Critical | CUDA runtime (update result checked; compatibility matrix pending) |
| E005 | metadata capacity mismatch | Critical | contracts |
| E006 | topology treated as mutable | Critical | graph lifecycle (fresh recapture fallback; update remains constrained) |
| E007 | memory-budget arithmetic overflow | Critical | policy |
| E008 | low-reuse graph admitted | Major | policy |
| E009 | graph-variant explosion | Major | policy |
| E010 | policy oscillation | Major | policy |
| E011 | benchmark synchronization contamination | Major | benchmarking |
| E012 | hidden synchronization in telemetry | Major | observability |
| E013 | hot-path allocation | Major | performance |
| E014 | framework-specific logic in core | Major | architecture |
| E015 | unbounded telemetry | Major | observability |
| E016 | silent fallback | Major | correctness |
| E017 | stale decision cache | Major | policy |
| E018 | incorrect graph-key equality | Major | signatures |
| E019 | unsafe workspace reuse | Critical | contracts |
| E020 | stale capability cache | Major | compatibility |
| E021 | driver/runtime mismatch handling defect | Major | compatibility |
| E022 | third-party license/provenance omission | Critical | release |
| E023 | ABI instability | Major | public API |
| E024 | graph registry race | Critical | concurrency (registry not implemented; single-runtime mutex only) |
| E025 | deadlock during lifecycle transition | Critical | concurrency (callback re-entry prohibited; broader lifecycle validation pending) |
| E026 | NaN/Inf cost-model propagation | Major | policy |
| E027 | timing overflow/negative delta | Major | measurement |
| E028 | incorrect percentile calculation | Major | benchmark |
| E029 | cold-start cost omitted | Major | policy |
| E030 | graph memory omitted from total budget | Critical | memory |
| E031 | synthetic-only benchmark claim | Major | evidence |
| E032 | instrumentation changes workload behavior | Major | measurement |
| E033 | low-confidence measurements admit unstable policy | Major | policy |
| E034 | hysteresis masks safety constraint failure | Critical | policy |
| E035 | graph-variant budget counted inconsistently across duplicate definitions | Major | policy |
| E036 | stale memory snapshot between observation and admission | Major | memory policy |
| E037 | inconsistent or double-counted memory accounting domains | Major | memory policy |
| E038 | capture callback re-enters runtime and deadlocks lifecycle mutex | Major | CUDA runtime (documented callback non-reentrancy) |
| E039 | runtime object lifetime overlaps concurrent lifecycle call | Critical | concurrency (externally synchronized lifetime required) |
| E040 | residency metadata diverges from physical CUDA graph lifecycle | Critical | fallback/eviction (v0.7 one-eviction acknowledgement protocol) |
| E041 | non-blocking graph destruction falsely credited as immediate memory reclamation | Critical | eviction (re-observation required) |
| E042 | pinned graph blocks all possible eviction progress | Major | residency (explicit PINNED_ONLY outcome) |
| E043 | invalid eviction mode silently selecting a lifecycle policy | Major | CUDA eviction API (explicit enum validation) |
| E044 | terminal CUDA fault masked as recoverable capture/update failure | Critical | safety (underlying CUDA error classification is preserved) |
| E045 | unknown CUDA/runtime error falls through to continued graph use | Critical | safety (unknown error quarantines by default) |
| E046 | quarantine cleared without external lifecycle reset | Critical | safety (explicit clear only; no implicit CUDA reset) |
| E047 | fatal device fault incorrectly recovered by eager fallback | Critical | safety (terminal state requires process restart) |
| E048 | concurrent use of one shadow controller races trace/report state | Major | shadow release (controller explicitly requires external serialization) |
