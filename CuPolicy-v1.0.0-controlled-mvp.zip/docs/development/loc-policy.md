# LOC policy

LOC is an engineering signal, not a quality metric.

Report these categories separately:

- authored production code;
- authored tests;
- authored benchmarks;
- generated code;
- third-party source;
- documentation/configuration.

Do not use GitHub language percentages as the authoritative LOC report.

## Initial budgets

| Release | Authored code budget |
|---|---:|
| v0.1 | <= 3,800 LOC including tests/tools |
| v0.5 | <= 9,500 LOC |
| v1.0 | target 13,000–22,000 LOC |

The budgets are guardrails, not optimization targets. A necessary, well-justified increase is preferable to compressed unsafe code. Generated documentation, build trees, lockfiles, and third-party source are excluded from authored-LOC budgets.
