# Development roadmap

## Stage 00 — qualification

Before runtime code is authorized:

- architecture contradiction review;
- dependency audit;
- license/provenance audit;
- CUDA semantic hazard register;
- measurement methodology;
- repository and CI baseline;
- documentation baseline.

## v0.1.x — foundation

- `v0.1.0` — initial public host-side vocabulary, C ABI version bridge, tests, strict warnings.
- `v0.1.1` — error/diagnostic refinements driven by real reproductions.
- `v0.1.2` — reproducibility and environment-fingerprint hardening.

CUDA execution semantics remain intentionally deferred.

## v0.2.x — observer

- `v0.2.0` — CPU-side observer scope, sampled/full modes, bounded atomic aggregates, non-owning callback sink, and an explicit overhead benchmark.
- `v0.2.1` — documentation/release-integrity patch; no runtime behavior change.
- `v0.2.2` — observer correctness baseline.
- `v0.2.x` — subsequent observer fixes and benchmark methodology corrections driven by real reproductions.

CUDA event timing and GPU-side observation remain deferred until a CUDA-capable validation environment is available.

## v0.3.x — signatures/contracts

Workload, shape, metadata, stream, workspace, and lifetime representations.

## v0.4.x — policy simulator

- `v0.4.0` — deterministic host-side cost model, explicit partial observations, conservative graph admission, and shadow simulation.
- `v0.4.1` — evidence confidence, hysteresis, deterministic candidate grouping/variant budgets, and structured policy reporting.

CUDA runtime behavior remains deferred.

## v0.5.x — memory policy

- `v0.5.0` — explicit memory snapshots, total-budget accounting, graph-residency caps, reserved headroom, and memory-aware admission.
- `v0.5.x` — trace-backed memory pressure analysis and policy calibration.

## v0.6.x — graph runtime

- `v0.6.0` — optional CUDA Graph capture, launch, update, and safe fresh recapture backend.
- `v0.6.x` — GPU-backed compatibility matrix and Compute Sanitizer validation before any production compatibility claim.

## v0.7.x — fallback/eviction

- `v0.7.0` — deterministic graph-residency bookkeeping, LRU eviction planning, explicit CUDA graph eviction, and fallback lifecycle semantics.
- `v0.7.x` — GPU-backed eviction/release validation and memory-accounting calibration.

## v0.8.x — safety

- `v0.8.0` — explicit safety state machine, recoverable-fault escalation, graph quarantine, terminal device-fault handling, and CUDA error classification.
- `v0.8.x` — fault injection, CUDA-backed concurrency validation, and safety telemetry calibration.

## v0.9.x — shadow release

- `v0.9.0` — bounded shadow controller, baseline-vs-policy comparison, trace recording, regret-safe reporting, and explicit no-intervention invariant.
- `v0.9.x` — external trace ingestion, framework baseline adapters, and controlled evidence calibration.

## v1.0.0 — MVP

Single-GPU controlled execution policy with evidence-backed compatibility.

## v1.1+ — integrations

PyTorch first, then vLLM and SGLang if the benchmark evidence justifies adapters.
