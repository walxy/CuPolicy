# Quality gates

A release is not accepted because it compiles.

## Every change

- build;
- relevant unit tests;
- formatting/linting;
- documentation impact review.

## Performance changes

Must include before/after measurements and environment fingerprints. The v0.4 policy benchmark is a
host-side methodology probe and must not be presented as GPU or CUDA runtime overhead.

## High-risk CUDA changes

Must include reproduction, targeted regression test, CUDA semantic review, and Compute Sanitizer coverage where applicable.

## Policy-model changes

Cost-model changes must include boundary tests and an exact bounded-model regression against the
stated integer equation. Overflow behavior must be explicit and conservative.

## Refactoring

Minimalist refactoring is the default. Aggressive refactoring requires an explicit problem statement, evidence of measurable structural/performance value, impacted interfaces, and a rollback path.
