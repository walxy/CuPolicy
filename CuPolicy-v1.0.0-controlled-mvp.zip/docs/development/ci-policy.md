# CI policy

CI is divided into fast deterministic checks and environment-dependent checks.

## Required on every change

- CMake configure/build;
- Python quality checks once the locked environment is available;
- documentation build in strict mode;
- repository hygiene checks.

## GPU-dependent checks

These run in GPU-enabled CI and are not simulated by a CPU-only runner.

## Rule

A green repository-status page must never be interpreted as proof of CUDA correctness unless GPU integration tests and the relevant sanitizer/benchmark gates have run.
