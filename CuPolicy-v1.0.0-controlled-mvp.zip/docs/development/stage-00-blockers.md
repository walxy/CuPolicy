# Stage 00 blockers

These are the only known blockers to declaring the foundation independently reproducible in the current execution environment.

| Blocker | Status | Required resolution |
|---|---|---|
| Python package-index access | Open | Generate and commit `uv.lock` from a network-enabled, trusted environment |
| Python tool execution | Blocked by the lock issue | Run locked `ruff`, `ty`, and `pytest` after lock generation |
| MkDocs strict build | Blocked by the lock issue | Run `mkdocs build --strict` after lock generation |
| GPU runtime validation | Pending external environment | Run on a CUDA-capable CI/host before any CUDA runtime feature is accepted |
| Material lifecycle | Planned migration | Migrate before 2026-11-05, or document an explicit maintained replacement decision |
| Project name clearance | Not legal clearance | Run trademark/domain/package-name review before public launch |
