# v1.0 GPU qualification

This repository can be host-qualified without CUDA, but v1.0 production claims require a real NVIDIA GPU and CUDA Toolkit. The CUDA graph test target must compile and execute; a missing toolkit is a blocked external gate, not a pass.

## Required environment

- NVIDIA GPU with a supported driver.
- CUDA Toolkit 13.3.1 baseline for this release qualification.
- `nvcc` on `PATH`.
- CMake 3.28+ and Ninja.

## Qualification

```bash
cmake --preset cuda
cmake --build --preset cuda
ctest --preset cuda --output-on-failure
```

The CUDA suite must cover capture, launch, update success/rejection, failed-update preservation, recapture, stream mismatch, eviction, safety classification, and controlled graph launch. Run Compute Sanitizer on the CUDA test executable before declaring GPU qualification complete.

## Required evidence

Record GPU model, driver version, CUDA Toolkit version, OS, compiler, test output, and Compute Sanitizer output. Record memory measurements separately from logical residency accounting because CUDA free-memory observations are snapshots rather than reservations.

## Promotion rule

Only a successful GPU qualification record may change the project status from `GPU VALIDATION PENDING` to `GPU QUALIFIED`. External-environment waivers must not be used to convert an unexecuted CUDA test into PASS.
