# Dependency policy

## Principle

Reuse mature open-source infrastructure before writing equivalent infrastructure.

## Planned developer stack

| Need | Candidate | Decision |
|---|---|---|
| Python environment | uv 0.12.0 | Adopt |
| Python lint/format | Ruff 0.16.0 | Adopt/pin for reproducibility |
| Python type checking | ty 0.0.78 | Adopt/pin; ty is still pre-1.0 and can change diagnostics/API |
| C++ formatting | clang-format | Adopt |
| C++ static analysis | clang-tidy | Adopt |
| C++ tests | GoogleTest | Adopt |
| C++ benchmarks | Google Benchmark | Adopt |
| C++ formatting | fmt | Adopt only if needed by runtime |
| C++ logging | spdlog | Optional; do not add until logging needs exist |
| CLI | CLI11 | Optional; add when CLI exists |
| Python/C++ bindings | nanobind | Later, only when Python API exists |
| JSON | nlohmann/json | Later, control/diagnostic boundary only |

Dependencies are not added solely because they are popular. Every dependency must clear maintenance, API, license, security, transitive-dependency and integration checks.

## Documentation tool lifecycle

Material for MkDocs 9.7.7 is the required documentation theme for this project, but its maintainers have announced end of life for **2026-11-05**, with maintenance limited to critical fixes/security updates until then. The source documentation should therefore remain portable Markdown/MkDocs configuration, and migration to the announced successor should be scheduled before the EOL date.
