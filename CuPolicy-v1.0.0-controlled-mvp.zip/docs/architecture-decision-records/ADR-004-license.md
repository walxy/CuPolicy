# ADR-004: Project license

**Status:** Accepted for Stage 00

## Decision

Use Apache-2.0 for CuPolicy, subject to final legal/provenance review before public release.
