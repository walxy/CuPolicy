# ADR-003: Dependency strategy

**Status:** Accepted for Stage 00

## Decision

Adopt mature open-source infrastructure where it is a better-engineered solution than equivalent bespoke code. Keep the runtime dependency footprint small and auditable.
