# ADR-001: Product boundary

**Status:** Accepted for Stage 00

## Decision

CuPolicy is a framework-neutral execution-control layer, not a replacement for CUDA, CUDA-X, allocators, compilers, or framework runtimes.

## Rationale

The existing stack already supplies most low-level execution primitives. The candidate independent value is policy, safety, lifecycle, and cross-stack observability.
