# ADR-002: Refactoring strategy

**Status:** Accepted for Stage 00

## Decision

Use minimalist refactoring by default. Escalate to aggressive refactoring only when a defect, measurable performance issue, ownership ambiguity, or structural complexity justifies the change.
