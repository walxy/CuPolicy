# v0.2.x observer performance note

## Purpose

This benchmark measures the CPU-side overhead of the v0.2 observer. It is a host-only diagnostic benchmark and is **not** a CUDA performance claim.

## Environment

- CPU toolchain: GCC 14.2.0 / Clang 17.0.0
- Build: Release
- C++: C++20
- Iterations: 1,000,000 per run
- Observer workload: empty scope body
- Timing: `std::chrono::steady_clock`

## Observed run

A representative GCC Release run before the v0.2.2 sampling-only correction reported approximately:

| Case | ns/iteration |
|---|---:|
| Baseline | 0.36 |
| Disabled observer | 4.01 |
| Sampled every 16th event | 29.25 |
| Full observer | 104.48 |

The baseline is intentionally minimal and should **not** be interpreted as a hardware timing floor. The useful comparison is the incremental cost between observer modes under the same executable and host conditions.

Five repeated Release runs gave approximately:

- disabled increment: 3.62–3.92 ns/iteration;
- sampled-16 increment: 28.30–30.72 ns/iteration;
- full increment: 88.65–116.17 ns/iteration.

The spread demonstrates ordinary host timing noise and is why these figures are treated as qualification data rather than a universal performance promise.

## Interpretation

The full observer currently performs two monotonic-clock reads plus atomic aggregate updates for each recorded event. It is therefore **not yet suitable as a claim of negligible hot-path overhead for GPU inference**. That decision must be made later using realistic CUDA/framework workloads.

The current design goal is to keep the observer:

- bounded in memory;
- allocation-free after construction;
- thread-safe for aggregate statistics;
- explicit about callback ownership and cost;
- removable through the disabled mode.

## Next validation

v0.2.x should add controlled microbenchmarks around realistic CPU scheduling/orchestration paths. GPU timing remains deferred until CUDA-capable validation is available.
