# Verification

The verification gate is intentionally layered:

1. clean CMake configure;
2. clean build;
3. Python environment resolution;
4. Ruff formatting/linting;
5. ty type checking;
6. Python tests;
7. documentation build in strict mode;
8. CMake install/export plus a clean external consumer;
9. policy arithmetic boundary and exhaustive bounded-model regression.

The v0.4/v0.5 host-side policy and memory layers are qualified without CUDA. The v0.6 CUDA Graph runtime and v0.7 eviction lifecycle additionally require a CUDA Toolkit/device-backed test environment; CTest return code 77 marks the GPU test as skipped when no device is available, never as a PASS.
