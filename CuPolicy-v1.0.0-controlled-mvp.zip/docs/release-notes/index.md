- [1.0.0](1.0.0.md) — Controlled single-GPU MVP
- [0.9.0](0.9.0.md) — Shadow Release
- [0.7.0](0.7.0.md) — Fallback and Eviction
# Release notes

- [0.6.0](0.6.0.md) — Graph Runtime
- [0.5.0](0.5.0.md) — Memory Policy
- [0.4.1](0.4.1.md) — Policy refinements
- [0.4.0](0.4.0.md) — Policy Simulator
- [0.3.2](0.3.2.md) — Contract diagnostics
- [0.3.1](0.3.1.md) — Contract hardening
- [0.3.0](0.3.0.md) — Execution Identity & Contracts
