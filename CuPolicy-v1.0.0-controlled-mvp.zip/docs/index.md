# CuPolicy

CuPolicy is a proposed lightweight execution-control layer for CUDA workloads.

The project is currently at **v1.0.0 controlled single-GPU MVP**. The current implementation objective is to prove that a framework-neutral policy layer can make better execution-mode decisions than existing defaults on realistic dynamic workloads without compromising correctness, capacity, or memory safety.

## Current implementation rule

No optimization is enabled merely because it is possible. The initial releases are measurement-first and shadow-mode-first.
