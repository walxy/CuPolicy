# Licensing

## Project license

Project license: **Apache-2.0** (foundation decision; final public-release legal review still required).

The project should use permissive dependencies where practical. Preferred dependency licenses are MIT, BSD-2-Clause, BSD-3-Clause, and Apache-2.0.

GPL/AGPL/SSPL dependencies should not enter the core runtime without an explicit legal and architecture review.

## CUDA

NVIDIA CUDA Toolkit components are subject to NVIDIA's licensing terms; they are not treated as ordinary MIT/BSD dependencies. The project should require CUDA to be installed externally and must not casually vendor toolkit files. Redistribution of NVIDIA components must follow NVIDIA's applicable terms.

## Provenance

For every distributed third-party component, record:

- project;
- version/commit;
- source URL;
- license;
- whether source is vendored, linked, generated, or build-only;
- applicable attribution/NOTICE obligations.

Do not copy framework source merely to reproduce a behavior that can be implemented against a documented API.

## CI action supply chain

GitHub Actions used for public CI should be pinned to immutable commit SHAs before the first public release. Major-version tags are convenient during development but are not the final supply-chain posture.
