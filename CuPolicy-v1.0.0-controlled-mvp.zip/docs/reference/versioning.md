# Versioning

## Project

Semantic Versioning: `MAJOR.MINOR.PATCH`.

## Experimental releases

`0.x` may contain intentional API changes, but every breaking change must be documented.

## Stable releases

`1.x` establishes a compatibility contract. Breaking public API or ABI changes require a major release unless an explicitly documented compatibility mechanism is used.

## Independent schemas

Track separately:

- project version;
- public API version;
- ABI version;
- policy schema version;
- telemetry schema version.
