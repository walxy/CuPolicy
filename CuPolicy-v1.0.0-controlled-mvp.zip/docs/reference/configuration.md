# Configuration

The public runtime configuration schema is not formalized yet. v1.0.0 exposes the policy model, a controlled execution controller, an opt-in CUDA Graph runtime backend, and a bounded non-intervening shadow controller as typed C++ values.

Memory policy currently has three distinct concepts:

```text
MemorySnapshot
  device_budget_bytes
  non_graph_resident_bytes
  graph_resident_bytes

MemoryConstraints
  require_memory_evidence
  max_graph_resident_bytes
  min_free_bytes_after_admission

PolicyConstraints
  max_graph_memory_bytes      # per-candidate limit retained from v0.4
  memory                       # v0.5 memory-policy limits
```

A backend should populate `MemorySnapshot` from a coherent accounting domain at the policy decision boundary. CuPolicy does not own the allocator and does not reinterpret framework-specific pool statistics as equivalent values.

The future YAML/JSON schema will be formalized only after the memory policy has been validated against real CUDA traces.
