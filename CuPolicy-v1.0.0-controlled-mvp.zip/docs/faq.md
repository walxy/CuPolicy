# FAQ

## Does CuPolicy replace CUDA?

No.

## Does it replace CUDA Graphs?

No. CUDA Graphs are an execution mechanism that CuPolicy may select.

## Does it replace PyTorch, vLLM, SGLang, or TensorRT?

No. Framework integration is intended to be adapter-based.

## Is it production-ready?

No. The project is currently at v0.1.0 foundation / pre-alpha.

## Why use uv, Ruff, and ty?

They improve Python environment reproducibility and developer feedback. They are not CUDA runtime optimizers.

## Why not build a custom allocator?

CUDA already provides stream-ordered memory allocation, and mature higher-level memory-resource systems exist. The proposed project focuses on policy rather than replacing the allocator.
