# Third-party software inventory

This repository contains **no vendored third-party source**. The table records planned developer dependencies and their licenses; exact resolved versions must be captured in `uv.lock`/vcpkg manifests before public release.

| Component | Purpose | License | Distribution posture |
|---|---|---|---|
| uv | Python project/dependency management | Apache-2.0 OR MIT | developer/CI tool |
| Ruff | Python lint/format | MIT | developer/CI tool |
| ty | Python type checking | MIT | developer/CI tool |
| Material for MkDocs | documentation theme | MIT | developer/docs tool; EOL 2026-11-05 |
| GoogleTest | C++ tests | BSD-3-Clause | build/test dependency |
| Google Benchmark | C++ benchmarks | Apache-2.0 | build/test dependency |
| fmt | C++ formatting | MIT | optional runtime/build dependency |
| spdlog | logging | MIT | optional runtime/build dependency |
| CLI11 | CLI parsing | BSD-3-Clause | optional developer/runtime dependency |
| nanobind | Python/C++ bindings | BSD-3-Clause | future optional dependency |
| nlohmann/json | control-plane JSON | MIT | future optional dependency |
| NVIDIA CUDA Toolkit | GPU runtime/toolchain | NVIDIA license terms | external system dependency; do not vendor casually |

This is an engineering inventory, not legal advice. Before distributing binaries or source containing third-party code, regenerate the inventory from the exact resolved dependency graph and preserve all required attribution notices.
