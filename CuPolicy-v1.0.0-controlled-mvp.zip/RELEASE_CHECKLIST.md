# Release checklist

## Before a public release

Internal development tags may be created before external-environment gates are available, but they must never be presented as production releases.

## Before tagging/public release

- [ ] Project version agrees across CMake, Python metadata, CITATION.cff, and changelog.
- [ ] `uv.lock` is generated in a trusted network-enabled environment and committed.
- [ ] Exact third-party dependency graph is captured and license-reviewed.
- [ ] CUDA compatibility is tested, not inferred.
- [ ] Unit/integration tests pass.
- [ ] Sanitizer checks relevant to the release pass.
- [ ] Documentation builds in strict mode.
- [ ] Benchmark results include environment fingerprints and methodology.
- [ ] Public CI action references are pinned to immutable SHAs.
- [ ] Release notes list added/changed/fixed/performance/compatibility/known limitations.
- [ ] Source archive contains no build output, secrets, local caches, or private assets.
