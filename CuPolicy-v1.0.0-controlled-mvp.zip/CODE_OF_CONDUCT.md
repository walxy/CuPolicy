# Code of Conduct

The project expects respectful, professional, technically substantive collaboration. Harassment, discrimination, malicious behavior, and deliberate obstruction of safety or correctness investigations are not acceptable.
