# SPDX-License-Identifier: Apache-2.0
"""Static repository consistency checks for the current source release."""

from pathlib import Path
import re
import tomllib

ROOT = Path(__file__).resolve().parents[1]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def main() -> int:
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text())
    version = pyproject["project"]["version"]
    require(re.fullmatch(r"\d+\.\d+\.\d+", version) is not None, f"version: {version}")
    require(pyproject["project"]["license"] == "Apache-2.0", "project license")
    require(pyproject["tool"]["uv"]["package"] is False, "uv package setting")
    require(
        pyproject["tool"]["uv"]["required-version"] == ">=0.12.0,<0.13",
        "uv version constraint",
    )

    cmake = (ROOT / "CMakeLists.txt").read_text()
    require(re.search(r"project\(CuPolicy\s+VERSION\s+" + re.escape(version) + r"\b", cmake) is not None, "CMake project version")

    version_h = (ROOT / "include/cupolicy/version.hpp").read_text()
    require(re.search(r'kVersion\s*=\s*"' + re.escape(version) + r'"', version_h) is not None, "C++ version constant")
    major, minor, patch = (int(part) for part in version.split("."))
    require(re.search(r'kVersionMajor\s*=\s*' + str(major) + r'\b', version_h) is not None, "C++ major version constant")
    require(re.search(r'kVersionMinor\s*=\s*' + str(minor) + r'\b', version_h) is not None, "C++ minor version constant")
    require(re.search(r'kVersionPatch\s*=\s*' + str(patch) + r'\b', version_h) is not None, "C++ patch version constant")

    cff = (ROOT / "CITATION.cff").read_text()
    require(f"version: {version}" in cff, "CITATION version")

    changelog = (ROOT / "CHANGELOG.md").read_text()
    require(f"## [{version}]" in changelog or f"## {version}" in changelog, "CHANGELOG version")

    mkdocs = (ROOT / "mkdocs.yml").read_text()
    for target in re.findall(r": ([^\n]+\.md)", mkdocs):
        require((ROOT / "docs" / target).exists(), f"missing docs target: {target}")
    require("example.invalid" not in mkdocs, "placeholder documentation URL")

    required_files = [
        ROOT / "include/cupolicy/version.hpp",
        ROOT / "include/cupolicy/status.hpp",
        ROOT / "include/cupolicy/execution.hpp",
        ROOT / "include/cupolicy/workload.hpp",
        ROOT / "include/cupolicy/observation.hpp",
        ROOT / "include/cupolicy/contracts.hpp",
        ROOT / "include/cupolicy/execution_identity.hpp",
        ROOT / "include/cupolicy/policy.hpp",
        ROOT / "include/cupolicy/c_api.h",
        ROOT / "include/cupolicy/cuda_graph.hpp",
        ROOT / "include/cupolicy/residency.hpp",
        ROOT / "include/cupolicy/safety.hpp",
        ROOT / "src/c_api.cpp",
        ROOT / "src/observer.cpp",
        ROOT / "src/policy.cpp",
        ROOT / "src/cuda_graph.cpp",
        ROOT / "src/residency.cpp",
        ROOT / "src/safety.cpp",
        ROOT / "tests/cpp/test_foundation.cpp",
        ROOT / "tests/cpp/test_observer.cpp",
        ROOT / "tests/cpp/test_contracts.cpp",
        ROOT / "tests/cpp/test_policy.cpp",
        ROOT / "tests/cpp/test_cuda_graph.cpp",
        ROOT / "tests/cpp/test_residency.cpp",
        ROOT / "tests/cpp/test_safety.cpp",
        ROOT / "docs/development/v0.2-observer.md",
        ROOT / "docs/performance-v0.2-observer.md",
        ROOT / "docs/development/v0.3-execution-identity.md",
        ROOT / "docs/development/v0.5-memory-policy.md",
        ROOT / "docs/development/v0.5-validation.md",
        ROOT / "docs/development/v0.6-graph-runtime.md",
        ROOT / "docs/development/v0.7-fallback-eviction.md",
        ROOT / "docs/development/v0.7-validation.md",
        ROOT / "docs/release-notes/0.6.0.md",
        ROOT / "docs/release-notes/0.8.0.md",
        ROOT / "docs/development/v0.8-safety.md",
        ROOT / "docs/development/v0.8-validation.md",
        ROOT / "include/cupolicy/shadow.hpp",
        ROOT / "src/shadow.cpp",
        ROOT / "tests/cpp/test_shadow.cpp",
        ROOT / "benchmarks/cpp/bench_shadow.cpp",
        ROOT / "benchmarks/cpp/bench_control.cpp",
        ROOT / "docs/release-notes/0.9.0.md",
        ROOT / "docs/release-notes/1.0.0.md",
        ROOT / "docs/development/v1.0-mvp.md",
        ROOT / "docs/development/v1.0-validation.md",
        ROOT / "docs/development/gpu-qualification.md",
        ROOT / "include/cupolicy/control.hpp",
        ROOT / "src/control.cpp",
        ROOT / "tests/cpp/test_control.cpp",
        ROOT / "docs/development/v0.9-shadow-release.md",
        ROOT / "docs/development/v0.9-validation.md",
        ROOT / "docs/error-register.md",
    ]
    for path in required_files:
        require(path.exists(), f"missing required file: {path}")

    readme = (ROOT / "README.md").read_text()
    require("v0.9.0 shadow release" not in readme, "README stale current release")

    source = (ROOT / "src/c_api.cpp").read_text()
    require("cupolicy_version" in source, "C API implementation")
    require("kVersion" in source, "C API version source")

    print(f"Repository v{version} consistency: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
