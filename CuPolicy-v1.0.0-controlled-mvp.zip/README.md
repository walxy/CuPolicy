# CuPolicy

**Adaptive GPU execution policy for CUDA workloads.**

> Status: v1.0.0 controlled single-GPU MVP; shadow release, safety controller, fallback/eviction, and optional CUDA Graph runtime are included. Controlled graph launch is explicit and disabled by default.

CuPolicy is being designed as a small, framework-neutral execution-control layer for CUDA workloads. The intended role is to decide when existing execution mechanisms—such as eager execution and CUDA Graphs—are justified under performance, memory, lifecycle, and safety constraints.

## Scope

The first implementation target is **single-GPU, measurement-first execution policy**. The project does not intend to replace CUDA, CUDA-X libraries, PyTorch, TensorRT, vLLM, SGLang, allocators, compilers, or kernel libraries.

## Current status

The current v1.0.0 release adds a framework-neutral controlled execution controller alongside the explicit shadow controller. Shadow mode compares the current eager/graph baseline with the policy recommendation, records bounded trace entries, reports estimated prospective benefit without inventing constrained regret, and never mutates execution. Controlled mode is opt-in and can launch an already-available graph only when policy and safety permit it; capture/update/recapture/eviction remain explicit lifecycle operations.

- requirements and architectural qualification;
- host-side public API vocabulary and observer tests;
- dependency and license policy;
- reproducible development tooling;
- error taxonomy and validation plan;
- benchmark methodology;
- documentation structure;
- Git/release conventions.

The CUDA backend is optional and must be enabled explicitly with `CUPOLICY_ENABLE_CUDA=ON`; GPU validation is required before any production compatibility claim. The observer currently measures CPU-side elapsed time only; GPU timing is intentionally deferred until CUDA validation is available.

**Release qualification:** v1.0.0 is a source-qualified controlled single-GPU MVP with comprehensive host-side validation and an explicitly pending NVIDIA GPU qualification gate.

## Development roadmap

- `v0.2.2` — observer correctness baseline
- `v0.3.2` — execution identity & contracts
- `v0.5.0` — memory-aware policy simulator
- `v0.8.0` — safety controller
- `v0.9.0` — shadow release
- `v1.0.0` — controlled single-GPU MVP (current)

See [`docs/development/roadmap.md`](docs/development/roadmap.md).

## Engineering principles

1. **Evidence before optimization.**
2. **Reuse mature infrastructure before implementing equivalents.**
3. **Minimalist refactoring is the default; aggressive refactoring is evidence-gated.**
4. **No performance claim without a controlled benchmark.**
5. **No automatic optimization without a defined safe fallback.**
6. **No third-party source copied without provenance and license review.**
7. **Core policy remains framework-neutral.**
8. **Errors must be reproducible, classified, and regression-tested.**

## License

CuPolicy is licensed under Apache-2.0 in the current source tree; final public-distribution review remains required. See [`LICENSE`](LICENSE) and [`docs/reference/licensing.md`](docs/reference/licensing.md).

## Name status

`CuPolicy` / `cupolicy` is a **provisional project name**. An initial GitHub/public-web search did not surface an exact CUDA project using the same name, but this is not trademark or legal clearance. The name must be rechecked before public launch.
