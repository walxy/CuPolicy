# Changelog

## 1.0.0

- Added the controlled single-GPU execution controller over the existing policy, memory, residency, graph-runtime, and safety layers.
- Added explicit `SHADOW` and opt-in `CONTROLLED` execution modes; shadow mode never intervenes.
- Added fail-closed backend validation and terminal-safety blocking.
- Added tests for graph success, unavailable-graph eager fallback, recoverable graph failure, terminal fault blocking, malformed configuration, and shadow non-intervention.

### Validation and qualification

- v1.0.0 is a source-qualified controlled single-GPU MVP with comprehensive host-side validation and an explicitly pending NVIDIA GPU qualification gate.
- NVIDIA GPU/CUDA runtime qualification remains pending in environments without NVIDIA hardware and the CUDA Toolkit.

## 0.7.0

### Added
- Deterministic `ResidencyController` with pinned-graph support and LRU eviction selection.
- Explicit CUDA Graph eviction API with non-blocking and wait-for-completion modes.
- Fallback/eviction validation and residency regression coverage, including overflow and pinned-only edge cases.

### Changed
- Residency evaluation is non-mutating; physical CUDA eviction must be acknowledged separately before admission is retried.
- Non-blocking CUDA graph eviction is explicitly documented as allowing deferred physical resource release.

### Validation
- GCC/Clang host profiles and ASan/UBSan are revalidated for v0.7.0; TSan remains required where supported.
- CUDA/GPU eviction and release validation remains external without NVIDIA hardware and CUDA Toolkit.

## 0.6.0

### Added
- Optional CUDA Runtime API backend for controlled CUDA Graph capture, launch, update, and safe fresh recapture.
- RAII ownership of CUDA graph and executable-graph handles inside the runtime backend.
- Conservative same-stream launch/update/recapture validation.
- CUDA graph update-result diagnostics.
- CUDA integration tests with explicit CTest skip semantics when no GPU is available.

### Changed
- CUDA is now an explicit opt-in backend via `CUPOLICY_ENABLE_CUDA=ON`; host-only builds remain CUDA-independent.
- Failed capture, failed instantiation, and rejected graph updates never replace an installed executable graph.
- Empty captured graphs are rejected as non-useful execution artifacts.

### Validation
- GCC/Clang host builds and ASan/UBSan/TSan suites remain required and were revalidated.
- CUDA/GPU graph-runtime validation remains external in environments without NVIDIA hardware and CUDA Toolkit.

## 0.5.0

### Added
- Explicit `MemorySnapshot` accounting context separated from execution-definition identity.
- Deterministic `MemoryPolicyEvaluator` for total-device budget, graph-residency budget, reserved headroom, and current-usage validation.
- Memory-aware graph admission in the offline policy simulator.
- Candidate-side memory snapshots representing the decision boundary so duplicate-definition accounting does not reconstruct residency heuristically.
- Regression tests covering overflow-safe bounded accounting, monotonicity, missing evidence, current overcommitment, graph caps, total budget, and reserved headroom.

### Changed
- Offline simulation now retains actual accepted capture-definition bookkeeping; it is not `noexcept` because the simulator may allocate bounded definition tracking storage.
- v0.5 keeps memory policy out of the allocator/runtime layer: the backend is responsible for supplying a coherent accounting snapshot.

### Validation
- Host-side policy and memory-model validation included in the release suite.
- CUDA/GPU runtime memory attribution remains external/pending.

## 0.4.1

### Added
- Evidence confidence and minimum timing-sample gates for policy admission.
- Benefit-threshold hysteresis for candidates already running as CUDA Graphs in future runtime integration.
- Deterministic capture-definition grouping and bounded graph-variant admission in simulation.
- Structured simulator counters for confidence, hysteresis, grouping, and variant-budget outcomes.
- Policy-constraint validation and regression coverage for invalid configuration.

### Validation
- Host-side policy simulator and bounded integer-model tests are included in the release suite.
- CUDA/GPU runtime validation remains external/pending.
- This release does not implement CUDA graph capture, replay, or runtime intervention.

## 0.4.0

### Added
- Explicit partial `ObservedExecution` representation separate from complete `ExecutionIdentity`.
- Deterministic host-side policy evaluator using integer nanosecond/byte arithmetic.
- Conservative graph admission gates for evidence completeness, contract safety, graph availability, reuse, memory budget, and amortization.
- Explainable policy decision reasons and a trace-oriented simulator with bounded summaries.
- Regression tests and a policy evaluation benchmark.

### Validation
- Host-side policy simulator validation is included in the release test suite.
- CUDA/GPU runtime validation remains external/pending.

## 0.3.2

### Changed
- Corrected release metadata and validation records after contract-hardening work landed in v0.3.1.
- Added repository checks for numeric C++ version components as well as the public version string.
- Clarified complete-identity semantics and non-persistent identity-hash semantics.

### Validation
- Host compiler and sanitizer profiles revalidated.
- CUDA/GPU validation remains external/pending.
- Locked Python/MkDocs validation remains external/pending.

## 0.3.1

### Added
- Explicit contract-validation diagnostics and `ExecutionIdentity::validate()`.
- Regression tests for resource, lifetime, capacity, stream, and dependency issue codes.

### Changed
- Clarified that contract validation reports logical invariants but does not prove CUDA runtime/event existence.
- Kept identity hashes explicitly non-persistent and cache-oriented.

### Validation
- Host-side contract suite updated and revalidated.
- CUDA/GPU validation remains external/pending.

## 0.3.0

### Added
- Owning workload signatures and explicit resource, workspace, and stream contracts.
- Execution identity with separate capture-definition and full replay-contract comparisons.
- Order-sensitive deterministic hashing for capture definitions and full identities.

### Validation
- Host-side contract tests, including capacity/lifetime/resource-state changes.
- CUDA/GPU validation remains external/pending.

## 0.2.2

### Fixed
- Correct sampled-observation sequencing so `sample_every=N` records events 1, 1+N, 1+2N, ... rather than an off-by-one pattern.
- Added regression coverage for sampled sequence numbers, operation IDs, and `sample_every=1`.
- Added explicit Debug, Release, ASan, and TSan CMake presets for reproducible host-side validation.

### Validation
- GCC 14.2 Debug/Release: PASS
- Clang 17 Debug/Release: pending rerun
- ASan/UBSan: pending rerun
- TSan: pending rerun
- CUDA/GPU: external environment pending

All notable changes to CuPolicy will be documented here.

## [0.2.1] — Observer patch

### Changed

- corrected release metadata/documentation consistency after the v0.2.0 implementation tag;
- refreshed Stage 00 validation records to distinguish historical qualification from the current observer release.

### Known limitations

- no CUDA runtime integration;
- no GPU-side timing;
- no graph capture/replay;
- no policy engine.

## [0.2.0] — Observer

### Added

- CPU-side execution observer with disabled, sampled and full modes;
- bounded atomic observer aggregates;
- non-owning callback sink for sampled observations;
- observer regression tests, including concurrent scope completion;
- CPU observer overhead benchmark.

### Fixed

- release-test version drift inherited from v0.1.0;
- counter wraparound by saturating observer counters;
- Clang portability by disabling unused CMake module dependency scanning;
- explicit thread-library linkage for observer tests.

### Known limitations

- no CUDA runtime integration;
- no GPU-side timing;
- no graph capture/replay;
- no policy engine.

## [0.1.0] — Foundation

### Added

- repository foundation;
- public host-side C++ API vocabulary;
- C ABI version query;
- host-side regression test;
- engineering policies and error register;
- CMake and Python toolchain manifests;
- initial documentation architecture.

### Known limitations

- no CUDA runtime implementation;
- no graph capture/replay;
- no framework adapters;
- no production compatibility claim.
