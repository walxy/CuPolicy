// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/safety.hpp"

#include <cstdlib>
#include <iostream>
#include <limits>

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

}  // namespace

int main() {
    using namespace cupolicy;

    require(to_string(SafetyState::kHealthy) == "HEALTHY", "state string");
    require(to_string(SafetyAction::kRequireProcessRestart) == "REQUIRE_PROCESS_RESTART",
            "action string");
    require(to_string(SafetyEventKind::kIllegalAddress) == "ILLEGAL_ADDRESS", "event string");

    SafetyController controller;
    const auto good_contract = controller.observe({SafetyEventKind::kGraphUpdateRejected, 910, 7});
    require(good_contract.ok(), "recoverable event accepted");
    require(good_contract.state == SafetyState::kDegraded, "recoverable fault degrades state");
    require(good_contract.action == SafetyAction::kFallbackEager, "recoverable fault falls back");
    require(good_contract.consecutive_recoverable_faults == 1, "fault count increments");

    const auto second_fault = controller.observe({SafetyEventKind::kOutOfMemory, 2, 7});
    require(second_fault.action == SafetyAction::kFallbackEager, "second recoverable fault falls back");
    const auto third_fault = controller.observe({SafetyEventKind::kTransientRuntimeError, 999, 7});
    require(third_fault.state == SafetyState::kQuarantined, "threshold quarantines graph");
    require(third_fault.action == SafetyAction::kQuarantineGraph, "threshold quarantines action");
    require(controller.graph_quarantined(), "quarantine bit is set");

    const auto blocked_recovery = controller.recover();
    require(blocked_recovery.action == SafetyAction::kQuarantineGraph,
            "quarantine cannot be cleared by ordinary recovery");
    require(controller.state() == SafetyState::kQuarantined, "quarantine remains active");

    const auto cleared = controller.clear_quarantine();
    require(cleared.ok(), "explicit quarantine clear succeeds");
    require(controller.state() == SafetyState::kHealthy, "explicit clear restores healthy state");
    require(!controller.graph_quarantined(), "explicit clear removes quarantine");

    SafetyController terminal;
    const auto fatal = terminal.observe({SafetyEventKind::kIllegalAddress, 700, 3});
    require(fatal.state == SafetyState::kTerminal, "fatal device fault becomes terminal");
    require(fatal.action == SafetyAction::kRequireProcessRestart, "fatal device fault requires restart");
    const auto fatal_kind = terminal.observe({SafetyEventKind::kFatalDeviceFault, 710, 3});
    require(fatal_kind.error == SafetyErrorCode::kTerminalState, "terminal remains sticky across fatal classes");
    const auto terminal_again = terminal.observe({SafetyEventKind::kGraphUpdateRejected, 910, 3});
    require(terminal_again.error == SafetyErrorCode::kTerminalState, "terminal state rejects further recovery");
    require(terminal_again.action == SafetyAction::kRequireProcessRestart, "terminal state stays fail-safe");
    const auto terminal_clear = terminal.clear_quarantine();
    require(terminal_clear.error == SafetyErrorCode::kTerminalState, "terminal state cannot be cleared");

    SafetyController unknown;
    const auto unknown_event = unknown.observe({SafetyEventKind::kUnknownRuntimeError, 999, 12});
    require(unknown_event.state == SafetyState::kQuarantined, "unknown runtime fault quarantines conservatively");
    require(unknown_event.action == SafetyAction::kQuarantineGraph, "unknown runtime fault does not fall back silently");

    const auto invalid_event = controller.observe(
        {static_cast<SafetyEventKind>(255U), 0, 0});
    require(invalid_event.error == SafetyErrorCode::kInvalidEvent, "invalid event is rejected");
    require(controller.state() == SafetyState::kHealthy, "invalid event cannot alter state");

    return EXIT_SUCCESS;
}
