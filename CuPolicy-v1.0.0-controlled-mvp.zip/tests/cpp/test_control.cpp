// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/control.hpp"
#include "cupolicy/execution.hpp"

#include <cstdint>
#include <cstdlib>
#include <limits>

namespace {

int g_eager_calls = 0;
int g_graph_calls = 0;

bool eager_success(void*) noexcept {
    ++g_eager_calls;
    return true;
}

bool eager_failure(void*) noexcept {
    ++g_eager_calls;
    return false;
}

bool graph_available(void*) noexcept { return true; }

cupolicy::BackendStatus graph_success(void*) noexcept {
    ++g_graph_calls;
    return {cupolicy::BackendStatusCode::kOk, cupolicy::SafetyEventKind::kNone, 0};
}

cupolicy::BackendStatus graph_recoverable_failure(void*) noexcept {
    ++g_graph_calls;
    return {cupolicy::BackendStatusCode::kFailed,
            cupolicy::SafetyEventKind::kCaptureFailure,
            719};
}

cupolicy::PolicyCandidate accepted_candidate() {
    cupolicy::PolicyCandidate candidate{};
    candidate.observation.capture_definition_id = 1;
    candidate.observation.eager_duration_ns = 200;
    candidate.observation.graph_replay_duration_ns = 100;
    candidate.observation.capture_duration_ns = 10;
    candidate.observation.instantiate_duration_ns = 10;
    candidate.observation.warmup_duration_ns = 10;
    candidate.observation.graph_memory_bytes = 64;
    candidate.observation.contract_issues = cupolicy::ContractIssue::kNone;
    candidate.observation.fields =
        cupolicy::ObservationField::kCaptureDefinition |
        cupolicy::ObservationField::kEagerDuration |
        cupolicy::ObservationField::kGraphReplayDuration |
        cupolicy::ObservationField::kCaptureDuration |
        cupolicy::ObservationField::kInstantiateDuration |
        cupolicy::ObservationField::kWarmupDuration |
        cupolicy::ObservationField::kGraphMemory |
        cupolicy::ObservationField::kContractValidation;
    candidate.observation.timing_samples = 10;
    candidate.observation.confidence = cupolicy::EvidenceConfidence::kHigh;
    candidate.expected_replays = 10;
    candidate.current_mode = cupolicy::ExecutionMode::kEager;
    candidate.memory = {4096, 0, 0,
                        cupolicy::MemoryField::kDeviceBudget |
                            cupolicy::MemoryField::kNonGraphResident |
                            cupolicy::MemoryField::kGraphResident};
    return candidate;
}

cupolicy::ControlBackend backend(cupolicy::GraphLaunchCallback launch) {
    return {graph_available, launch, nullptr};
}

void require(bool condition) {
    if (!condition) {
        std::abort();
    }
}

}  // namespace

int main() {
    using namespace cupolicy;

    const PolicyConstraints constraints{};
    const PolicyCandidate candidate = accepted_candidate();
    require(PolicyEvaluator::evaluate(candidate, constraints).decision.mode == ExecutionMode::kGraph);

    g_eager_calls = 0;
    g_graph_calls = 0;
    ControlController shadow(ControlConfig{ControlMode::kShadow, false, true});
    const ControlResult shadow_result =
        shadow.execute(candidate, constraints, backend(graph_success), eager_success);
    require(shadow_result.ok());
    require(shadow_result.action == ControlAction::kShadowOnly);
    require(!shadow_result.intervention_performed);
    require(g_eager_calls == 0 && g_graph_calls == 0);

    ControlController controlled(ControlConfig{ControlMode::kControlled, true, true});
    const ControlResult graph_result =
        controlled.execute(candidate, constraints, backend(graph_success), eager_success);
    require(graph_result.ok());
    require(graph_result.action == ControlAction::kExecuteGraph);
    require(graph_result.graph_executed);
    require(graph_result.intervention_performed);
    require(g_graph_calls == 1);
    require(g_eager_calls == 0);

    PolicyCandidate graph_baseline = candidate;
    graph_baseline.current_mode = ExecutionMode::kGraph;
    ControlController graph_baseline_controller(ControlConfig{ControlMode::kControlled, true, true});
    const ControlResult graph_baseline_result =
        graph_baseline_controller.execute(graph_baseline, constraints, backend(graph_success), eager_success);
    require(graph_baseline_result.ok());
    require(graph_baseline_result.action == ControlAction::kExecuteGraph);
    require(!graph_baseline_result.intervention_performed);

    PolicyCandidate eager_candidate_no_backend = candidate;
    eager_candidate_no_backend.expected_replays = 0;
    ControlController eager_without_backend(ControlConfig{ControlMode::kControlled, true, true});
    const ControlResult eager_without_backend_result =
        eager_without_backend.execute(eager_candidate_no_backend, constraints, ControlBackend{}, eager_success);
    require(eager_without_backend_result.ok());
    require(eager_without_backend_result.action == ControlAction::kExecuteEager);
    require(eager_without_backend_result.eager_executed);

    ControlController unavailable(ControlConfig{ControlMode::kControlled, true, true});
    ControlBackend unavailable_backend{
        [](void*) noexcept { return false; }, graph_success, nullptr};
    const ControlResult unavailable_result =
        unavailable.execute(candidate, constraints, unavailable_backend, eager_success);
    require(unavailable_result.ok());
    require(unavailable_result.action == ControlAction::kFallbackEager);
    require(unavailable_result.eager_executed);

    ControlController recovery(ControlConfig{ControlMode::kControlled, true, true});
    const ControlResult recovery_result =
        recovery.execute(candidate, constraints, backend(graph_recoverable_failure), eager_success);
    require(recovery_result.ok());
    require(recovery_result.action == ControlAction::kFallbackEager);
    require(recovery_result.eager_executed);
    require(recovery.safety().state() == SafetyState::kDegraded);

    ControlController terminal(ControlConfig{ControlMode::kControlled, true, true});
    ControlBackend terminal_backend{
        graph_available,
        [](void*) noexcept {
            ++g_graph_calls;
            return BackendStatus{BackendStatusCode::kFailed,
                                 SafetyEventKind::kIllegalAddress,
                                 700};
        },
        nullptr};
    const ControlResult terminal_result =
        terminal.execute(candidate, constraints, terminal_backend, eager_success);
    require(!terminal_result.ok());
    require(terminal_result.action == ControlAction::kBlockExecution);
    require(!terminal_result.eager_executed);
    require(terminal.safety().state() == SafetyState::kTerminal);

    const ControlResult terminal_eager_result =
        terminal.execute(eager_candidate_no_backend, constraints, ControlBackend{}, eager_success);
    require(!terminal_eager_result.ok());
    require(terminal_eager_result.action == ControlAction::kBlockExecution);
    require(!terminal_eager_result.eager_executed);

    ControlController invalid_config(ControlConfig{static_cast<ControlMode>(255), false, true});
    const ControlResult invalid_result =
        invalid_config.execute(candidate, constraints, backend(graph_success), eager_success);
    require(!invalid_result.ok());
    require(invalid_result.error == ControlErrorCode::kInvalidConfiguration);

    ControlController no_launch_permission(ControlConfig{ControlMode::kControlled, false, true});
    require(!no_launch_permission.config().valid());

    ControlController no_callback(ControlConfig{ControlMode::kControlled, true, true});
    const ControlResult no_callback_result =
        no_callback.execute(candidate, constraints, backend(graph_success), nullptr);
    require(!no_callback_result.ok());
    require(no_callback_result.error == ControlErrorCode::kInvalidEagerCallback);

    ControlController eager_failure_controller(ControlConfig{ControlMode::kControlled, true, true});
    PolicyCandidate eager_candidate = candidate;
    eager_candidate.expected_replays = 0;
    const ControlResult eager_failure_result =
        eager_failure_controller.execute(eager_candidate, constraints, backend(graph_success), eager_failure);
    require(!eager_failure_result.ok());
    require(eager_failure_result.action == ControlAction::kBlockExecution);

    return 0;
}
