// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/residency.hpp"

#include <array>
#include <cstdlib>
#include <iostream>
#include <limits>

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

}  // namespace

int main() {
    using namespace cupolicy;

    ResidencyController controller(ResidencyConstraints{2, 100});
    require(controller.size() == 0, "controller starts empty");
    require(controller.resident_bytes() == 0, "controller starts at zero bytes");

    require(!controller.admit(0, 1, 10), "zero definition id rejected");
    require(!controller.admit(1, 0, 10), "zero graph id rejected");
    require(!controller.admit(1, 1, 101), "oversized candidate rejected");
    require(!controller.admit(1, 1, 10 + 100), "oversized candidate cannot be admitted");

    require(controller.admit(1, 11, 40), "first graph admitted");
    require(controller.admit(2, 12, 40), "second graph admitted");
    require(controller.contains(1) && controller.contains(2), "resident definitions tracked");
    require(controller.resident_bytes() == 80, "resident byte total tracked");

    const auto already = controller.evaluate(1, 11, 40);
    require(already.admissible, "same resident generation is accepted as a no-op");
    require(already.reason == ResidencyDecisionReason::kAlreadyResident,
            "already resident reason");

    const auto replacement = controller.evaluate(1, 99, 50);
    require(!replacement.admissible, "new generation requires explicit replacement");
    require(replacement.reason == ResidencyDecisionReason::kReplacementRequired,
            "replacement reason");
    require(replacement.replacement.has_value(), "replacement identifies prior generation");
    require(controller.replace(1, 99, 50), "replacement updates generation metadata");
    require(controller.find(1)->graph_id == 99, "replacement graph id stored");
    require(controller.resident_bytes() == 90, "replacement memory accounted");

    require(controller.touch(1), "touch updates recency");
    const auto victim = controller.next_eviction();
    require(victim.has_value(), "eviction candidate exists");
    require(victim->capture_definition_id == 2, "LRU chooses older definition");

    const auto byte_pressure = controller.evaluate(3, 13, 40);
    require(!byte_pressure.admissible, "candidate under byte pressure needs eviction");
    require(byte_pressure.reason == ResidencyDecisionReason::kEvictionRequired,
            "byte pressure requires eviction");
    require(byte_pressure.eviction.has_value(), "byte pressure returns eviction target");
    require(byte_pressure.eviction->capture_definition_id == 2,
            "byte pressure chooses LRU target");

    require(controller.pin(2), "pin succeeds");
    const auto pinned_victim = controller.next_eviction();
    require(pinned_victim.has_value(), "unpinned victim still exists");
    require(pinned_victim->capture_definition_id == 1, "pinned graph is never selected");
    require(controller.unpin(2), "unpin succeeds");
    require(!controller.unpin(2), "double unpin rejected");

    require(controller.remove(2), "physical eviction can be acknowledged");
    require(!controller.contains(2), "removed graph is absent");
    require(controller.resident_bytes() == 50, "resident bytes shrink after removal");
    require(controller.admit(3, 13, 40), "candidate admitted after successful eviction");
    require(controller.size() == 2, "graph count restored after replacement");
    require(controller.resident_bytes() == 90, "replacement bytes tracked");

    const auto touch_missing = controller.touch(99);
    require(!touch_missing, "touching missing definition is rejected");

    ResidencyController count_limited(ResidencyConstraints{1, 100});
    require(count_limited.admit(10, 20, 10), "count-limited first graph admitted");
    const auto count_pressure = count_limited.evaluate(11, 21, 10);
    require(!count_pressure.admissible, "count pressure requires eviction");
    require(count_pressure.reason == ResidencyDecisionReason::kEvictionRequired,
            "count pressure requires eviction");
    require(count_pressure.eviction.has_value(), "count pressure returns victim");
    require(count_pressure.eviction->capture_definition_id == 10, "count pressure victim");

    require(count_limited.pin(10), "pin count-limited graph");
    const auto pinned_only = count_limited.evaluate(11, 21, 10);
    require(!pinned_only.admissible, "pinned-only state rejects replacement");
    require(pinned_only.reason == ResidencyDecisionReason::kPinnedOnly,
            "pinned-only reason");
    require(count_limited.unpin(10), "unpin count-limited graph");

    const ResidencyController invalid(ResidencyConstraints{0, 100});
    const auto invalid_decision = invalid.evaluate(1, 1, 1);
    require(invalid_decision.reason == ResidencyDecisionReason::kInvalidConstraints,
            "invalid constraints are rejected");

    ResidencyController overflow(ResidencyConstraints{2, std::numeric_limits<std::uint64_t>::max()});
    require(overflow.admit(50, 60, std::numeric_limits<std::uint64_t>::max()),
            "max-size graph can be admitted alone");
    const auto overflow_eval = overflow.evaluate(51, 61, 1);
    require(!overflow_eval.admissible, "overflow candidate requires eviction");
    require(overflow_eval.eviction.has_value(), "overflow candidate selects victim");
    require(overflow_eval.reason == ResidencyDecisionReason::kEvictionRequired,
            "overflow candidate eviction reason");

    return EXIT_SUCCESS;
}
