// SPDX-License-Identifier: Apache-2.0
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <span>

#include "cupolicy/policy.hpp"

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "policy test failed: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

cupolicy::MemorySnapshot complete_memory() {
    using namespace cupolicy;
    return MemorySnapshot{
        16 * 1024,
        2 * 1024,
        4 * 1024,
        MemoryField::kDeviceBudget | MemoryField::kNonGraphResident | MemoryField::kGraphResident,
    };
}

cupolicy::ObservedExecution complete_observation() {
    using namespace cupolicy;
    return ObservedExecution{
        123,
        100,
        40,
        100,
        20,
        10,
        1024,
        ContractIssue::kNone,
        ObservationField::kCaptureDefinition | ObservationField::kEagerDuration |
            ObservationField::kGraphReplayDuration | ObservationField::kCaptureDuration |
            ObservationField::kInstantiateDuration | ObservationField::kWarmupDuration |
            ObservationField::kGraphMemory | ObservationField::kContractValidation,
        10,
        EvidenceConfidence::kHigh,
    };
}

}  // namespace

int main() {
    using namespace cupolicy;

    require(to_string(DecisionReason::kCandidateAccepted) == "CANDIDATE_ACCEPTED",
            "accepted reason string");
    require(to_string(DecisionReason::kInvalidCandidate) == "INVALID_CANDIDATE",
            "invalid-candidate reason string");
    require(to_string(DecisionReason::kBelowBenefitThreshold) == "BELOW_BENEFIT_THRESHOLD",
            "threshold reason string");
    require(to_string(ObservationField::kGraphMemory) == "GRAPH_MEMORY",
            "observation field string");

    const ObservedExecution partial = complete_observation();
    ObservedExecution missing = partial;
    missing.fields = missing.fields & ~ObservationField::kGraphMemory;
    require(!missing.complete_for_policy(), "partial observation is not policy-complete");

    PolicyCandidate candidate{partial, 10, PolicyCandidateState::kAvailable};
    candidate.memory = complete_memory();
    const PolicyConstraints constraints{};
    const PolicyEvaluation accepted = PolicyEvaluator::evaluate(candidate, constraints);
    require(accepted.decision.mode == ExecutionMode::kGraph, "profitable candidate uses graph");
    require(accepted.memory_evaluated, "canonical evaluator applies memory policy");
    require(accepted.memory_reason == MemoryAdmissionReason::kAccepted, "memory admission reason");
    require(accepted.decision.reason == DecisionReason::kCandidateAccepted, "accepted reason");
    require(accepted.per_replay_savings_ns == 60, "per replay savings");
    require(accepted.setup_cost_ns == 130, "setup cost");
    require(accepted.break_even_replays == 3, "positive-benefit break-even replay count");
    require(accepted.break_even_reachable, "break-even replay count is reachable");
    require(accepted.estimated_net_benefit_ns == 470, "estimated net benefit");

    PolicyConstraints threshold_constraint = constraints;
    threshold_constraint.min_net_benefit_ns = accepted.estimated_net_benefit_ns;
    const PolicyEvaluation threshold_result =
        PolicyEvaluator::evaluate(candidate, threshold_constraint);
    require(threshold_result.decision.reason == DecisionReason::kBelowBenefitThreshold,
            "positive benefit below threshold is distinguished");

    PolicyCandidate insufficient_evidence = candidate;
    insufficient_evidence.observation.fields = insufficient_evidence.observation.fields &
                                                ~ObservationField::kGraphReplayDuration;
    const PolicyEvaluation evidence_result =
        PolicyEvaluator::evaluate(insufficient_evidence, constraints);
    require(evidence_result.decision.reason == DecisionReason::kInsufficientEvidence,
            "missing field forces eager");

    PolicyCandidate unsafe = candidate;
    unsafe.observation.contract_issues = ContractIssue::kCapacityInsufficient;
    const PolicyEvaluation unsafe_result = PolicyEvaluator::evaluate(unsafe, constraints);
    require(unsafe_result.decision.reason == DecisionReason::kUnsafeContract,
            "invalid contract forces eager");

    PolicyCandidate unavailable = candidate;
    unavailable.state = PolicyCandidateState::kUnavailable;
    const PolicyEvaluation unavailable_result = PolicyEvaluator::evaluate(unavailable, constraints);
    require(unavailable_result.decision.reason == DecisionReason::kGraphUnavailable,
            "unavailable graph forces eager");

    PolicyConstraints reuse_constraint = constraints;
    reuse_constraint.min_expected_replays = 11;
    const PolicyEvaluation reuse_result = PolicyEvaluator::evaluate(candidate, reuse_constraint);
    require(reuse_result.decision.reason == DecisionReason::kInsufficientReuse,
            "reuse constraint is enforced");

    PolicyConstraints memory_constraint = constraints;
    memory_constraint.max_graph_memory_bytes = 1023;
    const PolicyEvaluation memory_result = PolicyEvaluator::evaluate(candidate, memory_constraint);
    require(memory_result.decision.reason == DecisionReason::kMemoryBudget,
            "memory constraint is enforced");

    PolicyCandidate slower_graph = candidate;
    slower_graph.observation.graph_replay_duration_ns = 100;
    const PolicyEvaluation slower_result = PolicyEvaluator::evaluate(slower_graph, constraints);
    require(slower_result.decision.reason == DecisionReason::kNonPositiveBenefit,
            "non-positive savings force eager");

    PolicyCandidate expensive_setup = candidate;
    expensive_setup.observation.capture_duration_ns = 10'000;
    const PolicyEvaluation setup_result = PolicyEvaluator::evaluate(expensive_setup, constraints);
    require(setup_result.decision.reason == DecisionReason::kNotAmortized,
            "unamortized setup forces eager");

    PolicyCandidate overflow_sum_candidate = candidate;
    overflow_sum_candidate.observation.capture_duration_ns =
        std::numeric_limits<std::uint64_t>::max();
    const PolicyEvaluation overflow_sum_result =
        PolicyEvaluator::evaluate(overflow_sum_candidate, constraints);
    require(overflow_sum_result.setup_cost_ns == std::numeric_limits<std::uint64_t>::max(),
            "setup sum saturates");
    require(overflow_sum_result.break_even_replays ==
                std::numeric_limits<std::uint64_t>::max() / 60 + 1,
            "break-even arithmetic remains exact without addition wraparound");
    require(overflow_sum_result.break_even_reachable, "large break-even remains representable");

    PolicyCandidate unreachable_break_even = overflow_sum_candidate;
    unreachable_break_even.observation.eager_duration_ns = 2;
    unreachable_break_even.observation.graph_replay_duration_ns = 1;
    unreachable_break_even.observation.instantiate_duration_ns = 0;
    unreachable_break_even.observation.warmup_duration_ns = 0;
    unreachable_break_even.expected_replays = std::numeric_limits<std::uint64_t>::max();
    const PolicyEvaluation unreachable_result =
        PolicyEvaluator::evaluate(unreachable_break_even, constraints);
    require(!unreachable_result.break_even_reachable, "unreachable break-even is explicit");
    require(unreachable_result.break_even_replays == std::numeric_limits<std::uint64_t>::max(),
            "unreachable break-even saturates safely");
    require(unreachable_result.decision.reason == DecisionReason::kNotAmortized,
            "unreachable break-even is not mislabeled as non-positive");

    PolicyCandidate invalid_state = candidate;
    invalid_state.state = static_cast<PolicyCandidateState>(255U);
    const PolicyEvaluation invalid_state_result =
        PolicyEvaluator::evaluate(invalid_state, constraints);
    require(invalid_state_result.decision.reason == DecisionReason::kInvalidCandidate,
            "invalid enum state cannot admit graph");

    PolicyCandidate overflow_product_candidate = candidate;
    overflow_product_candidate.expected_replays = std::numeric_limits<std::uint64_t>::max();
    overflow_product_candidate.observation.capture_duration_ns = 0;
    overflow_product_candidate.observation.instantiate_duration_ns = 0;
    overflow_product_candidate.observation.warmup_duration_ns = 0;
    const PolicyEvaluation overflow_product_result =
        PolicyEvaluator::evaluate(overflow_product_candidate, constraints);
    require(overflow_product_result.decision.mode == ExecutionMode::kGraph,
            "large values are overflow-safe");
    require(overflow_product_result.estimated_net_benefit_ns ==
                std::numeric_limits<std::uint64_t>::max(),
            "benefit product saturates");

    std::array<PolicyCandidate, 5> trace{
        candidate,
        insufficient_evidence,
        unsafe,
        unavailable,
        invalid_state,
    };
    std::uint64_t sink_calls = 0;
    const auto sink = [](const PolicyCandidate&, const PolicyEvaluation&, void* context) noexcept {
        ++*static_cast<std::uint64_t*>(context);
    };
    const SimulationSummary summary =
        PolicySimulator::simulate(std::span<const PolicyCandidate>(trace), constraints, sink, &sink_calls);
    require(summary.observations == 5, "simulator counts observations");
    require(summary.graph_decisions == 1, "simulator counts graph decisions");
    require(summary.eager_decisions == 4, "simulator counts eager decisions");
    require(summary.invalid_candidate == 1, "simulator counts invalid candidates");
    require(summary.insufficient_evidence == 1, "simulator counts evidence rejection");
    require(summary.unsafe_contract == 1, "simulator counts contract rejection");
    require(summary.graph_unavailable == 1, "simulator counts availability rejection");
    require(summary.estimated_net_benefit_ns == 470, "simulator aggregates net benefit");
    require(summary.below_benefit_threshold == 0, "simulator threshold count remains exact");
    require(sink_calls == 5, "simulator invokes sink per candidate");

    // Exhaustive bounded integer-model regression: for small non-negative inputs,
    // graph admission must match the reference net-benefit equation exactly.
    for (std::uint64_t eager_ns = 0; eager_ns <= 10; ++eager_ns) {
        for (std::uint64_t graph_ns = 0; graph_ns <= 10; ++graph_ns) {
            for (std::uint64_t capture_ns = 0; capture_ns <= 5; ++capture_ns) {
                for (std::uint64_t instantiate_ns = 0; instantiate_ns <= 5; ++instantiate_ns) {
                    for (std::uint64_t warmup_ns = 0; warmup_ns <= 5; ++warmup_ns) {
                        for (std::uint64_t replays = 0; replays <= 10; ++replays) {
                            PolicyCandidate probe = candidate;
                            probe.expected_replays = replays;
                            probe.observation.eager_duration_ns = eager_ns;
                            probe.observation.graph_replay_duration_ns = graph_ns;
                            probe.observation.capture_duration_ns = capture_ns;
                            probe.observation.instantiate_duration_ns = instantiate_ns;
                            probe.observation.warmup_duration_ns = warmup_ns;
                            const PolicyEvaluation result = PolicyEvaluator::evaluate(probe, {});
                            const std::uint64_t savings = eager_ns > graph_ns ? eager_ns - graph_ns : 0;
                            const std::uint64_t setup = capture_ns + instantiate_ns + warmup_ns;
                            const std::uint64_t total = replays * savings;
                            const std::uint64_t expected_net = total > setup ? total - setup : 0;
                            require(result.estimated_net_benefit_ns == expected_net,
                                    "bounded model net benefit matches equation");
                            require((result.decision.mode == ExecutionMode::kGraph) ==
                                        (expected_net > 0),
                                    "bounded model admission matches positive net benefit");
                        }
                    }
                }
            }
        }
    }

    require(to_string(EvidenceConfidence::kHigh) == "HIGH", "confidence string");
    require(to_string(DecisionReason::kHysteresisRetained) == "HYSTERESIS_RETAINED",
            "hysteresis reason string");
    require(to_string(DecisionReason::kVariantBudget) == "VARIANT_BUDGET",
            "variant budget reason string");

    PolicyConstraints confidence_constraint = constraints;
    confidence_constraint.min_evidence_confidence = EvidenceConfidence::kMedium;
    const auto confidence_ok = PolicyEvaluator::evaluate(candidate, confidence_constraint);
    require(confidence_ok.decision.mode == ExecutionMode::kGraph, "high confidence satisfies threshold");
    PolicyCandidate low_confidence = candidate;
    low_confidence.observation.confidence = EvidenceConfidence::kLow;
    const auto confidence_reject = PolicyEvaluator::evaluate(low_confidence, confidence_constraint);
    require(confidence_reject.decision.reason == DecisionReason::kNotEnoughConfidence,
            "confidence threshold rejects low confidence");

    PolicyCandidate cold = candidate;
    cold.current_mode = ExecutionMode::kGraph;
    cold.expected_replays = 4;
    PolicyConstraints hysteresis = constraints;
    hysteresis.min_net_benefit_ns = 200;
    hysteresis.graph_exit_min_net_benefit_ns = 100;
    const auto retained = PolicyEvaluator::evaluate(cold, hysteresis);
    require(retained.decision.mode == ExecutionMode::kGraph, "hysteresis retains graph");
    require(retained.hysteresis_retained, "hysteresis flag");
    require(retained.decision.reason == DecisionReason::kHysteresisRetained,
            "hysteresis reason");

    PolicyConstraints invalid_constraints = constraints;
    invalid_constraints.graph_exit_min_net_benefit_ns = 10;
    invalid_constraints.min_net_benefit_ns = 5;
    const auto invalid_constraint_result = PolicyEvaluator::evaluate(candidate, invalid_constraints);
    require(invalid_constraint_result.decision.reason == DecisionReason::kInvalidCandidate,
            "invalid constraints are rejected");

    PolicyCandidate missing_id = candidate;
    missing_id.observation.capture_definition_id = 0;
    const auto missing_id_result = PolicyEvaluator::evaluate(missing_id, constraints);
    require(missing_id_result.decision.reason == DecisionReason::kInsufficientEvidence,
            "missing definition ID is insufficient evidence");

    PolicyCandidate invalid_confidence = candidate;
    invalid_confidence.observation.confidence = static_cast<EvidenceConfidence>(255U);
    const auto invalid_confidence_result = PolicyEvaluator::evaluate(invalid_confidence, constraints);
    require(invalid_confidence_result.decision.reason == DecisionReason::kInsufficientEvidence,
            "invalid confidence is insufficient evidence");

    PolicyCandidate invalid_mode = candidate;
    invalid_mode.current_mode = static_cast<ExecutionMode>(255);
    const auto invalid_mode_result = PolicyEvaluator::evaluate(invalid_mode, constraints);
    require(invalid_mode_result.decision.reason == DecisionReason::kInvalidCandidate,
            "invalid current mode is rejected");

    PolicyCandidate unsafe_graph = candidate;
    unsafe_graph.current_mode = ExecutionMode::kGraph;
    unsafe_graph.observation.contract_issues = ContractIssue::kCapacityInsufficient;
    PolicyConstraints unsafe_hysteresis = hysteresis;
    const auto unsafe_hysteresis_result = PolicyEvaluator::evaluate(unsafe_graph, unsafe_hysteresis);
    require(unsafe_hysteresis_result.decision.mode == ExecutionMode::kEager,
            "hysteresis cannot retain unsafe graph");
    require(unsafe_hysteresis_result.decision.reason == DecisionReason::kUnsafeContract,
            "safety gate overrides hysteresis");


    require(to_string(MemoryAdmissionReason::kAccepted) == "ACCEPTED", "memory reason string");
    MemoryConstraints memory_constraints{};
    const MemoryAdmission memory_ok =
        MemoryPolicyEvaluator::evaluate(candidate.memory, candidate.observation.graph_memory_bytes,
                                        memory_constraints);
    require(memory_ok.admitted, "memory admission accepts within budget");
    require(memory_ok.projected_graph_resident_bytes == 5120, "projected graph residency");
    require(memory_ok.projected_total_resident_bytes == 7168, "projected total residency");
    require(memory_ok.free_bytes_after_admission == 9216, "free bytes after admission");

    MemoryConstraints graph_cap = memory_constraints;
    graph_cap.max_graph_resident_bytes = 4096;
    const MemoryAdmission graph_cap_result = MemoryPolicyEvaluator::evaluate(
        candidate.memory, candidate.observation.graph_memory_bytes, graph_cap);
    require(!graph_cap_result.admitted, "graph resident cap rejects candidate");
    require(graph_cap_result.reason == MemoryAdmissionReason::kCandidateExceedsGraphBudget,
            "graph cap reason");

    MemorySnapshot low_total = candidate.memory;
    low_total.device_budget_bytes = 7000;
    const MemoryAdmission total_budget_result = MemoryPolicyEvaluator::evaluate(
        low_total, candidate.observation.graph_memory_bytes, memory_constraints);
    require(!total_budget_result.admitted, "total memory budget rejects candidate");
    require(total_budget_result.reason == MemoryAdmissionReason::kTotalBudgetExceeded,
            "total budget reason");

    MemorySnapshot current_over_budget = candidate.memory;
    current_over_budget.device_budget_bytes = 6000;
    const MemoryAdmission current_over_budget_result = MemoryPolicyEvaluator::evaluate(
        current_over_budget, candidate.observation.graph_memory_bytes, memory_constraints);
    require(!current_over_budget_result.admitted, "current over-budget state rejects candidate");
    require(current_over_budget_result.reason == MemoryAdmissionReason::kCurrentUsageExceedsBudget,
            "current usage budget reason");

    MemoryConstraints reserve = memory_constraints;
    reserve.min_free_bytes_after_admission = 10'000;
    const MemoryAdmission reserve_result = MemoryPolicyEvaluator::evaluate(
        candidate.memory, candidate.observation.graph_memory_bytes, reserve);
    require(!reserve_result.admitted, "reserved headroom rejects candidate");
    require(reserve_result.reason == MemoryAdmissionReason::kReservedHeadroomViolated,
            "reserved headroom reason");

    MemorySnapshot overcommitted = candidate.memory;
    overcommitted.non_graph_resident_bytes = 20 * 1024;
    const MemoryAdmission overcommitted_result = MemoryPolicyEvaluator::evaluate(
        overcommitted, candidate.observation.graph_memory_bytes, memory_constraints);
    require(!overcommitted_result.admitted, "current over-budget state rejects candidate");
    require(overcommitted_result.reason == MemoryAdmissionReason::kCurrentUsageExceedsBudget,
            "current usage reason");

    PolicyCandidate missing_memory = candidate;
    missing_memory.memory = MemorySnapshot{};
    const auto missing_memory_eval = PolicyEvaluator::evaluate(missing_memory, constraints);
    require(missing_memory_eval.decision.reason == DecisionReason::kMemoryBudget,
            "canonical evaluator rejects missing memory evidence");
    require(missing_memory_eval.memory_reason == MemoryAdmissionReason::kInsufficientEvidence,
            "missing memory reason is preserved");
    const auto missing_memory_summary =
        PolicySimulator::simulate(std::span<const PolicyCandidate>(&missing_memory, 1), constraints);
    require(missing_memory_summary.graph_decisions == 0, "missing memory evidence blocks graph");
    require(missing_memory_summary.memory_budget_rejections == 1,
            "missing memory evidence is reported as memory rejection");

    // Exhaustive bounded memory-model regression: admission must satisfy the exact accounting
    // inequalities, and increasing usage cannot convert a rejection into an admission.
    for (std::uint64_t budget = 0; budget <= 16; ++budget) {
        for (std::uint64_t non_graph = 0; non_graph <= 16; ++non_graph) {
            for (std::uint64_t graph = 0; graph <= 16; ++graph) {
                for (std::uint64_t candidate_bytes = 0; candidate_bytes <= 8; ++candidate_bytes) {
                    MemorySnapshot bounded{
                        budget,
                        non_graph,
                        graph,
                        MemoryField::kDeviceBudget | MemoryField::kNonGraphResident |
                            MemoryField::kGraphResident,
                    };
                    MemoryConstraints bounded_constraints{};
                    const MemoryAdmission result = MemoryPolicyEvaluator::evaluate(
                        bounded, candidate_bytes, bounded_constraints);
                    const bool expected =
                        non_graph <= budget &&
                        graph <= budget - non_graph &&
                        graph <= bounded_constraints.max_graph_resident_bytes &&
                        candidate_bytes <= bounded_constraints.max_graph_resident_bytes - graph &&
                        candidate_bytes <= budget - non_graph - graph &&
                        (budget - non_graph - graph - candidate_bytes) >=
                            bounded_constraints.min_free_bytes_after_admission;
                    require(result.admitted == expected, "bounded memory admission matches accounting");

                    if (!result.admitted && non_graph < 16) {
                        MemorySnapshot more_non_graph = bounded;
                        more_non_graph.non_graph_resident_bytes = non_graph + 1;
                        const MemoryAdmission monotonic = MemoryPolicyEvaluator::evaluate(
                            more_non_graph, candidate_bytes, bounded_constraints);
                        require(!monotonic.admitted,
                                "increasing non-graph usage cannot create admission");
                    }
                    if (!result.admitted && candidate_bytes < 8) {
                        const MemoryAdmission more_candidate = MemoryPolicyEvaluator::evaluate(
                            bounded, candidate_bytes + 1, bounded_constraints);
                        require(!more_candidate.admitted,
                                "increasing candidate bytes cannot create admission");
                    }
                }
            }
        }
    }

    std::array<PolicyCandidate, 3> grouped{candidate, candidate, candidate};
    grouped[1].observation.capture_definition_id = 124;
    grouped[2].observation.capture_definition_id = 125;
    PolicyConstraints grouped_constraints = constraints;
    grouped_constraints.max_graph_variants = 2;
    const auto grouped_summary =
        PolicySimulator::simulate(std::span<const PolicyCandidate>(grouped), grouped_constraints);
    require(grouped_summary.unique_capture_definitions == 3, "unique group count");
    require(grouped_summary.duplicate_candidates == 0, "distinct group count");
    require(grouped_summary.accepted_graph_definitions == 2, "graph variant budget count");
    require(grouped_summary.variant_budget_rejections == 1, "variant budget rejection count");

    std::array<PolicyCandidate, 3> duplicates{candidate, candidate, candidate};
    const auto duplicate_summary =
        PolicySimulator::simulate(std::span<const PolicyCandidate>(duplicates), constraints);
    require(duplicate_summary.unique_capture_definitions == 1, "duplicate unique group count");
    require(duplicate_summary.duplicate_candidates == 2, "duplicate group count");
    require(duplicate_summary.accepted_graph_definitions == 1, "duplicate accepted group count");

    return EXIT_SUCCESS;
}
