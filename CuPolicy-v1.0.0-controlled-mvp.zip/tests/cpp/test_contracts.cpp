// SPDX-License-Identifier: Apache-2.0
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <utility>
#include <vector>

#include "cupolicy/contracts.hpp"
#include "cupolicy/execution_identity.hpp"

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "contracts test failed: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

}  // namespace

int main() {
    using namespace cupolicy;

    const WorkloadSignature a{1, 128, 4096};
    const WorkloadSignature b{1, 128, 4096};
    const WorkloadSignature c{1, 256, 4096};
    require(a == b, "equal workload signatures");
    require(!(a == c), "different workload signatures");
    require(same_shape(a, b), "same_shape matches");

    std::vector<std::uint64_t> source_shape{1, 64, 1024};
    const WorkloadSignature owned{source_shape};
    source_shape[1] = 128;
    require(owned.shape[1] == 64, "workload signature owns source dimensions");

    const MetadataContract metadata{
        ResourceIdentity{11, Mutability::kMutable},
        4096,
        2048,
        Lifetime::kReplay,
    };
    require(metadata.valid(), "metadata capacity contract");
    require(metadata.validate().valid(), "valid metadata diagnostics");
    require(metadata.capacity_sufficient(), "metadata capacity sufficient");
    require(to_string(metadata.resource.mutability) == "MUTABLE", "mutability string");

    const MetadataContract unspecified_lifetime{
        ResourceIdentity{11, Mutability::kMutable},
        4096,
        2048,
        Lifetime::kUnspecified,
    };
    require(!unspecified_lifetime.valid(), "unspecified metadata lifetime rejected");
    require(has_issue(unspecified_lifetime.validate().issues, ContractIssue::kLifetimeUnspecified),
            "metadata diagnostics identify missing lifetime");

    const MetadataContract insufficient{
        ResourceIdentity{11, Mutability::kMutable},
        1024,
        2048,
        Lifetime::kReplay,
    };
    require(!insufficient.valid(), "insufficient metadata rejected");
    require(has_issue(insufficient.validate().issues, ContractIssue::kCapacityInsufficient),
            "metadata diagnostics identify insufficient capacity");

    const MetadataContract unspecified_resource{
        ResourceIdentity{0, Mutability::kMutable},
        4096,
        2048,
        Lifetime::kReplay,
    };
    require(!unspecified_resource.valid(), "unspecified metadata resource rejected");
    require(has_issue(unspecified_resource.validate().issues, ContractIssue::kResourceUnspecified),
            "metadata diagnostics identify missing resource");

    const WorkspaceContract workspace{
        ResourceIdentity{22, Mutability::kImmutable},
        8192,
        4096,
        Lifetime::kExecution,
    };
    require(workspace.valid(), "workspace contract");

    const WorkspaceContract insufficient_workspace{
        ResourceIdentity{22, Mutability::kImmutable},
        1024,
        4096,
        Lifetime::kExecution,
    };
    require(!insufficient_workspace.valid(), "insufficient workspace rejected");

    const StreamContract same_stream{
        7,
        7,
        Ordering::kSameStream,
        0,
    };
    require(same_stream.valid(), "same-stream contract");

    const StreamContract dependency{
        7,
        9,
        Ordering::kExplicitDependency,
        42,
    };
    require(dependency.valid(), "explicit dependency contract");

    const StreamContract mismatched_same_stream{
        7,
        9,
        Ordering::kSameStream,
        0,
    };
    require(!mismatched_same_stream.valid(), "same-stream mismatch rejected");
    require(has_issue(mismatched_same_stream.validate().issues, ContractIssue::kStreamMismatch),
            "stream diagnostics identify same-stream mismatch");

    const StreamContract invalid_independent{
        7,
        7,
        Ordering::kIndependent,
        0,
    };
    require(!invalid_independent.valid(), "independent same-stream contract rejected");
    require(has_issue(invalid_independent.validate().issues, ContractIssue::kStreamMismatch),
            "stream diagnostics identify invalid independent relationship");

    const StreamContract invalid_dependency{
        7,
        9,
        Ordering::kExplicitDependency,
        0,
    };
    require(!invalid_dependency.valid(), "missing dependency id rejected");
    require(has_issue(invalid_dependency.validate().issues, ContractIssue::kDependencyUnspecified),
            "stream diagnostics identify missing dependency");

    const StreamContract unspecified_stream{
        0,
        0,
        Ordering::kSameStream,
        0,
    };
    require(!unspecified_stream.valid(), "unspecified stream id rejected");
    require(has_issue(unspecified_stream.validate().issues, ContractIssue::kProducerStreamUnspecified),
            "stream diagnostics identify missing producer");

    ExecutionIdentity first{
        WorkloadSignature{1, 128, 4096},
        100,
        200,
        MetadataContract{
            ResourceIdentity{11, Mutability::kMutable},
            4096,
            2048,
            Lifetime::kReplay,
        },
        WorkspaceContract{
            ResourceIdentity{22, Mutability::kImmutable},
            8192,
            4096,
            Lifetime::kExecution,
        },
        dependency,
    };
    ExecutionIdentity same = first;
    require(first == same, "equal execution identities");
    require(identity_hash(first) == identity_hash(same), "equal identities have equal hash");
    require(capture_definition_hash(first) == capture_definition_hash(same), "equal capture definitions have equal hash");
    require(first.capture_definition_equal(same), "capture definitions match");
    require(first.replay_contract_equal(same), "replay contracts match");
    require(first.validate().valid(), "complete execution identity is valid");

    ExecutionIdentity reversed_shape = first;
    reversed_shape.workload.shape = {4096, 128, 1};
    require(!first.capture_definition_equal(reversed_shape), "dimension order changes capture identity");
    require(capture_definition_hash(first) != capture_definition_hash(reversed_shape),
            "dimension order changes capture hash in this regression case");
    ExecutionIdentity different_metadata = first;
    different_metadata.metadata.resource.mutability = Mutability::kImmutable;
    require(identity_hash(first) != identity_hash(different_metadata),
            "metadata mutability changes full identity hash");

    ExecutionIdentity different_stream = first;
    different_stream.stream.consumer_stream_id = 10;
    require(first.capture_definition_equal(different_stream), "capture identity ignores replay resource state");
    require(capture_definition_hash(first) == capture_definition_hash(different_stream),
            "replay-only stream state is excluded from capture hash");
    require(!first.replay_contract_equal(different_stream), "resource contract detects stream change");

    ExecutionIdentity different_topology = first;
    different_topology.topology_id = 101;
    require(!first.capture_definition_equal(different_topology), "topology changes capture identity");

    ExecutionIdentity different_capacity = first;
    different_capacity.metadata.capacity_bytes = 8192;
    require(first.capture_definition_equal(different_capacity), "capacity does not change capture definition");
    require(!first.replay_contract_equal(different_capacity), "capacity change changes replay contract");

    ExecutionIdentity different_lifetime = first;
    different_lifetime.workspace.lifetime = Lifetime::kReplay;
    require(first.capture_definition_equal(different_lifetime), "lifetime does not change capture definition");
    require(!first.replay_contract_equal(different_lifetime), "lifetime change changes replay contract");

    ExecutionIdentity invalid_identity = first;
    invalid_identity.metadata.capacity_bytes = 1;
    invalid_identity.stream.dependency_id = 0;
    const ContractValidation invalid_result = invalid_identity.validate();
    require(!invalid_result.valid(), "invalid execution identity is rejected");
    require(has_issue(invalid_result.issues, ContractIssue::kCapacityInsufficient),
            "identity diagnostics include capacity issue");
    require(has_issue(invalid_result.issues, ContractIssue::kDependencyUnspecified),
            "identity diagnostics include dependency issue");

    ExecutionIdentity different_shape = first;
    different_shape.workload.shape[1] = 256;
    require(!first.capture_definition_equal(different_shape), "shape changes capture identity");

    return EXIT_SUCCESS;
}
