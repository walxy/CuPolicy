// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/shadow.hpp"

#include <array>
#include <cstdlib>
#include <span>

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        std::fprintf(stderr, "FAIL: %s\n", message);
        std::abort();
    }
}

cupolicy::PolicyCandidate base_candidate() {
    using namespace cupolicy;
    PolicyCandidate candidate{};
    candidate.observation.capture_definition_id = 101;
    candidate.observation.eager_duration_ns = 1000;
    candidate.observation.graph_replay_duration_ns = 100;
    candidate.observation.capture_duration_ns = 100;
    candidate.observation.instantiate_duration_ns = 100;
    candidate.observation.warmup_duration_ns = 100;
    candidate.observation.graph_memory_bytes = 1024;
    candidate.observation.timing_samples = 10;
    candidate.observation.confidence = EvidenceConfidence::kHigh;
    candidate.observation.fields =
        ObservationField::kCaptureDefinition |
        ObservationField::kEagerDuration |
        ObservationField::kGraphReplayDuration |
        ObservationField::kCaptureDuration |
        ObservationField::kInstantiateDuration |
        ObservationField::kWarmupDuration |
        ObservationField::kGraphMemory |
        ObservationField::kContractValidation;
    candidate.memory = MemorySnapshot{
        16 * 1024,
        1024,
        2048,
        MemoryField::kDeviceBudget | MemoryField::kNonGraphResident |
            MemoryField::kGraphResident,
    };
    candidate.expected_replays = 10;
    return candidate;
}

}  // namespace

int main() {
    using namespace cupolicy;

    PolicyConstraints constraints{};
    constraints.min_expected_replays = 1;
    constraints.min_evidence_confidence = EvidenceConfidence::kHigh;
    constraints.min_timing_samples = 1;

    ShadowController controller(ShadowConfig{ShadowMode::kShadow, 2});
    PolicyCandidate eager = base_candidate();

    ShadowController invalid_config(ShadowConfig{static_cast<ShadowMode>(255U), 0});
    require(invalid_config.config().mode == ShadowMode::kOff, "invalid config fails closed");
    require(invalid_config.config().max_trace_entries == 1, "invalid config uses bounded off-mode capacity");
    const auto invalid_config_result = invalid_config.evaluate(eager, constraints);
    require(!invalid_config_result.evaluated, "invalid config cannot evaluate policy");

    const auto first = controller.evaluate(eager, constraints);
    require(first.intervention_performed == false, "shadow never intervenes");
    require(first.evaluated, "shadow evaluates complete observation");
    require(first.comparison == ShadowComparisonReason::kPolicyWouldPreferGraph,
            "policy would prefer graph over eager baseline");
    require(controller.report().policy_would_prefer_graph == 1, "comparison count");
    require(controller.report().estimated_regret_ns > 0, "regret estimate recorded");
    require(controller.trace().size() == 1, "trace record");

    PolicyCandidate graph = eager;
    graph.current_mode = ExecutionMode::kGraph;
    const auto second = controller.evaluate(graph, constraints);
    require(second.comparison == ShadowComparisonReason::kAgreement, "graph agreement");
    require(controller.report().agreements == 1, "agreement count");
    require(controller.report().trace_entries == 2, "second trace record");
    require(controller.report().estimated_regret_ns > 0, "prospective graph benefit recorded");

    ShadowController constrained_controller(ShadowConfig{ShadowMode::kShadow, 4});
    PolicyCandidate graph_rejected = graph;
    graph_rejected.memory.fields = MemoryField::kNone;
    const auto graph_rejected_result = constrained_controller.evaluate(graph_rejected, constraints);
    require(graph_rejected_result.proposed_decision.mode == ExecutionMode::kEager,
            "memory-rejected graph proposal falls back to eager");
    require(graph_rejected_result.estimated_policy_benefit_ns == 0,
            "constrained graph does not report performance benefit as policy benefit");
    require(graph_rejected_result.estimated_regret_ns == 0,
            "constrained graph does not report false performance regret");

    ShadowController observe_controller(ShadowConfig{ShadowMode::kObserve, 2});
    const auto observed_only = observe_controller.evaluate(eager, constraints);
    require(!observed_only.evaluated, "observe mode does not evaluate policy");
    require(observed_only.proposed_decision.mode == ExecutionMode::kEager,
            "observe mode exposes baseline mode only");
    require(observe_controller.report().observations == 1, "observe mode records observation");
    require(observe_controller.report().evaluated == 0, "observe mode does not count evaluation");

    PolicyCandidate invalid = eager;
    invalid.current_mode = static_cast<ExecutionMode>(255U);
    const auto invalid_result = controller.evaluate(invalid, constraints);
    require(!invalid_result.evaluated, "invalid baseline not evaluated");
    require(invalid_result.intervention_performed == false, "invalid baseline no intervention");
    require(controller.report().policy_could_not_evaluate == 1, "invalid baseline counted");
    require(controller.report().trace_dropped == 1, "trace cap is bounded");

    const std::string json = controller.report_json();
    require(json.find("\"intervention_performed\": false") != std::string::npos,
            "json explicitly proves no intervention");
    require(json.find("\"observations\": 3") != std::string::npos, "json observation count");

    ShadowController off(ShadowConfig{ShadowMode::kOff, 2});
    const auto off_result = off.evaluate(eager, constraints);
    require(!off_result.evaluated, "off mode skips evaluation");
    require(off.report().observations == 0, "off mode leaves report untouched");

    std::array<PolicyCandidate, 2> replay_trace{eager, graph};
    ShadowController replay_controller(ShadowConfig{ShadowMode::kShadow, 4});
    const ShadowReport replay_report =
        replay_controller.replay(std::span<const PolicyCandidate>(replay_trace), constraints);
    require(replay_report.observations == 2, "replay count");
    require(replay_report.trace_entries == 2, "replay trace count");
    require(replay_report.intervention_performed() == false, "replay never intervenes");

    return EXIT_SUCCESS;
}
