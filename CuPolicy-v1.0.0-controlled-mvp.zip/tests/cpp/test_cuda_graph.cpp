// SPDX-License-Identifier: Apache-2.0
#include "cupolicy/cuda_graph.hpp"

#include <cstdlib>
#include <iostream>

#if defined(CUPOLICY_HAS_CUDA)

#include <cuda_runtime_api.h>

namespace {

struct MemsetContext {
    void* device_ptr;
    std::size_t bytes;
    int value;
    bool two_ops;
};

cudaError_t memset_callback(cudaStream_t stream, void* opaque) noexcept {
    const auto* context = static_cast<const MemsetContext*>(opaque);
    cudaError_t error = cudaMemsetAsync(context->device_ptr, context->value, context->bytes, stream);
    if (error != cudaSuccess || !context->two_ops) {
        return error;
    }
    return cudaMemsetAsync(context->device_ptr, context->value, context->bytes, stream);
}

cudaError_t failing_callback(cudaStream_t, void*) noexcept {
    return cudaErrorInvalidValue;
}

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

void require_cuda(cudaError_t error, const char* message) {
    if (error != cudaSuccess) {
        std::cerr << "FAIL: " << message << ": " << cudaGetErrorString(error) << '\n';
        std::exit(EXIT_FAILURE);
    }
}

}  // namespace

int main() {
    int device_count = 0;
    const cudaError_t count_error = cudaGetDeviceCount(&device_count);
    if (count_error == cudaErrorNoDevice || device_count == 0) {
        std::cout << "SKIP: no CUDA device available\n";
        return 77;
    }
    require_cuda(count_error, "cudaGetDeviceCount");
    require_cuda(cudaSetDevice(0), "cudaSetDevice");

    cudaStream_t stream = nullptr;
    cudaStream_t other_stream = nullptr;
    void* device_buffer = nullptr;
    require_cuda(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking), "create stream");
    require_cuda(cudaStreamCreateWithFlags(&other_stream, cudaStreamNonBlocking), "create second stream");
    require_cuda(cudaMalloc(&device_buffer, 64), "allocate buffer");

    {
        MemsetContext context{device_buffer, 64, 0x11, false};
        cupolicy::CudaGraphRuntime runtime;

        auto status = runtime.capture(stream, memset_callback, &context);
        require(status.ok(), "initial capture succeeds");
        require(runtime.initialized(), "runtime initialized after capture");
        const std::uint64_t initial_graph_id = runtime.graph_id();
        require(initial_graph_id != 0, "graph id allocated");

        const auto first_launch = runtime.launch(stream);
        require(first_launch.ok(), "first graph launch succeeds");
        require_cuda(cudaStreamSynchronize(stream), "sync first launch");

        unsigned char host_value = 0;
        require_cuda(cudaMemcpy(&host_value, device_buffer, 1, cudaMemcpyDeviceToHost), "copy first value");
        require(host_value == 0x11, "first graph writes expected value");

        const auto wrong_stream = runtime.launch(other_stream);
        require(wrong_stream.code == cupolicy::GraphRuntimeStatusCode::kStreamMismatch,
            "launch on a different stream is rejected");

        context.value = 0x22;
        status = runtime.update(stream, memset_callback, &context);
        require(status.ok(), "graph update succeeds");
        require(runtime.graph_id() == initial_graph_id, "successful update preserves graph id");
        require(status.update_result_code == static_cast<int>(cupolicy::GraphUpdateResult::kSuccess),
            "update result reports success");

        require(runtime.launch(stream).ok(), "launch after update succeeds");
        require_cuda(cudaStreamSynchronize(stream), "sync updated launch");
        require_cuda(cudaMemcpy(&host_value, device_buffer, 1, cudaMemcpyDeviceToHost), "copy updated value");
        require(host_value == 0x22, "updated graph writes expected value");

        context.value = 0x2A;
        context.two_ops = true;
        const auto rejected_update = runtime.update(stream, memset_callback, &context);
        require(rejected_update.code == cupolicy::GraphRuntimeStatusCode::kGraphUpdateRejected,
            "topology-changing update is rejected");
        require(rejected_update.update_result_code ==
                static_cast<int>(cupolicy::GraphUpdateResult::kTopologyChanged),
            "topology update result is reported");
        require(runtime.graph_id() == initial_graph_id,
            "rejected update preserves graph id");
        context.two_ops = false;
        require(runtime.launch(stream).ok(), "old graph remains launchable after rejected update");
        require_cuda(cudaStreamSynchronize(stream), "sync after rejected update");
        require_cuda(cudaMemcpy(&host_value, device_buffer, 1, cudaMemcpyDeviceToHost),
                 "copy after rejected update");
        require(host_value == 0x22, "rejected update preserves installed executable graph");

        context.value = 0x33;
        context.two_ops = true;
        const auto wrong_recapture_stream = runtime.recapture(other_stream, memset_callback, &context);
        require(wrong_recapture_stream.code == cupolicy::GraphRuntimeStatusCode::kStreamMismatch,
            "recapture on a different stream is rejected");

        status = runtime.recapture(stream, memset_callback, &context);
        require(status.ok(), "recapture succeeds");
        require(runtime.graph_id() != initial_graph_id, "recapture allocates a new graph id");

        require(runtime.launch(stream).ok(), "launch after recapture succeeds");
        require_cuda(cudaStreamSynchronize(stream), "sync recaptured launch");
        require_cuda(cudaMemcpy(&host_value, device_buffer, 1, cudaMemcpyDeviceToHost), "copy recaptured value");
        require(host_value == 0x33, "recaptured graph writes expected value");

        const auto invalid_eviction = runtime.evict(
            cupolicy::EvictionOptions{static_cast<cupolicy::EvictionMode>(255)});
        require(invalid_eviction.status.code == cupolicy::GraphRuntimeStatusCode::kInvalidArgument,
                "invalid eviction mode is rejected");
        require(runtime.initialized(), "invalid eviction leaves runtime initialized");

        const auto nonblocking_eviction = runtime.evict();
        require(nonblocking_eviction.ok(), "nonblocking eviction succeeds");
        require(nonblocking_eviction.logical_eviction, "nonblocking eviction clears logical residency");
        require(nonblocking_eviction.physical_release_may_be_deferred,
                "nonblocking eviction requires conservative memory accounting");
        require(!runtime.initialized(), "runtime is uninitialized after eviction");
        require(runtime.graph_id() == 0, "graph id is cleared after eviction");
        require(runtime.launch(stream).code == cupolicy::GraphRuntimeStatusCode::kNotInitialized,
                "launch after eviction is rejected");

        context.value = 0x55;
        context.two_ops = false;
        status = runtime.capture(stream, memset_callback, &context);
        require(status.ok(), "capture after eviction succeeds");
        const auto synchronized_eviction = runtime.evict(
            cupolicy::EvictionOptions{cupolicy::EvictionMode::kWaitForCompletion});
        require(synchronized_eviction.ok(), "synchronized eviction succeeds");
        require(synchronized_eviction.synchronization_performed,
                "synchronized eviction reports stream synchronization");
        require(!synchronized_eviction.physical_release_may_be_deferred,
                "synchronized eviction has a stronger release boundary");

        cupolicy::CudaGraphRuntime empty_capture;
        const auto empty_status = empty_capture.capture(
        stream, [](cudaStream_t, void*) noexcept { return cudaSuccess; }, nullptr);
        require(empty_status.code == cupolicy::GraphRuntimeStatusCode::kCaptureFailed,
            "empty captured graph is rejected");
        require(!empty_capture.initialized(), "empty capture leaves runtime empty");

        cupolicy::CudaGraphRuntime second_capture;
        MemsetContext second_context{device_buffer, 64, 0x44, false};
        status = second_capture.capture(stream, memset_callback, &second_context);
        require(status.ok(), "second runtime can capture the same stream after first runtime is alive");
        const auto duplicate_capture = second_capture.capture(stream, memset_callback, &second_context);
        require(duplicate_capture.code == cupolicy::GraphRuntimeStatusCode::kAlreadyInitialized,
            "duplicate capture on initialized runtime is rejected");

        cupolicy::CudaGraphRuntime failed_capture;
        const auto failed = failed_capture.capture(stream, failing_callback, nullptr);
        require(failed.code == cupolicy::GraphRuntimeStatusCode::kCaptureFailed,
            "callback failure is surfaced as capture failure");
        require(!failed_capture.initialized(), "failed capture leaves runtime empty");
        status = failed_capture.capture(stream, memset_callback, &context);
        require(status.ok(), "runtime remains reusable after failed capture");

        const auto not_initialized = empty_capture.launch(stream);
        require(not_initialized.code == cupolicy::GraphRuntimeStatusCode::kNotInitialized,
            "launch of empty runtime is rejected");
        require(runtime.initialized(), "primary runtime remains initialized until scope exit");
    }

    require_cuda(cudaFree(device_buffer), "free buffer");
    require_cuda(cudaStreamDestroy(other_stream), "destroy second stream");
    require_cuda(cudaStreamDestroy(stream), "destroy stream");
    return EXIT_SUCCESS;
}

#else

int main() { return EXIT_FAILURE; }

#endif
