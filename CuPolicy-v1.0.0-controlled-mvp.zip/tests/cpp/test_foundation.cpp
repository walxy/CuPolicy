// SPDX-License-Identifier: Apache-2.0
#include <cstdlib>
#include <iostream>
#include <string_view>

#include "cupolicy/c_api.h"
#include "cupolicy/execution.hpp"
#include "cupolicy/status.hpp"
#include "cupolicy/version.hpp"
#include "cupolicy/workload.hpp"

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "foundation test failed: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

}  // namespace

int main() {
    using namespace cupolicy;

    require(std::string_view(cupolicy_version()) == kVersion, "C API version");

    require(Status{}.ok(), "default status");
    const Status invalid{StatusCode::kInvalidArgument};
    require(!invalid.ok(), "invalid status");
    require(invalid.code() == StatusCode::kInvalidArgument, "invalid status code");
    require(invalid.message() == "INVALID_ARGUMENT", "status message");

    require(to_string(ExecutionMode::kGraph) == "GRAPH", "execution mode string");
    require(to_string(DecisionReason::kDefault) == "DEFAULT", "decision reason string");
    require(to_string(DecisionReason::kCandidateAccepted) == "CANDIDATE_ACCEPTED",
            "policy decision reason string");
    const ExecutionDecision decision{ExecutionMode::kEager, 0, DecisionReason::kDefault};
    require(decision.mode == ExecutionMode::kEager, "default execution decision");

    const WorkloadSignature a{1, 128, 4096};
    const WorkloadSignature b{1, 128, 4096};
    const WorkloadSignature c{1, 256, 4096};
    require(same_shape(a, b), "matching workload shapes");
    require(!same_shape(a, c), "different workload shapes");

    return 0;
}
