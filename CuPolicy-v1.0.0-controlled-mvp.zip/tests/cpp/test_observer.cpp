// SPDX-License-Identifier: Apache-2.0
#include <array>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <thread>
#include <utility>

#include "cupolicy/observation.hpp"

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "observer test failed: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

struct SinkState {
    std::atomic<std::uint64_t> count{0};
    std::atomic<std::uint64_t> last_operation{0};
};

void record_sink(const cupolicy::ObservationSample& sample, void* context) noexcept {
    auto* state = static_cast<SinkState*>(context);
    state->last_operation.store(sample.operation_id, std::memory_order_relaxed);
    state->count.fetch_add(1, std::memory_order_relaxed);
}

}  // namespace

int main() {
    using namespace cupolicy;

    require(to_string(ObservationMode::kDisabled) == std::string_view{"DISABLED"},
            "disabled mode string");
    require(to_string(ObservationMode::kSampled) == std::string_view{"SAMPLED"},
            "sampled mode string");
    require(to_string(ObservationMode::kFull) == std::string_view{"FULL"},
            "full mode string");

    Observer disabled{ObserverConfig{ObservationMode::kDisabled, 1}};
    {
        auto scope = disabled.begin(1, 2);
        static_cast<void>(scope);
    }
    require(disabled.snapshot().events_seen == 0, "disabled observer has no events");

    SinkState state;
    Observer full{ObserverConfig{ObservationMode::kFull, 1}, record_sink, &state};
    {
        auto scope = full.begin(7, 3);
        std::this_thread::sleep_for(std::chrono::microseconds(50));
    }
    const auto full_snapshot = full.snapshot();
    require(full_snapshot.events_seen == 1, "full observer counts one event");
    require(full_snapshot.samples_recorded == 1, "full observer records one sample");
    require(full_snapshot.total_cpu_duration_ns > 0, "full observer records duration");
    require(full_snapshot.max_cpu_duration_ns >= full_snapshot.last_cpu_duration_ns,
            "max duration is valid");
    require(state.count.load(std::memory_order_relaxed) == 1, "sink receives one sample");
    require(state.last_operation.load(std::memory_order_relaxed) == 7,
            "sink receives operation id");

    struct SamplingState {
        std::array<std::uint64_t, 4> sequences{};
        std::array<std::uint64_t, 4> operations{};
        std::atomic<std::uint64_t> count{0};
    };
    SamplingState sampling_state;
    const auto sampling_sink = [](const ObservationSample& sample, void* context) noexcept {
        auto* sampling = static_cast<SamplingState*>(context);
        const auto index = sampling->count.fetch_add(1, std::memory_order_relaxed);
        if (index < sampling->sequences.size()) {
            sampling->sequences[static_cast<std::size_t>(index)] = sample.sequence;
            sampling->operations[static_cast<std::size_t>(index)] = sample.operation_id;
        }
    };
    Observer sampled{ObserverConfig{ObservationMode::kSampled, 3}, sampling_sink, &sampling_state};
    for (std::uint64_t i = 0; i < 7; ++i) {
        auto scope = sampled.begin(i, 0);
        static_cast<void>(scope);
    }
    const auto sampled_snapshot = sampled.snapshot();
    require(sampled_snapshot.events_seen == 7, "sampled observer sees all events");
    require(sampled_snapshot.samples_recorded == 3, "sampling every third event from first");
    require(sampling_state.count.load(std::memory_order_relaxed) == 3,
            "sampling sink receives three samples");
    require(sampling_state.sequences[0] == 1 && sampling_state.sequences[1] == 4 &&
                sampling_state.sequences[2] == 7,
            "sampling uses one-based event sequence");
    require(sampling_state.operations[0] == 0 && sampling_state.operations[1] == 3 &&
                sampling_state.operations[2] == 6,
            "sampling selects first and every third event");

    Observer every_event{ObserverConfig{ObservationMode::kSampled, 1}};
    for (std::uint64_t i = 0; i < 4; ++i) {
        auto scope = every_event.begin(i, 0);
        static_cast<void>(scope);
    }
    const auto every_event_snapshot = every_event.snapshot();
    require(every_event_snapshot.samples_recorded == 4,
            "sampling interval one records every event");

    Observer move_observer{{ObservationMode::kFull, 1}};
    {
        auto moved = move_observer.begin(42, 0);
        auto moved_again = std::move(moved);
        static_cast<void>(moved_again);
    }
    const auto move_snapshot = move_observer.snapshot();
    require(move_snapshot.samples_recorded == 1, "moved scope is recorded exactly once");

    ObserverConfig zero_interval{ObservationMode::kSampled, 0};
    Observer normalized{zero_interval};
    require(normalized.config().sample_every == 1, "zero sampling interval normalized");

    Observer concurrent{{ObservationMode::kFull, 1}};
    constexpr int kThreads = 4;
    constexpr int kEventsPerThread = 2500;
    std::array<std::thread, kThreads> workers;
    for (int thread_index = 0; thread_index < kThreads; ++thread_index) {
        workers[static_cast<std::size_t>(thread_index)] = std::thread([&concurrent, thread_index] {
            const auto base = static_cast<std::uint64_t>(thread_index) * kEventsPerThread;
            for (int event = 0; event < kEventsPerThread; ++event) {
                auto scope = concurrent.begin(base + static_cast<std::uint64_t>(event), 0);
                static_cast<void>(scope);
            }
        });
    }
    for (auto& worker : workers) {
        worker.join();
    }
    const auto concurrent_snapshot = concurrent.snapshot();
    constexpr auto kTotalEvents = static_cast<std::uint64_t>(kThreads * kEventsPerThread);
    require(concurrent_snapshot.events_seen == kTotalEvents, "concurrent event count");
    require(concurrent_snapshot.samples_recorded == kTotalEvents, "concurrent sample count");
    require(concurrent_snapshot.total_cpu_duration_ns > 0, "concurrent durations recorded");

    return EXIT_SUCCESS;
}
