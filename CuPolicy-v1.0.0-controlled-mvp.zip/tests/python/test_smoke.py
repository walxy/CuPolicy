def test_stage00_smoke() -> None:
    assert True
