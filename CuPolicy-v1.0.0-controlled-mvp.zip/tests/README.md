# Tests

Host-side foundation tests are built with CMake. GPU/CUDA tests are deferred until CUDA runtime code exists.
