# Security policy

Do not include credentials, private keys, benchmark secrets, or proprietary model assets in issues or repository content.

Security-sensitive defects involving memory safety, code execution, package supply chain, or release artifacts should be reported privately to the project maintainers once the public repository is established.
